#ifndef ORDERMANAGERFORM_H
#define ORDERMANAGERFORM_H

//#include "client.h"
//#include "order.h"
//#include "product.h"
#include <QWidget>

class QMenu;
class QTreeWidgetItem;
class ProductManagerForm;
class ClientManagerForm;
class QSqlTableModel;

namespace Ui { class OrderManagerForm; }

class OrderManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit OrderManagerForm(QWidget *parent = nullptr);   //생성자
    ~OrderManagerForm();                                    //소멸자
    void loadData();                                        //파일 입출력
//    int calTotalPrice();

private:
    int makeId();                                           //주문 ID를 자동 할당해주는 함수
    int clientID;
/*    QMap<int, Order*> orderList; */                           //주문 정보를 Map에 담아 List화
    Ui::OrderManagerForm *ui;                               //OrderManagerForm의 ui
    QMenu* menu;    //QMenu 클래스는 메뉴 모음, 상황에 맞는 메뉴 및 기타 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel * orderModel;

private slots:
    /* Client에서 전달된 시그널을 구현하는 슬롯*/
    void updateClientTreeWdiget(QList<QStringList>);
    void updateClient(QStringList);

    void removeItem();                                      //항목(item)을 제거하는 함수
    void showContextMenu(const QPoint &);                   //마우스 커서 위치
    //void on_treeWidget_itemClicked(QTreeWidgetItem *item, int column);   //treeWidget에 있는 항목(item)을 선택했을 때
    void on_addPushButton_clicked();                        //Add(주문 추가) 버튼을 클릭했을 때
    void on_modifyPushButton_clicked();                     //Modify(수정) 버튼을 클릭했을 때
    void on_searchPushButton_clicked();                     //검색 기능을 수행하는 함수
    void on_clientTreeWidget_itemClicked(QTreeWidgetItem *item, int column);
    void on_clientNameLineEdit_textEdited(const QString clientName);
    void on_productNameComboBox_textActivated(const QString);


    void updateProduct(QStringList);
//    void updateProduct(Product*, int);
//    void update(QList<QString>);
    void on_purchaseQuantitySpinBox_valueChanged(int);
    void on_clearPushButton_clicked();
    void on_tableView_clicked(const QModelIndex &index);


    /*YUNA*/
    void slot_productName(int, QString);        //productNameComboBox를 클릭하면 제품 이름이 출력되는 슬롯
    void slot_productInfo(QStringList);        //productNameComboBox에서 제품을 선택하면 productTreeWidget에 제품 정보가 출력되는 슬롯
    void updateTotalPrice(int);

signals:
    /* Order -> Client로 시그널 보냄 */
    void sig_requesSearchClient(QString);
    void sig_requesProductNameSearch(QString);
    void sig_calTotalPrice(QString, int = -1);
    //void sig_requesProductNameSearch(QString, int = -1);

//    void sig_requestProductNames();
    void sig_requestSearchID(int);

    void sig_reduceInventoryAmount(QString, int);

    /*YUNA*/
    void productFind(QString);
};

#endif // ORDERMANAGERFORM_H
