#include "clientmanagerform.h"
#include "ui_clientmanagerform.h"
//#include "client.h"

#include <QFile>
#include <QMenu>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>


ClientManagerForm::ClientManagerForm(QWidget *parent)                   //생성자
    : QWidget(parent),
      ui(new Ui::ClientManagerForm)
{
    ui->setupUi(this);                                                  //지정한 위젯에 대한 사용자 인터페이스를 설정

    QList<int> sizes;
    sizes << 1900 << 1300;                                              //1900 : treeWidget size, 1300 : toolBox size
    ui->splitter->setSizes(sizes);                                      //splitter 크기 조절

    QAction* removeAction = new QAction(tr("&Remove"));                 //삭제 기능 생성
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));

    menu = new QMenu;                                                   //menu : 멤버변수       //메뉴 생성
    menu->addAction(removeAction);
    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));
}

void ClientManagerForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "clientConnection");
    db.setDatabaseName("ClientDBlist.db");            //DB 파일로 저장
    if(db.open()) {
        QSqlQuery query(db);
        query.exec("CREATE TABLE IF NOT EXISTS ClientDB(id INTEGER Primary Key,"
                   "clientName VARCHAR(30) NOT NULL, phoneNumber VARHCHAR(50), address VARHCHAR(100), email VARHCHAR(100));");
        //qDebug("%d", __LINE__);
        clientModel = new QSqlTableModel(this, db);
        clientModel->setTable("ClientDB");
        clientModel->select();
        clientModel->setHeaderData(0, Qt::Horizontal, QObject::tr("고객 ID"));
        clientModel->setHeaderData(1, Qt::Horizontal, QObject::tr("고객 이름"));
        clientModel->setHeaderData(2, Qt::Horizontal, QObject::tr("전화번호"));
        clientModel->setHeaderData(3, Qt::Horizontal, QObject::tr("주소"));
        clientModel->setHeaderData(4, Qt::Horizontal, QObject::tr("이메일"));
        //qDebug("%d", __LINE__);
        ui->tableView->setModel(clientModel);
        ui->tableView->resizeColumnsToContents();
    }
    for(int i = 0; i < clientModel->rowCount(); i++) {
        int clientID = clientModel->data(clientModel->index(i, 0)).toInt();
        QString clientName = clientModel->data(clientModel->index(i, 1)).toString();
        emit clientAdded(clientID, clientName);
    }
}

ClientManagerForm::~ClientManagerForm()                                 //소멸자
{
/*    delete ui;

    clientModel->submitAll();
    QSqlDatabase db = clientModel->database();
    if(db.isOpen())
    {
        db.close();
        db.removeDatabase("QSQLITE");
    } */                                               //파일을 닫음

    delete ui;
    QSqlDatabase db = QSqlDatabase::database("clientConnection");
    if(db.isOpen()) {
        clientModel->submitAll();
        delete clientModel;
        db.commit();
        db.close();
    }
}

int ClientManagerForm::makeId( )
//고객 ID를 자동 할당해주는 함수
{
    if(clientModel->rowCount() == 0) {
        return 1;
    } else {
        auto clientID = clientModel->data(clientModel->index(clientModel->rowCount()-1, 0)).toInt();
        return ++clientID;
    }
}

void ClientManagerForm::removeItem()                                    //항목(item)을 제거해주는 함수
{
    QModelIndex index = ui->tableView->currentIndex();
    QString clientName;
    clientName = clientModel->data(index.siblingAtColumn(1)).toString();
    if(index.isValid()) {
        clientModel->removeRow(index.row());
        clientModel->select();
        ui->tableView->update();
    }
    emit sig_sendClientInfo(clientName);
}

void ClientManagerForm::showContextMenu(const QPoint &pos)              //마우스 커서 위치
{
    QPoint globalPos = ui->tableView->mapToGlobal(pos);
    menu->exec(globalPos);
}

void ClientManagerForm::on_tableView_clicked(const QModelIndex &index)
{
    int clientID = clientModel->data(index.siblingAtColumn(0)).toInt();
    QString clientName = clientModel->data(index.siblingAtColumn(1)).toString();
    QString phoneNumber = clientModel->data(index.siblingAtColumn(2)).toString();
    QString address = clientModel->data(index.siblingAtColumn(3)).toString();
    QString email = clientModel->data(index.siblingAtColumn(4)).toString();

    ui->clientIDLineEdit->setText(QString::number(clientID));                       //treeView에서 선택된 항목 중 고객 ID가 clientIDLineEdit에 나타납니다.
    ui->clientNameLineEdit->setText(clientName);                     //treeView에서 선택된 항목 중 고객 이름이 clientNameLineEdit애 나타납니다.
    ui->phoneNumberLineEdit->setText(phoneNumber);                    //treeView에서 선택된 항목 중 고객 전화번호가 phoneNumberLineEdit에 나타납니다.
    ui->addressLineEdit->setText(address);                        //treeView에서 선택된 항목 중 고객 주소가 addressLineEdit에 나타납니다.
    ui->emailLineEdit->setText(email);
}


void ClientManagerForm::on_addPushButton_clicked()                      //Add(고객 추가) 버튼을 클릭했을 때
{
    QString clientname, phonenumber, address, email;
    int clientID = makeId();                                            //고객 ID 자동할당
    ui->clientIDLineEdit->setText(QString::number(clientID));

    clientname = ui->clientNameLineEdit->text();                        //clientNameLineEdit에 입력한 text는 고객 이름
    phonenumber = ui->phoneNumberLineEdit->text();                      //phoneNumberLineEdit에 입력한 text는 고객 전화번호
    address = ui->addressLineEdit->text();                              //addressLineEdit 입력한 text는 고객 주소
    email = ui->emailLineEdit->text();                                  //emailLineEdit 입력한 text는 고객 이메일
#if 1
    QSqlDatabase db = QSqlDatabase::database("clientConnection");
    if(db.isOpen() && clientname.length()) {
        QSqlQuery query(clientModel->database());
        query.prepare("INSERT INTO ClientDB VALUES(?, ?, ?, ?, ?)");
        query.bindValue(0, clientID);
        query.bindValue(1, clientname);
        query.bindValue(2, phonenumber);
        query.bindValue(3, address);
        query.bindValue(4, email);
        query.exec();
        clientModel->select();
        ui->tableView->resizeColumnsToContents();
        emit clientAdded(clientID, clientname);
#else
    if(clientname.length()) {
        QSqlDatabase db = QSqlDatabase::database("clientConnection");
        if(db.isOpen()) {
            QSqlQuery query(db);
            query.exec(QString("INSERT INTO ClientDB VALUES(%1, '%2', '%3', '%4', '%5')")
                       .arg(clientID).arg(clientname).arg(phonenumber).arg(address).arg(email));
            clientModel->select();
            ui->tableView->resizeColumnsToContents();
        }
#endif

    }
    ui->clientIDLineEdit->setText("");                                  //Add 버튼을 누르고 나서 clientIDLineEdit을 공백으로 비워줌
    ui->clientNameLineEdit->setText("");                                //clientNameLineEdit을 공백으로 비워줌
    ui->phoneNumberLineEdit->setText("");                               //phoneNumberLineEdit을 을 공백으로 비워줌
    ui->addressLineEdit->setText("");                                   //addressLineEdit을 공백으로 비워줌
    ui->emailLineEdit->setText("");                                     //emailLineEdit을 공백으로 비워줌
}

void ClientManagerForm::on_modifyPushButton_clicked()                   //Modify(수정) 버튼을 클릭했을 때
{
    QModelIndex ix = ui->tableView->currentIndex();
    int index = ix.row();
    if(ix.isValid()) {
        QString clientName, phoneNumber, address, email;
        int clientID;
        clientID = ui->clientIDLineEdit->text().toInt();
        clientName = ui->clientNameLineEdit->text();
        phoneNumber = ui->phoneNumberLineEdit->text();
        address = ui->addressLineEdit->text();
        email = ui->emailLineEdit->text();
#if 1
        clientModel->setData(ix.siblingAtColumn(1), clientName);
        clientModel->setData(ix.siblingAtColumn(2), phoneNumber);
        clientModel->setData(ix.siblingAtColumn(3), address);
        clientModel->setData(ix.siblingAtColumn(4), email);
        clientModel->submit();
#else
        QSqlQuery query(clientModel->database());
        query.prepare("UPDATE client SET clinetName = ?, phoneNumber = ?, address = ?, email = ?, WHERE clientID = ?");
        query.bindValue(0, clinetName);
        query.bindValue(1, phoneNumber);
        query.bindValue(2, address);
        query.bindValue(3, email);
        query.bindValue(4, clientID);
        query.exec();
#endif
        clientModel->select();
        ui->tableView->resizeColumnsToContents();
        emit sig_sendModifyClient(clientID, index, clientName);

    }
}


void ClientManagerForm::on_searchPushButton_clicked()                   //검색 기능을 수행하는 함수
{
    ui->searchTreeWidget->clear();
    int i = ui->searchComboBox->currentIndex();
    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
                   : Qt::MatchCaseSensitive;

    QModelIndexList indexes = clientModel->match(clientModel->index(0, i), Qt::EditRole, ui->searchLineEdit->text(), -1, Qt::MatchFlags(flag));

    foreach(auto ix, indexes) {
        int clientID = clientModel->data(ix.siblingAtColumn(0)).toInt(); //c->id();
        QString clientName = clientModel->data(ix.siblingAtColumn(1)).toString();
        QString phoneNumber = clientModel->data(ix.siblingAtColumn(2)).toString();
        QString address = clientModel->data(ix.siblingAtColumn(3)).toString();
        QString email =  clientModel->data(ix.siblingAtColumn(4)).toString();
        QStringList strings;
        strings << QString::number(clientID) << clientName << phoneNumber << address << email;
        new QTreeWidgetItem(ui->searchTreeWidget, strings);
        for(int i = 0; i < ui->searchTreeWidget->columnCount(); i++)
            ui->searchTreeWidget->resizeColumnToContents(i);
    }
}

//void ClientManagerForm::acceptClientInfo(int key)
//{
//    QModelIndexList indexes = clientModel->match(clientModel->index(0, 0), Qt::EditRole, key, -1, Qt::MatchFlags(Qt::MatchCaseSensitive));

//    foreach(auto index, indexes) {
////    QModelIndex index = clientList[key];
//        QString name = clientModel->data(index.siblingAtColumn(1)).toString();
//        QString phoneNumber = clientModel->data(index.siblingAtColumn(2)).toString();
//        QString address = clientModel->data(index.siblingAtColumn(3)).toString();
//        emit sendClientInfo(name, phoneNumber, address);
//    }
//}

void ClientManagerForm::sendSearchedClient(QString clientName)          //sendSearchedClient 슬롯 함수 구현
{
#if 0
    //    QSqlDatabase db = QSqlDatabase::database("clientConnection");
    //    if(db.isOpen()) {
    //        QSqlQuery query(clientModel->database());
    //        qDebug() << query.value(1);
    //        if(query.value(1) == clientName)
    //            qDebug() << query.value(1);
    //    }

    for(int i = 0; i < clientModel->rowCount(); i++) {
        QString name = clientModel->data(clientModel->index(i, 1)).toString();
        if(name == clientName)
        {
            QModelIndex ix = ui->tableView->currentIndex();
            int clientID = clientModel->data(ix.siblingAtColumn(0)).toInt(); //c->id();
            QString clientName = clientModel->data(ix.siblingAtColumn(1)).toString();
            QString phoneNumber = clientModel->data(ix.siblingAtColumn(2)).toString();
            QString address = clientModel->data(ix.siblingAtColumn(3)).toString();
            QString email =  clientModel->data(ix.siblingAtColumn(4)).toString();
            QStringList clientStrings;
            clientStrings << QString::number(clientID) << clientName << phoneNumber << address << email;

            emit sig_sendSearchedClient(clientStrings);
        }
    }
#else
    QModelIndexList indexes = clientModel->match(clientModel->index(0, 1),
                                                 Qt::EditRole, clientName, -1, Qt::MatchFlags(Qt::MatchCaseSensitive));
    QList<QStringList> searchedClientList;
    foreach(auto ix, indexes) {
        int clientID = clientModel->data(ix.siblingAtColumn(0)).toInt(); //c->id();
        QString clientName = clientModel->data(ix.siblingAtColumn(1)).toString();
        QString phoneNumber = clientModel->data(ix.siblingAtColumn(2)).toString();
        QString address = clientModel->data(ix.siblingAtColumn(3)).toString();
        QString email =  clientModel->data(ix.siblingAtColumn(4)).toString();
        QStringList clientStrings;
        clientStrings << QString::number(clientID) << clientName << phoneNumber << address << email;
        searchedClientList.append(clientStrings);
    }
    emit sig_sendSearchedClient(searchedClientList);
}
#endif

//    QList<Client*> searchedClientList;
//    foreach(Client* c, clientList)                                      //foreach(variable, container)
//    {
//        if(clientName == c->getClientName())                            //Order에서 입력받은 이름과 Client에 있는 회원 이름 정보가 일치할 경우
//        searchedClientList.append(c);
//    }
//    emit sig_sendSearchedClient(searchedClientList);
//}



void ClientManagerForm::sendSearchedID(int clientID)                  //sendSearchedID 슬롯 함수 구현
{
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList indexes = clientModel->match(clientModel->index(0, 0), Qt::EditRole,
                                                 clientID, -1, Qt::MatchFlags(flag));

        int cID = clientModel->data(indexes.at(0).siblingAtColumn(0)).toInt(); //c->id();
        QString clientName = clientModel->data(indexes.at(0).siblingAtColumn(1)).toString();
        QString phoneNumber = clientModel->data(indexes.at(0).siblingAtColumn(2)).toString();
        QString address = clientModel->data(indexes.at(0).siblingAtColumn(3)).toString();
        QString email =  clientModel->data(indexes.at(0).siblingAtColumn(4)).toString();
        QStringList clientStrings;
        clientStrings << QString::number(cID) << clientName << phoneNumber << address << email;
        emit sig_sendSearchedID(clientStrings);
}

void ClientManagerForm::on_clearPushButton_clicked()
{
    ui->clientIDLineEdit->setText("");                                  //Add 버튼을 누르고 나서 clientIDLineEdit을 공백으로 비워줌
    ui->clientNameLineEdit->setText("");                                //clientNameLineEdit을 공백으로 비워줌
    ui->phoneNumberLineEdit->setText("");                               //phoneNumberLineEdit을 을 공백으로 비워줌
    ui->addressLineEdit->setText("");                                   //addressLineEdit을 공백으로 비워줌
    ui->emailLineEdit->setText("");                                     //emailLineEdit을 공백으로 비워줌
}

