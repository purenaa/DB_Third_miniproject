#ifndef CLIENTMANAGERFORM_H
#define CLIENTMANAGERFORM_H

#include "client.h"
#include <QWidget>

class Client;
class QMenu;
//class QTreeWidgetItem;
class QSqlDatabase;
class QSqlTableModel;

namespace Ui { class ClientManagerForm; }

class ClientManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ClientManagerForm(QWidget *parent = nullptr);          //생성자
    ~ClientManagerForm();                                           //소멸자
    void loadData();                                                //파일 입출력

private slots:
    /* QTreeWidget을 위한 슬롯 */
    void removeItem();                                              //항목(item)을 제거하는 함수
    void showContextMenu(const QPoint &);                           //마우스 커서 위치
    void on_addPushButton_clicked();                                //Add(고객 추가) 버튼을 클릭했을 때
    void on_modifyPushButton_clicked();                             //Modify(수정) 버튼을 클릭했을 때
    void on_searchPushButton_clicked();                             //검색 기능을 수행하는 함수

    /* Order에서 전달된 시그널을 구현하는 슬롯 */
    void sendSearchedClient(QString);
    void sendSearchedID(int);

                                         //OrderManagerForm에서 void sig_requestSearchID(int);가 신호(singals)를 발생
    void on_tableView_clicked(const QModelIndex &index);
    void on_clearPushButton_clicked();



    //    void acceptClientInfo(int);   //교수님코드

signals:
    /* Client -> Server 로 전달하는 시그널*/
    void clientAdded(int, QString);
    void sig_sendModifyClient(int, int, QString);
    void sig_sendClientInfo(QString);

    /* Client -> Order로 전달하는 시그널 */
    void sig_sendSearchedClient(QList<QStringList>);


    void sig_sendSearchedID(QStringList);
    void sendClientInfo(QString, QString, QString);

private:
    int makeId();                                                   //고객 ID를 자동 할당해주는 함수
/*    QMap<int, Client*> clientList;  */                                //고객 정보를 Map에 담아 List화
    Ui::ClientManagerForm *ui;                                      //ClientManagerForm의 ui
    QMenu* menu;                            //QMenu 클래스는 메뉴 모음, 상황에 맞는 메뉴 및 기타 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel* clientModel;
};
#endif // CLIENTMANAGERFORM_H
