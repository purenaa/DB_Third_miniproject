#include "mainwindow.h"
#include "chatclient.h"
#include "qobjectdefs.h"
#include "ui_mainwindow.h"
#include "clientmanagerform.h"
#include "productmanagerform.h"
#include "ordermanagerform.h"
#include "clientserverform.h"
#include "chatclient.h"

#include <QMdiSubWindow>
#include <QSqlDatabase>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , chatClientID(0)
{
    ui->setupUi(this);

    /* WindowTitle 지정 */
    orderForm = new OrderManagerForm(this);
    orderForm->setWindowTitle(tr("Order Info"));
    connect(orderForm, SIGNAL(destroyed()), orderForm, SLOT(deleteLater()));

    serverForm = new ClientServerForm(this);
    serverForm->setWindowTitle(tr("Chatting Server"));

    clientForm = new ClientManagerForm(this);
    connect(clientForm, SIGNAL(destroyed()), clientForm, SLOT(deleteLater()));
    clientForm->setWindowTitle(tr("Client Info"));

    productForm = new ProductManagerForm(this);
    productForm->setWindowTitle(tr("Product Info"));
    connect(productForm, SIGNAL(destroyed()), productForm, SLOT(deleteLater()));

    /* Client -> Server */ /* clientForm에서 고객 정보를 생성, 변경, 삭제할 때마다 ServerForm에서 고객 정보를 업데이트 합니다. */
    connect(clientForm, SIGNAL(clientAdded(int, QString)), serverForm, SLOT(addClient(int, QString)));
    connect(clientForm, SIGNAL(sig_sendClientInfo(QString)), serverForm, SLOT(slot_updateClientInfo(QString)));
    connect(clientForm, SIGNAL(sig_sendModifyClient(int, int, QString)), serverForm, SLOT(slot_updateModifyClient(int, int, QString)));     //12

    /* Order -> Client , Clinet -> Order */
    /* orderForm에서 입력한 고객 이름과 clientForm에 있는 고객 이름이 일치할 때 일치하는 고객 정보를 clientTreeWidget에 출력합니다. */
    connect(orderForm, SIGNAL(sig_requesSearchClient(QString)), clientForm, SLOT(sendSearchedClient(QString)));
    connect(clientForm, SIGNAL(sig_sendSearchedClient(QList<QStringList>)), orderForm, SLOT(updateClientTreeWdiget(QList<QStringList>)));   //5

    /* Product -> Order */ /*productForm의 제품 정보를 OrderForm의 productNameComboBox에서 제품 이름을 출력합니다. */
    connect(productForm, SIGNAL(productAdded(int, QString)), orderForm, SLOT(slot_productName(int, QString)));

    /* Product -> Order */ /* productForm에서 제품 이름을 변경하면 orderForm의 productNameComboBox에도 변경된 제품 이름을 출력합니다. */
    connect(productForm, SIGNAL(sig_sendModifyProduct(int,QString)), orderForm, SLOT(producNameComboBoxModify(int,QString)));

    /* Product -> Order */ /* productForm에서 제품을 삭제하면 orderForm의 productNameComboBox에서도 제품을 삭제합니다. */
    connect(productForm, SIGNAL(sig_sendRemovdProduct(int)), orderForm, SLOT(productNameComboBoxRemove(int)));

    /* Order -> Product */ /* orderForm에서 주문된 정보를 삭제하면 삭제된 제품의 이름과
                              productForm의 제품 이름이 일치할 때 일치하는 제품의 재고 수량을 업데이트합니다. */
    connect(orderForm, SIGNAL(sig_reduceInventoryAmount(QString, int)), productForm, SLOT(updateInventoryAmount(QString, int)));

    /* Order -> Client , Clinet -> Order */
    /* orderForm에서 입력한 고객 이름과 일치하는 고객 정보를 clientForm에서 찾아 clientTreeWidget에 출력합니다. */
    connect(orderForm, SIGNAL(sig_requestSearchID(int)), clientForm, SLOT(sendSearchedID(int)));
    connect(clientForm, SIGNAL(sig_sendSearchedID(QStringList)), orderForm, SLOT(updateClient(QStringList)));

    /* Order -> Product , Product -> Order */
    /* orderForm의 tableView에서 주문된 정보를 클릭했을 때 해당 제품 이름과 일치하는 제품 정보를 productForm에서 찾아 productTreeWidget에 출력합니다. */
    connect(orderForm, SIGNAL(sig_requesProductNameSearch(QString)), productForm, SLOT(slot_sendProductNameSearch(QString)));
    connect(productForm, SIGNAL(sig_sendProductNameSearch(QStringList)), orderForm, SLOT(updateProduct(QStringList)));

    /*Order -> Product, Product -> Order */  /* 구매 수량에 따라 계산된 총 구매 가격을 totalPriceLineEdit에 출력합니다. */
    connect(orderForm, SIGNAL(sig_calTotalPrice(QString,int)), productForm, SLOT(slot_CalTotalPrice(QString,int)));
    connect(productForm, SIGNAL(sig_sendTotalPrice(int)), orderForm, SLOT(updateTotalPrice(int)));

    /*Order -> Product, Product -> Order */
    /* 주문할 때 productNameComboBox에서 선택한 제품 이름과 일치하는 제품 정보를 productForm에서 찾아 productTreeWidget에 출력합니다. */
    connect(orderForm, SIGNAL(productFind(QString)), productForm, SLOT(slot_productData(QString)));
    connect(productForm, SIGNAL(productData(QStringList)), orderForm, SLOT(slot_productInfo(QStringList)));

    clientForm->loadData();
    productForm->loadData();
    orderForm->loadData();

    QIcon iconClient = QIcon("clientImg.png");          // ClientInfo 아이콘
    ui->actionClient->setIcon(iconClient);

    QIcon iconProduct = QIcon("productImg.jpg");        // ProductInfo 아이콘
    ui->actionProduct->setIcon(iconProduct);

    QIcon iconOrder = QIcon("orderImg.png");            // OrderInfo 아이콘
    ui->actionOrder->setIcon(iconOrder);

    QIcon iconChat_Client = QIcon("chatImg.png");       // ChatServer 아이콘
    ui->actionChat_Client->setIcon(iconChat_Client);

    QIcon iconChat_Server = QIcon("serverImg.png");     // ChatClient 아이콘
    ui->actionChatServer->setIcon(iconChat_Server);

    QIcon iconQuit = QIcon("quitImg5.png");             // Quit 아이콘
    ui->actionQuit->setIcon(iconQuit);

    QMdiSubWindow *cw = ui->mdiArea->addSubWindow(clientForm);
    ui->mdiArea->addSubWindow(productForm);
    ui->mdiArea->addSubWindow(orderForm);
    ui->mdiArea->addSubWindow(serverForm);
    ui->mdiArea->setActiveSubWindow(cw);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete serverForm;
    delete clientForm;
    delete productForm;
    delete orderForm;

    QStringList list = QSqlDatabase::connectionNames();
    for(int i = 0; i < list.count(); ++i) {
        QSqlDatabase::removeDatabase(list[i]);
    }
}

void MainWindow::on_actionClient_triggered()
{
    if(clientForm != nullptr) {
        clientForm->setFocus();
    }
}

void MainWindow::on_actionProduct_triggered()
{
    if(productForm != nullptr) {
        productForm->setFocus();
    }
}

void MainWindow::on_actionOrder_triggered()
{
    if(orderForm != nullptr) {
        orderForm->setFocus();
    }
}

void MainWindow::on_mdiArea_subWindowActivated(QMdiSubWindow *orderupdate)
{
    Q_UNUSED(orderupdate);
}

void MainWindow::on_actionChatServer_triggered()
{
    if(serverForm != nullptr) {
        serverForm->setFocus();
    }
}

void MainWindow::on_actionChat_Client_triggered()
{
    chatClient = new ChatClient(nullptr, chatClientID++);
    chatClient->move(1100, 400);
    chatClient ->show();
    connect(chatClient, SIGNAL(destroyed()), chatClient, SLOT(deleteLater()));

    /* connect 할 때 chatClient를 여러개 띄우면 그것들 중 하나만 login해도 나머지 한테도 전부
      시그널이 가기 때문에 chatClient마다 고유 ID를 부여해서 시그널을 보낼 때 id를 같이 보냅니다. */
    connect(chatClient, SIGNAL(sig_checkLogin(QString, int)), serverForm, SLOT(slot_checkLogin(QString, int)));
    connect(serverForm, SIGNAL(sig_checkLogin(int, int)), chatClient, SLOT(slot_login(int, int)));
}


