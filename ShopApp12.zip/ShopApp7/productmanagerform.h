#ifndef PRODUCTMANAGERFORM_H
#define PRODUCTMANAGERFORM_H

//#include "product.h"
#include <QWidget>

class Product;
class QMenu;
class QSqlDatabase;
class QSqlTableModel;
class QStandardItemModel;

namespace Ui { class ProductManagerForm; }

class ProductManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ProductManagerForm(QWidget *parent = nullptr);      // 생성자 (DB를 열 때)
    ~ProductManagerForm();                                       // 소멸자 (DB를 닫을 때)
    void headerName();                                           // 0~3열까지 헤더이름을 지정해주는 함수
    void loadData();                                             // DB 생성
    void clear();                                                // 초기화해주는 함수

private:
    int makeId();                                           // 제품 ID를 자동 할당해주는 함수
    Ui::ProductManagerForm *ui;                             // ProductManagerForm의 ui
    /* 멤버변수 */
    QMenu* menu;                                            // QMenu 클래스는 상황에 맞는 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel* productModel;                           // 제품 커리모델
    QStandardItemModel* searchModel;                        // 검색 커리모델

private slots:
    /* tableView를 위한 슬롯 */
    void removeItem();                                      // tableView에 있는 항목을 제거해주는 함수
    void showContextMenu(const QPoint &);                   // 오른쪽 마우스 버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수
    void on_tableView_clicked(const QModelIndex &index);    // tableView의 항목을 선택했을 때
    void on_addPushButton_clicked();                        // 제품을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작
    void on_modifyPushButton_clicked();                     // modify 버튼을 누르면 이미 추가된 제품 정보가 변경됩니다.
    void on_clearPushButton_clicked();                      // clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수
    void on_searchPushButton_clicked();                     // 제품 정보를 조회하고 싶을 때 Search 버튼을 누르면 조회하실 수 있습니다.
    /* Order에서 전달된 시그널을 구현하는 슬롯 */
    void slot_productData(QString);                 /* orderManagerForm의 productNameComboBox에서 선택한 제품 이름과
                                                       productManagerForm에 있는 제품 이름이 일치할 때 일치하는 제품 정보를 가지고 있는 슬롯 */
    void slot_sendProductNameSearch(QString);       /* orderManagerForm의 tableView에서 클릭한 주문 정보의 제품 이름과
                                                       ProductManagerForm에 있는 제품 이름이 일치할 때 일치하는 제품 정보를 가지고 있는 슬롯 */
    void slot_CalTotalPrice(QString, int);          /* orderManagerForm의 purchaseQuantitySpinBox의 값을 변경할 때 총 제품 가격을 계산해주는 슬롯 */
    void updateInventoryAmount(QString, int);       /* orderManagerForm에서 주문된 정보를 삭제하면 삭제된 제품의 이름과
                                                       productManagerForm의 제품 이름이 일치할 때 일치하는 제품의 재고 수량을 업데이트해주는 슬롯 */

signals:
    void productAdded(int, QString);                        // 추가한 제품 ID와 제품 이름을 [시그널:productAdded]로 전달합니다.
    void sig_sendRemovdProduct(int);                        // 제거된 인덱스의 행을 [시그널:sig_sendRemovdProduct]로 전달합니다.
    void sig_sendModifyProduct(int, QString);               // 인덱스의 행, 변경된 제품 이름을 [시그널:sig_sendModifyProduct]로 전달합니다.
    void productData(QStringList);                          // orderManagerForm에서 선택한 제품 이름과 일치하는 제품 정보를 [시그널:productData]로 전달합니다.
    void sig_sendProductNameSearch(QStringList);            /* orderManagerForm의 tableView에서 클릭한 주문 정보의 제품 이름과
                                                               일치하는 제품 정보를 [시그널:sig_sendProductNameSearch]로 전달합니다. */
    void sig_sendTotalPrice(int);                           // 계산한 총 구매 가격을 [시그널:sig_sendTotalPrice]로 전달합니다.
};

#endif // PRODUCTMANAGERFORM_H
