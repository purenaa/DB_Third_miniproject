/****************************************************************************
** Meta object code from reading C++ file 'ordermanagerform.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ShopApp7/ordermanagerform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ordermanagerform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_OrderManagerForm_t {
    uint offsetsAndSizes[68];
    char stringdata0[17];
    char stringdata1[23];
    char stringdata2[1];
    char stringdata3[28];
    char stringdata4[18];
    char stringdata5[20];
    char stringdata6[26];
    char stringdata7[12];
    char stringdata8[23];
    char stringdata9[19];
    char stringdata10[13];
    char stringdata11[11];
    char stringdata12[16];
    char stringdata13[25];
    char stringdata14[28];
    char stringdata15[28];
    char stringdata16[32];
    char stringdata17[17];
    char stringdata18[5];
    char stringdata19[7];
    char stringdata20[33];
    char stringdata21[11];
    char stringdata22[37];
    char stringdata23[14];
    char stringdata24[40];
    char stringdata25[27];
    char stringdata26[21];
    char stringdata27[12];
    char stringdata28[6];
    char stringdata29[17];
    char stringdata30[17];
    char stringdata31[17];
    char stringdata32[25];
    char stringdata33[26];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_OrderManagerForm_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_OrderManagerForm_t qt_meta_stringdata_OrderManagerForm = {
    {
        QT_MOC_LITERAL(0, 16),  // "OrderManagerForm"
        QT_MOC_LITERAL(17, 22),  // "sig_requesSearchClient"
        QT_MOC_LITERAL(40, 0),  // ""
        QT_MOC_LITERAL(41, 27),  // "sig_requesProductNameSearch"
        QT_MOC_LITERAL(69, 17),  // "sig_calTotalPrice"
        QT_MOC_LITERAL(87, 19),  // "sig_requestSearchID"
        QT_MOC_LITERAL(107, 25),  // "sig_reduceInventoryAmount"
        QT_MOC_LITERAL(133, 11),  // "productFind"
        QT_MOC_LITERAL(145, 22),  // "updateClientTreeWdiget"
        QT_MOC_LITERAL(168, 18),  // "QList<QStringList>"
        QT_MOC_LITERAL(187, 12),  // "updateClient"
        QT_MOC_LITERAL(200, 10),  // "removeItem"
        QT_MOC_LITERAL(211, 15),  // "showContextMenu"
        QT_MOC_LITERAL(227, 24),  // "on_addPushButton_clicked"
        QT_MOC_LITERAL(252, 27),  // "on_modifyPushButton_clicked"
        QT_MOC_LITERAL(280, 27),  // "on_searchPushButton_clicked"
        QT_MOC_LITERAL(308, 31),  // "on_clientTreeWidget_itemClicked"
        QT_MOC_LITERAL(340, 16),  // "QTreeWidgetItem*"
        QT_MOC_LITERAL(357, 4),  // "item"
        QT_MOC_LITERAL(362, 6),  // "column"
        QT_MOC_LITERAL(369, 32),  // "on_clientNameLineEdit_textEdited"
        QT_MOC_LITERAL(402, 10),  // "clientName"
        QT_MOC_LITERAL(413, 36),  // "on_productNameComboBox_textAc..."
        QT_MOC_LITERAL(450, 13),  // "updateProduct"
        QT_MOC_LITERAL(464, 39),  // "on_purchaseQuantitySpinBox_va..."
        QT_MOC_LITERAL(504, 26),  // "on_clearPushButton_clicked"
        QT_MOC_LITERAL(531, 20),  // "on_tableView_clicked"
        QT_MOC_LITERAL(552, 11),  // "QModelIndex"
        QT_MOC_LITERAL(564, 5),  // "index"
        QT_MOC_LITERAL(570, 16),  // "slot_productName"
        QT_MOC_LITERAL(587, 16),  // "slot_productInfo"
        QT_MOC_LITERAL(604, 16),  // "updateTotalPrice"
        QT_MOC_LITERAL(621, 24),  // "producNameComboBoxModify"
        QT_MOC_LITERAL(646, 25)   // "productNameComboBoxRemove"
    },
    "OrderManagerForm",
    "sig_requesSearchClient",
    "",
    "sig_requesProductNameSearch",
    "sig_calTotalPrice",
    "sig_requestSearchID",
    "sig_reduceInventoryAmount",
    "productFind",
    "updateClientTreeWdiget",
    "QList<QStringList>",
    "updateClient",
    "removeItem",
    "showContextMenu",
    "on_addPushButton_clicked",
    "on_modifyPushButton_clicked",
    "on_searchPushButton_clicked",
    "on_clientTreeWidget_itemClicked",
    "QTreeWidgetItem*",
    "item",
    "column",
    "on_clientNameLineEdit_textEdited",
    "clientName",
    "on_productNameComboBox_textActivated",
    "updateProduct",
    "on_purchaseQuantitySpinBox_valueChanged",
    "on_clearPushButton_clicked",
    "on_tableView_clicked",
    "QModelIndex",
    "index",
    "slot_productName",
    "slot_productInfo",
    "updateTotalPrice",
    "producNameComboBoxModify",
    "productNameComboBoxRemove"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OrderManagerForm[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  170,    2, 0x06,    1 /* Public */,
       3,    1,  173,    2, 0x06,    3 /* Public */,
       4,    2,  176,    2, 0x06,    5 /* Public */,
       4,    1,  181,    2, 0x26,    8 /* Public | MethodCloned */,
       5,    1,  184,    2, 0x06,   10 /* Public */,
       6,    2,  187,    2, 0x06,   12 /* Public */,
       7,    1,  192,    2, 0x06,   15 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    1,  195,    2, 0x08,   17 /* Private */,
      10,    1,  198,    2, 0x08,   19 /* Private */,
      11,    0,  201,    2, 0x08,   21 /* Private */,
      12,    1,  202,    2, 0x08,   22 /* Private */,
      13,    0,  205,    2, 0x08,   24 /* Private */,
      14,    0,  206,    2, 0x08,   25 /* Private */,
      15,    0,  207,    2, 0x08,   26 /* Private */,
      16,    2,  208,    2, 0x08,   27 /* Private */,
      20,    1,  213,    2, 0x08,   30 /* Private */,
      22,    1,  216,    2, 0x08,   32 /* Private */,
      23,    1,  219,    2, 0x08,   34 /* Private */,
      24,    1,  222,    2, 0x08,   36 /* Private */,
      25,    0,  225,    2, 0x08,   38 /* Private */,
      26,    1,  226,    2, 0x08,   39 /* Private */,
      29,    2,  229,    2, 0x08,   41 /* Private */,
      30,    1,  234,    2, 0x08,   44 /* Private */,
      31,    1,  237,    2, 0x08,   46 /* Private */,
      32,    3,  240,    2, 0x08,   48 /* Private */,
      33,    1,  247,    2, 0x08,   52 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 17, QMetaType::Int,   18,   19,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 27,   28,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

void OrderManagerForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<OrderManagerForm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sig_requesSearchClient((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 1: _t->sig_requesProductNameSearch((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->sig_calTotalPrice((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 3: _t->sig_calTotalPrice((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->sig_requestSearchID((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->sig_reduceInventoryAmount((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 6: _t->productFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->updateClientTreeWdiget((*reinterpret_cast< std::add_pointer_t<QList<QStringList>>>(_a[1]))); break;
        case 8: _t->updateClient((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 9: _t->removeItem(); break;
        case 10: _t->showContextMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 11: _t->on_addPushButton_clicked(); break;
        case 12: _t->on_modifyPushButton_clicked(); break;
        case 13: _t->on_searchPushButton_clicked(); break;
        case 14: _t->on_clientTreeWidget_itemClicked((*reinterpret_cast< std::add_pointer_t<QTreeWidgetItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 15: _t->on_clientNameLineEdit_textEdited((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 16: _t->on_productNameComboBox_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 17: _t->updateProduct((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 18: _t->on_purchaseQuantitySpinBox_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->on_clearPushButton_clicked(); break;
        case 20: _t->on_tableView_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 21: _t->slot_productName((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 22: _t->slot_productInfo((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 23: _t->updateTotalPrice((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 24: _t->producNameComboBoxModify((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 25: _t->productNameComboBoxRemove((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<QStringList> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::sig_requesSearchClient; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::sig_requesProductNameSearch; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString , int );
            if (_t _q_method = &OrderManagerForm::sig_calTotalPrice; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(int );
            if (_t _q_method = &OrderManagerForm::sig_requestSearchID; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString , int );
            if (_t _q_method = &OrderManagerForm::sig_reduceInventoryAmount; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::productFind; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject OrderManagerForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_OrderManagerForm.offsetsAndSizes,
    qt_meta_data_OrderManagerForm,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_OrderManagerForm_t
, QtPrivate::TypeAndForceComplete<OrderManagerForm, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QStringList>, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QTreeWidgetItem *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *OrderManagerForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OrderManagerForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_OrderManagerForm.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int OrderManagerForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    }
    return _id;
}

// SIGNAL 0
void OrderManagerForm::sig_requesSearchClient(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void OrderManagerForm::sig_requesProductNameSearch(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void OrderManagerForm::sig_calTotalPrice(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 4
void OrderManagerForm::sig_requestSearchID(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void OrderManagerForm::sig_reduceInventoryAmount(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void OrderManagerForm::productFind(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
