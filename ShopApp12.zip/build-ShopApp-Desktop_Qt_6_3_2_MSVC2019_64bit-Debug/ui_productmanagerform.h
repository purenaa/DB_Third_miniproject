/********************************************************************************
** Form generated from reading UI file 'productmanagerform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTMANAGERFORM_H
#define UI_PRODUCTMANAGERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProductManagerForm
{
public:
    QVBoxLayout *verticalLayout_7;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QLabel *productInfoLabel;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *inputPage;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_4;
    QFormLayout *formLayout;
    QLabel *productIDLabel;
    QLineEdit *productIDLineEdit;
    QLabel *productNameLabel;
    QLineEdit *productNameLineEdit;
    QLabel *priceLabel;
    QLineEdit *priceLineEdit;
    QLabel *inventoryAmountLabel;
    QSpinBox *inventoryAmountSpinBox;
    QVBoxLayout *verticalLayout;
    QSpacerItem *verticalSpacer_2;
    QLabel *imageLabel;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addPushButton;
    QPushButton *modifyPushButton;
    QPushButton *clearPushButton;
    QWidget *searchPage;
    QVBoxLayout *verticalLayout_6;
    QVBoxLayout *verticalLayout_2;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout;
    QComboBox *searchComboBox;
    QLineEdit *searchLineEdit;
    QPushButton *searchPushButton;

    void setupUi(QWidget *ProductManagerForm)
    {
        if (ProductManagerForm->objectName().isEmpty())
            ProductManagerForm->setObjectName(QString::fromUtf8("ProductManagerForm"));
        ProductManagerForm->resize(517, 339);
        verticalLayout_7 = new QVBoxLayout(ProductManagerForm);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        splitter = new QSplitter(ProductManagerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        productInfoLabel = new QLabel(layoutWidget);
        productInfoLabel->setObjectName(QString::fromUtf8("productInfoLabel"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Dubai")});
        font.setPointSize(20);
        font.setBold(true);
        productInfoLabel->setFont(font);

        verticalLayout_3->addWidget(productInfoLabel);

        tableView = new QTableView(layoutWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_3->addWidget(tableView);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        inputPage = new QWidget();
        inputPage->setObjectName(QString::fromUtf8("inputPage"));
        inputPage->setGeometry(QRect(0, 0, 264, 269));
        verticalLayout_5 = new QVBoxLayout(inputPage);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        productIDLabel = new QLabel(inputPage);
        productIDLabel->setObjectName(QString::fromUtf8("productIDLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, productIDLabel);

        productIDLineEdit = new QLineEdit(inputPage);
        productIDLineEdit->setObjectName(QString::fromUtf8("productIDLineEdit"));
        productIDLineEdit->setEnabled(false);
        productIDLineEdit->setReadOnly(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, productIDLineEdit);

        productNameLabel = new QLabel(inputPage);
        productNameLabel->setObjectName(QString::fromUtf8("productNameLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, productNameLabel);

        productNameLineEdit = new QLineEdit(inputPage);
        productNameLineEdit->setObjectName(QString::fromUtf8("productNameLineEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, productNameLineEdit);

        priceLabel = new QLabel(inputPage);
        priceLabel->setObjectName(QString::fromUtf8("priceLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, priceLabel);

        priceLineEdit = new QLineEdit(inputPage);
        priceLineEdit->setObjectName(QString::fromUtf8("priceLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, priceLineEdit);

        inventoryAmountLabel = new QLabel(inputPage);
        inventoryAmountLabel->setObjectName(QString::fromUtf8("inventoryAmountLabel"));

        formLayout->setWidget(3, QFormLayout::LabelRole, inventoryAmountLabel);

        inventoryAmountSpinBox = new QSpinBox(inputPage);
        inventoryAmountSpinBox->setObjectName(QString::fromUtf8("inventoryAmountSpinBox"));
        inventoryAmountSpinBox->setMaximum(1000);

        formLayout->setWidget(3, QFormLayout::FieldRole, inventoryAmountSpinBox);


        verticalLayout_4->addLayout(formLayout);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalSpacer_2 = new QSpacerItem(160, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        imageLabel = new QLabel(inputPage);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));

        verticalLayout->addWidget(imageLabel);

        verticalSpacer = new QSpacerItem(160, 17, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);


        verticalLayout_4->addLayout(verticalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        addPushButton = new QPushButton(inputPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        horizontalLayout_2->addWidget(addPushButton);

        modifyPushButton = new QPushButton(inputPage);
        modifyPushButton->setObjectName(QString::fromUtf8("modifyPushButton"));

        horizontalLayout_2->addWidget(modifyPushButton);

        clearPushButton = new QPushButton(inputPage);
        clearPushButton->setObjectName(QString::fromUtf8("clearPushButton"));

        horizontalLayout_2->addWidget(clearPushButton);


        verticalLayout_4->addLayout(horizontalLayout_2);


        verticalLayout_5->addLayout(verticalLayout_4);

        toolBox->addItem(inputPage, QString::fromUtf8("Input"));
        searchPage = new QWidget();
        searchPage->setObjectName(QString::fromUtf8("searchPage"));
        searchPage->setGeometry(QRect(0, 0, 256, 279));
        verticalLayout_6 = new QVBoxLayout(searchPage);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        searchTableView = new QTableView(searchPage);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        searchTableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_2->addWidget(searchTableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchComboBox = new QComboBox(searchPage);
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->setObjectName(QString::fromUtf8("searchComboBox"));

        horizontalLayout->addWidget(searchComboBox);

        searchLineEdit = new QLineEdit(searchPage);
        searchLineEdit->setObjectName(QString::fromUtf8("searchLineEdit"));

        horizontalLayout->addWidget(searchLineEdit);


        verticalLayout_2->addLayout(horizontalLayout);

        searchPushButton = new QPushButton(searchPage);
        searchPushButton->setObjectName(QString::fromUtf8("searchPushButton"));

        verticalLayout_2->addWidget(searchPushButton);


        verticalLayout_6->addLayout(verticalLayout_2);

        toolBox->addItem(searchPage, QString::fromUtf8("Search"));
        splitter->addWidget(toolBox);

        verticalLayout_7->addWidget(splitter);

#if QT_CONFIG(shortcut)
        productIDLabel->setBuddy(productIDLineEdit);
        productNameLabel->setBuddy(productNameLineEdit);
        priceLabel->setBuddy(priceLineEdit);
        inventoryAmountLabel->setBuddy(inventoryAmountSpinBox);
#endif // QT_CONFIG(shortcut)

        retranslateUi(ProductManagerForm);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ProductManagerForm);
    } // setupUi

    void retranslateUi(QWidget *ProductManagerForm)
    {
        ProductManagerForm->setWindowTitle(QCoreApplication::translate("ProductManagerForm", "Form", nullptr));
        productInfoLabel->setText(QCoreApplication::translate("ProductManagerForm", "Product Information", nullptr));
        productIDLabel->setText(QCoreApplication::translate("ProductManagerForm", "&Product ID", nullptr));
        productNameLabel->setText(QCoreApplication::translate("ProductManagerForm", "Product &Name", nullptr));
        priceLabel->setText(QCoreApplication::translate("ProductManagerForm", "P&rice", nullptr));
        inventoryAmountLabel->setText(QCoreApplication::translate("ProductManagerForm", "&Inventory Amount", nullptr));
        imageLabel->setText(QString());
        addPushButton->setText(QCoreApplication::translate("ProductManagerForm", "Add", nullptr));
        modifyPushButton->setText(QCoreApplication::translate("ProductManagerForm", "Modify", nullptr));
        clearPushButton->setText(QCoreApplication::translate("ProductManagerForm", "Clear", nullptr));
        toolBox->setItemText(toolBox->indexOf(inputPage), QCoreApplication::translate("ProductManagerForm", "Input", nullptr));
        searchComboBox->setItemText(0, QCoreApplication::translate("ProductManagerForm", "Product ID Search", nullptr));
        searchComboBox->setItemText(1, QCoreApplication::translate("ProductManagerForm", "Product Name Search", nullptr));
        searchComboBox->setItemText(2, QCoreApplication::translate("ProductManagerForm", "Price Search", nullptr));
        searchComboBox->setItemText(3, QCoreApplication::translate("ProductManagerForm", "Inventory Amount Search", nullptr));

        searchPushButton->setText(QCoreApplication::translate("ProductManagerForm", "Search", nullptr));
        toolBox->setItemText(toolBox->indexOf(searchPage), QCoreApplication::translate("ProductManagerForm", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProductManagerForm: public Ui_ProductManagerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTMANAGERFORM_H
