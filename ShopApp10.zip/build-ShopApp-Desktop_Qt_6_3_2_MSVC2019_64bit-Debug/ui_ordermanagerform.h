/********************************************************************************
** Form generated from reading UI file 'ordermanagerform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ORDERMANAGERFORM_H
#define UI_ORDERMANAGERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OrderManagerForm
{
public:
    QVBoxLayout *verticalLayout_5;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *orderInfoLabel;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *inputPage;
    QVBoxLayout *verticalLayout_3;
    QFormLayout *formLayout;
    QLabel *purchaseDayLabel;
    QDateEdit *purchaseDayDateEdit;
    QLabel *orderIDLablel;
    QLineEdit *orderIDLineEdit;
    QLabel *clientNameLabel;
    QLineEdit *clientNameLineEdit;
    QLabel *productNameLabel;
    QComboBox *productNameComboBox;
    QLabel *purchaseQuantityLabel;
    QSpinBox *purchaseQuantitySpinBox;
    QLabel *totalPriceLabel;
    QLineEdit *totalPriceLineEdit;
    QLabel *clientInforLabel;
    QTreeWidget *clientTreeWidget;
    QLabel *productInfoLabel;
    QSplitter *splitter_2;
    QTreeWidget *productTreeWidget;
    QLabel *imageLabel;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addPushButton;
    QPushButton *modifyPushButton;
    QPushButton *clearPushButton;
    QWidget *searchPage;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout;
    QComboBox *searchComboBox;
    QLineEdit *searchLineEdit;
    QPushButton *searchPushButton;

    void setupUi(QWidget *OrderManagerForm)
    {
        if (OrderManagerForm->objectName().isEmpty())
            OrderManagerForm->setObjectName(QString::fromUtf8("OrderManagerForm"));
        OrderManagerForm->resize(504, 483);
        verticalLayout_5 = new QVBoxLayout(OrderManagerForm);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        splitter = new QSplitter(OrderManagerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        orderInfoLabel = new QLabel(layoutWidget);
        orderInfoLabel->setObjectName(QString::fromUtf8("orderInfoLabel"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Dubai")});
        font.setPointSize(20);
        font.setBold(true);
        orderInfoLabel->setFont(font);

        verticalLayout_2->addWidget(orderInfoLabel);

        tableView = new QTableView(layoutWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_2->addWidget(tableView);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        inputPage = new QWidget();
        inputPage->setObjectName(QString::fromUtf8("inputPage"));
        inputPage->setGeometry(QRect(0, 0, 262, 413));
        verticalLayout_3 = new QVBoxLayout(inputPage);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        purchaseDayLabel = new QLabel(inputPage);
        purchaseDayLabel->setObjectName(QString::fromUtf8("purchaseDayLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, purchaseDayLabel);

        purchaseDayDateEdit = new QDateEdit(inputPage);
        purchaseDayDateEdit->setObjectName(QString::fromUtf8("purchaseDayDateEdit"));
        purchaseDayDateEdit->setEnabled(true);
        purchaseDayDateEdit->setReadOnly(false);
        purchaseDayDateEdit->setDateTime(QDateTime(QDate(2022, 10, 10), QTime(3, 0, 0)));
        purchaseDayDateEdit->setCalendarPopup(false);

        formLayout->setWidget(0, QFormLayout::FieldRole, purchaseDayDateEdit);

        orderIDLablel = new QLabel(inputPage);
        orderIDLablel->setObjectName(QString::fromUtf8("orderIDLablel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, orderIDLablel);

        orderIDLineEdit = new QLineEdit(inputPage);
        orderIDLineEdit->setObjectName(QString::fromUtf8("orderIDLineEdit"));
        orderIDLineEdit->setEnabled(false);
        orderIDLineEdit->setReadOnly(true);

        formLayout->setWidget(1, QFormLayout::FieldRole, orderIDLineEdit);

        clientNameLabel = new QLabel(inputPage);
        clientNameLabel->setObjectName(QString::fromUtf8("clientNameLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, clientNameLabel);

        clientNameLineEdit = new QLineEdit(inputPage);
        clientNameLineEdit->setObjectName(QString::fromUtf8("clientNameLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, clientNameLineEdit);

        productNameLabel = new QLabel(inputPage);
        productNameLabel->setObjectName(QString::fromUtf8("productNameLabel"));

        formLayout->setWidget(3, QFormLayout::LabelRole, productNameLabel);

        productNameComboBox = new QComboBox(inputPage);
        productNameComboBox->setObjectName(QString::fromUtf8("productNameComboBox"));

        formLayout->setWidget(3, QFormLayout::FieldRole, productNameComboBox);

        purchaseQuantityLabel = new QLabel(inputPage);
        purchaseQuantityLabel->setObjectName(QString::fromUtf8("purchaseQuantityLabel"));

        formLayout->setWidget(4, QFormLayout::LabelRole, purchaseQuantityLabel);

        purchaseQuantitySpinBox = new QSpinBox(inputPage);
        purchaseQuantitySpinBox->setObjectName(QString::fromUtf8("purchaseQuantitySpinBox"));

        formLayout->setWidget(4, QFormLayout::FieldRole, purchaseQuantitySpinBox);

        totalPriceLabel = new QLabel(inputPage);
        totalPriceLabel->setObjectName(QString::fromUtf8("totalPriceLabel"));

        formLayout->setWidget(5, QFormLayout::LabelRole, totalPriceLabel);

        totalPriceLineEdit = new QLineEdit(inputPage);
        totalPriceLineEdit->setObjectName(QString::fromUtf8("totalPriceLineEdit"));

        formLayout->setWidget(5, QFormLayout::FieldRole, totalPriceLineEdit);


        verticalLayout_3->addLayout(formLayout);

        clientInforLabel = new QLabel(inputPage);
        clientInforLabel->setObjectName(QString::fromUtf8("clientInforLabel"));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Dubai")});
        font1.setPointSize(16);
        font1.setBold(true);
        clientInforLabel->setFont(font1);

        verticalLayout_3->addWidget(clientInforLabel);

        clientTreeWidget = new QTreeWidget(inputPage);
        clientTreeWidget->setObjectName(QString::fromUtf8("clientTreeWidget"));

        verticalLayout_3->addWidget(clientTreeWidget);

        productInfoLabel = new QLabel(inputPage);
        productInfoLabel->setObjectName(QString::fromUtf8("productInfoLabel"));
        productInfoLabel->setFont(font1);

        verticalLayout_3->addWidget(productInfoLabel);

        splitter_2 = new QSplitter(inputPage);
        splitter_2->setObjectName(QString::fromUtf8("splitter_2"));
        splitter_2->setOrientation(Qt::Horizontal);
        productTreeWidget = new QTreeWidget(splitter_2);
        productTreeWidget->headerItem()->setText(3, QString());
        QTreeWidgetItem *__qtreewidgetitem = new QTreeWidgetItem();
        __qtreewidgetitem->setText(0, QString::fromUtf8("Product Name"));
        productTreeWidget->setHeaderItem(__qtreewidgetitem);
        productTreeWidget->setObjectName(QString::fromUtf8("productTreeWidget"));
        splitter_2->addWidget(productTreeWidget);
        imageLabel = new QLabel(splitter_2);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        splitter_2->addWidget(imageLabel);

        verticalLayout_3->addWidget(splitter_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        addPushButton = new QPushButton(inputPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        horizontalLayout_2->addWidget(addPushButton);

        modifyPushButton = new QPushButton(inputPage);
        modifyPushButton->setObjectName(QString::fromUtf8("modifyPushButton"));

        horizontalLayout_2->addWidget(modifyPushButton);

        clearPushButton = new QPushButton(inputPage);
        clearPushButton->setObjectName(QString::fromUtf8("clearPushButton"));

        horizontalLayout_2->addWidget(clearPushButton);


        verticalLayout_3->addLayout(horizontalLayout_2);

        toolBox->addItem(inputPage, QString::fromUtf8("Input"));
        searchPage = new QWidget();
        searchPage->setObjectName(QString::fromUtf8("searchPage"));
        searchPage->setGeometry(QRect(0, 0, 249, 438));
        verticalLayout_4 = new QVBoxLayout(searchPage);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        searchTableView = new QTableView(searchPage);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        searchTableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout->addWidget(searchTableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchComboBox = new QComboBox(searchPage);
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->setObjectName(QString::fromUtf8("searchComboBox"));

        horizontalLayout->addWidget(searchComboBox);

        searchLineEdit = new QLineEdit(searchPage);
        searchLineEdit->setObjectName(QString::fromUtf8("searchLineEdit"));

        horizontalLayout->addWidget(searchLineEdit);


        verticalLayout->addLayout(horizontalLayout);

        searchPushButton = new QPushButton(searchPage);
        searchPushButton->setObjectName(QString::fromUtf8("searchPushButton"));

        verticalLayout->addWidget(searchPushButton);


        verticalLayout_4->addLayout(verticalLayout);

        toolBox->addItem(searchPage, QString::fromUtf8("Search"));
        splitter->addWidget(toolBox);

        verticalLayout_5->addWidget(splitter);

#if QT_CONFIG(shortcut)
        purchaseDayLabel->setBuddy(purchaseDayDateEdit);
        orderIDLablel->setBuddy(orderIDLineEdit);
        clientNameLabel->setBuddy(clientNameLineEdit);
        productNameLabel->setBuddy(productNameComboBox);
        purchaseQuantityLabel->setBuddy(purchaseQuantitySpinBox);
        totalPriceLabel->setBuddy(totalPriceLineEdit);
#endif // QT_CONFIG(shortcut)

        retranslateUi(OrderManagerForm);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(OrderManagerForm);
    } // setupUi

    void retranslateUi(QWidget *OrderManagerForm)
    {
        OrderManagerForm->setWindowTitle(QCoreApplication::translate("OrderManagerForm", "Form", nullptr));
        orderInfoLabel->setText(QCoreApplication::translate("OrderManagerForm", "Order Information", nullptr));
        purchaseDayLabel->setText(QCoreApplication::translate("OrderManagerForm", "Purchase &Day", nullptr));
        orderIDLablel->setText(QCoreApplication::translate("OrderManagerForm", "&Order ID", nullptr));
        clientNameLabel->setText(QCoreApplication::translate("OrderManagerForm", "&Client Name", nullptr));
        productNameLabel->setText(QCoreApplication::translate("OrderManagerForm", "Product Name", nullptr));
        purchaseQuantityLabel->setText(QCoreApplication::translate("OrderManagerForm", "Purchase &Quantity", nullptr));
        totalPriceLabel->setText(QCoreApplication::translate("OrderManagerForm", "Tota&l Price", nullptr));
        clientInforLabel->setText(QCoreApplication::translate("OrderManagerForm", "Client Information", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = clientTreeWidget->headerItem();
        ___qtreewidgetitem->setText(4, QCoreApplication::translate("OrderManagerForm", "Email", nullptr));
        ___qtreewidgetitem->setText(3, QCoreApplication::translate("OrderManagerForm", "Address", nullptr));
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("OrderManagerForm", "Phone Number", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("OrderManagerForm", "Client Name", nullptr));
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("OrderManagerForm", "Client ID", nullptr));
        productInfoLabel->setText(QCoreApplication::translate("OrderManagerForm", "Product Information", nullptr));
        QTreeWidgetItem *___qtreewidgetitem1 = productTreeWidget->headerItem();
        ___qtreewidgetitem1->setText(2, QCoreApplication::translate("OrderManagerForm", "Inventory Amount", nullptr));
        ___qtreewidgetitem1->setText(1, QCoreApplication::translate("OrderManagerForm", "Price", nullptr));
        imageLabel->setText(QCoreApplication::translate("OrderManagerForm", "image", nullptr));
        addPushButton->setText(QCoreApplication::translate("OrderManagerForm", "Add", nullptr));
        modifyPushButton->setText(QCoreApplication::translate("OrderManagerForm", "Modify", nullptr));
        clearPushButton->setText(QCoreApplication::translate("OrderManagerForm", "Clear", nullptr));
        toolBox->setItemText(toolBox->indexOf(inputPage), QCoreApplication::translate("OrderManagerForm", "Input", nullptr));
        searchComboBox->setItemText(0, QCoreApplication::translate("OrderManagerForm", "Order ID Check", nullptr));
        searchComboBox->setItemText(1, QCoreApplication::translate("OrderManagerForm", "Purchase Day Check", nullptr));
        searchComboBox->setItemText(2, QCoreApplication::translate("OrderManagerForm", "Client ID", nullptr));
        searchComboBox->setItemText(3, QCoreApplication::translate("OrderManagerForm", "Client Name Check", nullptr));
        searchComboBox->setItemText(4, QCoreApplication::translate("OrderManagerForm", "Product Name Check", nullptr));
        searchComboBox->setItemText(5, QCoreApplication::translate("OrderManagerForm", "Purchase Quantity Check", nullptr));
        searchComboBox->setItemText(6, QCoreApplication::translate("OrderManagerForm", "Total Price Check", nullptr));

        searchPushButton->setText(QCoreApplication::translate("OrderManagerForm", "Search", nullptr));
        toolBox->setItemText(toolBox->indexOf(searchPage), QCoreApplication::translate("OrderManagerForm", "Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OrderManagerForm: public Ui_OrderManagerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ORDERMANAGERFORM_H
