/****************************************************************************
** Meta object code from reading C++ file 'clientserverform.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ShopApp7/clientserverform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'clientserverform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ClientServerForm_t {
    uint offsetsAndSizes[34];
    char stringdata0[17];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[10];
    char stringdata4[24];
    char stringdata5[17];
    char stringdata6[11];
    char stringdata7[14];
    char stringdata8[12];
    char stringdata9[13];
    char stringdata10[13];
    char stringdata11[8];
    char stringdata12[47];
    char stringdata13[4];
    char stringdata14[16];
    char stringdata15[22];
    char stringdata16[27];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_ClientServerForm_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_ClientServerForm_t qt_meta_stringdata_ClientServerForm = {
    {
        QT_MOC_LITERAL(0, 16),  // "ClientServerForm"
        QT_MOC_LITERAL(17, 14),  // "sig_checkLogin"
        QT_MOC_LITERAL(32, 0),  // ""
        QT_MOC_LITERAL(33, 9),  // "addClient"
        QT_MOC_LITERAL(43, 23),  // "slot_updateModifyClient"
        QT_MOC_LITERAL(67, 16),  // "acceptConnection"
        QT_MOC_LITERAL(84, 10),  // "readClient"
        QT_MOC_LITERAL(95, 13),  // "clientConnect"
        QT_MOC_LITERAL(109, 11),  // "receiveData"
        QT_MOC_LITERAL(121, 12),  // "removeClient"
        QT_MOC_LITERAL(134, 12),  // "inviteClient"
        QT_MOC_LITERAL(147, 7),  // "kickOut"
        QT_MOC_LITERAL(155, 46),  // "on_clientTreeWidget_customCon..."
        QT_MOC_LITERAL(202, 3),  // "pos"
        QT_MOC_LITERAL(206, 15),  // "slot_checkLogin"
        QT_MOC_LITERAL(222, 21),  // "slot_updateClientInfo"
        QT_MOC_LITERAL(244, 26)   // "on_clearPushButton_clicked"
    },
    "ClientServerForm",
    "sig_checkLogin",
    "",
    "addClient",
    "slot_updateModifyClient",
    "acceptConnection",
    "readClient",
    "clientConnect",
    "receiveData",
    "removeClient",
    "inviteClient",
    "kickOut",
    "on_clientTreeWidget_customContextMenuRequested",
    "pos",
    "slot_checkLogin",
    "slot_updateClientInfo",
    "on_clearPushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ClientServerForm[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,   98,    2, 0x06,    1 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       3,    2,  103,    2, 0x08,    4 /* Private */,
       4,    3,  108,    2, 0x08,    7 /* Private */,
       5,    0,  115,    2, 0x08,   11 /* Private */,
       6,    0,  116,    2, 0x08,   12 /* Private */,
       7,    0,  117,    2, 0x08,   13 /* Private */,
       8,    0,  118,    2, 0x08,   14 /* Private */,
       9,    0,  119,    2, 0x08,   15 /* Private */,
      10,    0,  120,    2, 0x08,   16 /* Private */,
      11,    0,  121,    2, 0x08,   17 /* Private */,
      12,    1,  122,    2, 0x08,   18 /* Private */,
      14,    2,  125,    2, 0x08,   20 /* Private */,
      15,    1,  130,    2, 0x08,   23 /* Private */,
      16,    0,  133,    2, 0x08,   25 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString,    2,    2,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   13,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,

       0        // eod
};

void ClientServerForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ClientServerForm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sig_checkLogin((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 1: _t->addClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 2: _t->slot_updateModifyClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[3]))); break;
        case 3: _t->acceptConnection(); break;
        case 4: _t->readClient(); break;
        case 5: _t->clientConnect(); break;
        case 6: _t->receiveData(); break;
        case 7: _t->removeClient(); break;
        case 8: _t->inviteClient(); break;
        case 9: _t->kickOut(); break;
        case 10: _t->on_clientTreeWidget_customContextMenuRequested((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 11: _t->slot_checkLogin((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 12: _t->slot_updateClientInfo((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 13: _t->on_clearPushButton_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ClientServerForm::*)(int , int );
            if (_t _q_method = &ClientServerForm::sig_checkLogin; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject ClientServerForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ClientServerForm.offsetsAndSizes,
    qt_meta_data_ClientServerForm,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_ClientServerForm_t
, QtPrivate::TypeAndForceComplete<ClientServerForm, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *ClientServerForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ClientServerForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ClientServerForm.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ClientServerForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void ClientServerForm::sig_checkLogin(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
