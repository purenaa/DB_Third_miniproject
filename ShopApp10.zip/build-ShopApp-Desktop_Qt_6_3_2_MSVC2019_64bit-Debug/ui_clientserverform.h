/********************************************************************************
** Form generated from reading UI file 'clientserverform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTSERVERFORM_H
#define UI_CLIENTSERVERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClientServerForm
{
public:
    QHBoxLayout *horizontalLayout_2;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *clientListVerticalLayout;
    QLabel *clientListLabel;
    QTreeWidget *clientTreeWidget;
    QHBoxLayout *horizontalLayout;
    QWidget *layoutWidget_2;
    QVBoxLayout *messageVerticalLayout;
    QTreeWidget *messageTreeWidget;
    QHBoxLayout *messageLayout;
    QPushButton *clearPushButton;
    QPushButton *savePushButton;

    void setupUi(QWidget *ClientServerForm)
    {
        if (ClientServerForm->objectName().isEmpty())
            ClientServerForm->setObjectName(QString::fromUtf8("ClientServerForm"));
        ClientServerForm->resize(389, 307);
        horizontalLayout_2 = new QHBoxLayout(ClientServerForm);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        splitter = new QSplitter(ClientServerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        clientListVerticalLayout = new QVBoxLayout(layoutWidget);
        clientListVerticalLayout->setObjectName(QString::fromUtf8("clientListVerticalLayout"));
        clientListVerticalLayout->setContentsMargins(0, 0, 0, 0);
        clientListLabel = new QLabel(layoutWidget);
        clientListLabel->setObjectName(QString::fromUtf8("clientListLabel"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Dubai")});
        font.setPointSize(20);
        font.setBold(true);
        clientListLabel->setFont(font);

        clientListVerticalLayout->addWidget(clientListLabel);

        clientTreeWidget = new QTreeWidget(layoutWidget);
        clientTreeWidget->setObjectName(QString::fromUtf8("clientTreeWidget"));
        clientTreeWidget->setTabletTracking(false);
        clientTreeWidget->setSelectionBehavior(QAbstractItemView::SelectItems);
        clientTreeWidget->setRootIsDecorated(false);
        clientTreeWidget->setHeaderHidden(true);

        clientListVerticalLayout->addWidget(clientTreeWidget);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));

        clientListVerticalLayout->addLayout(horizontalLayout);

        splitter->addWidget(layoutWidget);
        layoutWidget_2 = new QWidget(splitter);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        messageVerticalLayout = new QVBoxLayout(layoutWidget_2);
        messageVerticalLayout->setObjectName(QString::fromUtf8("messageVerticalLayout"));
        messageVerticalLayout->setContentsMargins(0, 0, 0, 0);
        messageTreeWidget = new QTreeWidget(layoutWidget_2);
        messageTreeWidget->setObjectName(QString::fromUtf8("messageTreeWidget"));
        messageTreeWidget->setRootIsDecorated(false);
        messageTreeWidget->setWordWrap(true);

        messageVerticalLayout->addWidget(messageTreeWidget);

        messageLayout = new QHBoxLayout();
        messageLayout->setObjectName(QString::fromUtf8("messageLayout"));
        clearPushButton = new QPushButton(layoutWidget_2);
        clearPushButton->setObjectName(QString::fromUtf8("clearPushButton"));

        messageLayout->addWidget(clearPushButton);

        savePushButton = new QPushButton(layoutWidget_2);
        savePushButton->setObjectName(QString::fromUtf8("savePushButton"));

        messageLayout->addWidget(savePushButton);


        messageVerticalLayout->addLayout(messageLayout);

        splitter->addWidget(layoutWidget_2);

        horizontalLayout_2->addWidget(splitter);


        retranslateUi(ClientServerForm);

        QMetaObject::connectSlotsByName(ClientServerForm);
    } // setupUi

    void retranslateUi(QWidget *ClientServerForm)
    {
        ClientServerForm->setWindowTitle(QCoreApplication::translate("ClientServerForm", "Form", nullptr));
        clientListLabel->setText(QCoreApplication::translate("ClientServerForm", "Client Connection", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = clientTreeWidget->headerItem();
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("ClientServerForm", "hideColumn", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("ClientServerForm", "Name", nullptr));
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("ClientServerForm", "Status", nullptr));
        QTreeWidgetItem *___qtreewidgetitem1 = messageTreeWidget->headerItem();
        ___qtreewidgetitem1->setText(5, QCoreApplication::translate("ClientServerForm", "Time", nullptr));
        ___qtreewidgetitem1->setText(4, QCoreApplication::translate("ClientServerForm", "Message", nullptr));
        ___qtreewidgetitem1->setText(3, QCoreApplication::translate("ClientServerForm", "Client Name", nullptr));
        ___qtreewidgetitem1->setText(2, QCoreApplication::translate("ClientServerForm", "Client ID", nullptr));
        ___qtreewidgetitem1->setText(1, QCoreApplication::translate("ClientServerForm", "Port", nullptr));
        ___qtreewidgetitem1->setText(0, QCoreApplication::translate("ClientServerForm", "IP", nullptr));
        clearPushButton->setText(QCoreApplication::translate("ClientServerForm", "Clear", nullptr));
        savePushButton->setText(QCoreApplication::translate("ClientServerForm", "Save", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ClientServerForm: public Ui_ClientServerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTSERVERFORM_H
