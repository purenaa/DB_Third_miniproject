#include "mainwindow.h"
#include "chatclient.h"
#include "qobjectdefs.h"
#include "ui_mainwindow.h"
#include "clientmanagerform.h"
#include "productmanagerform.h"
#include "ordermanagerform.h"
#include "clientserverform.h"
#include "chatclient.h"

#include <QMdiSubWindow>
#include <QSqlDatabase>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , chatClientID(0)
{
    ui->setupUi(this);

    orderForm = new OrderManagerForm(this);
    orderForm->setWindowTitle(tr("Order Info"));
    connect(orderForm, SIGNAL(destroyed()), orderForm, SLOT(deleteLater()));

    serverForm = new ClientServerForm(this);
    serverForm->setWindowTitle(tr("Chatting Server"));

    clientForm = new ClientManagerForm(this);
    connect(clientForm, SIGNAL(destroyed()), clientForm, SLOT(deleteLater()));
    clientForm->setWindowTitle(tr("Client Info"));

    productForm = new ProductManagerForm(this);
    productForm->setWindowTitle(tr("Product Info"));
    connect(productForm, SIGNAL(destroyed()), productForm, SLOT(deleteLater()));

    /* Client -> Server */
    connect(clientForm, SIGNAL(clientAdded(int, QString)), serverForm, SLOT(addClient(int, QString)));  //3
    connect(clientForm, SIGNAL(sig_sendClientInfo(QString)), serverForm, SLOT(slot_updateClientInfo(QString))); //11
    connect(clientForm, SIGNAL(sig_sendModifyClient(int, int, QString)), serverForm, SLOT(slot_updateModifyClient(int, int, QString)));     //12

    /* Order -> Client , Clinet -> Order */
    connect(orderForm, SIGNAL(sig_requesSearchClient(QString)), clientForm, SLOT(sendSearchedClient(QString)));   //4
    connect(clientForm, SIGNAL(sig_sendSearchedClient(QList<QStringList>)), orderForm, SLOT(updateClientTreeWdiget(QList<QStringList>)));   //5

    /* Order -> Product, Product -> Order */
//    connect(orderForm, SIGNAL(sig_requestProductNames()), productForm, SLOT(slot_getProductNames()));     //1
//    connect(productForm, SIGNAL(sig_getProductNames(QList<QString>)), orderForm, SLOT(update(QList<QString>)));    //2

    //위에꺼 대신 구현한 시그널 슬롯
    /*Product -> Order */  /*product의 제품 정보를 Order의 productNameComboBox에서 제품 이름을 출력*/
    connect(productForm, SIGNAL(productAdded(int, QString)), orderForm, SLOT(slot_productName(int, QString)));      //1, 2

    /* Product -> Order */      //modify
    connect(productForm, SIGNAL(sig_sendModifyProduct(int,int,QString)), orderForm, SLOT(producNameComboBoxModify(int,int,QString)));
                                //remove
    connect(productForm, SIGNAL(sig_sendRemovdProduct(int)), orderForm, SLOT(productNameComboBoxRemove(int)));

    //    connect(clientForm, SIGNAL(sig_sendSearchedProduct(QList<QStringList>)), orderForm, SLOT(updateProductComboBox(QList<QStringList>)));


    /* Order -> Product */
    connect(orderForm, SIGNAL(sig_reduceInventoryAmount(QString, int)), productForm, SLOT(updateInventoryAmount(QString, int)));   //10


    /* Order -> Client , Clinet -> Order */
    connect(orderForm, SIGNAL(sig_requestSearchID(int)), clientForm, SLOT(sendSearchedID(int)));       //6
    connect(clientForm, SIGNAL(sig_sendSearchedID(QStringList)), orderForm, SLOT(updateClient(QStringList)));     //7

    /* Order -> Product , Product -> Order */
    connect(orderForm, SIGNAL(sig_requesProductNameSearch(QString)), productForm, SLOT(slot_sendProductNameSearch(QString)));   //8
    connect(productForm, SIGNAL(sig_sendProductNameSearch(QStringList)), orderForm, SLOT(updateProduct(QStringList)));  //9

    /*Order -> Product, Product -> Order */  //TotalPrice 계산해서 totalPriceLineEdit에 자동출력
    connect(orderForm, SIGNAL(sig_calTotalPrice(QString,int)), productForm, SLOT(slot_CalTotalPrice(QString,int)));
    connect(productForm, SIGNAL(sig_sendTotalPrice(int)), orderForm, SLOT(updateTotalPrice(int)));



    /*YUNA*/
    /*order의 productNameComboBox에서 제품을 선택하면 productTreeWidget에 해당 제품 정보가 출력*/
    connect(orderForm, SIGNAL(productFind(QString)), productForm, SLOT(slot_productData(QString)));
    connect(productForm, SIGNAL(productData(QStringList)), orderForm, SLOT(slot_productInfo(QStringList)));


    clientForm->loadData();
    productForm->loadData();
    orderForm->loadData();

    QIcon iconClient = QIcon("clientImg.png");          //ClientInfo 아이콘
    ui->actionClient->setIcon(iconClient);

    QIcon iconProduct = QIcon("productImg.jpg");        //ProductInfo 아이콘
    ui->actionProduct->setIcon(iconProduct);

    QIcon iconOrder = QIcon("orderImg.png");            //OrderInfo 아이콘
    ui->actionOrder->setIcon(iconOrder);

    QIcon iconChat_Client = QIcon("chatImg.png");       //ChatServer 아이콘
    ui->actionChat_Client->setIcon(iconChat_Client);

    QIcon iconChat_Server = QIcon("serverImg.png");     //ChatClient 아이콘
    ui->actionChatServer->setIcon(iconChat_Server);

    QIcon iconQuit = QIcon("quitImg5.png");             //Quit 아이콘
    ui->actionQuit->setIcon(iconQuit);

    QMdiSubWindow *cw = ui->mdiArea->addSubWindow(clientForm);
    ui->mdiArea->addSubWindow(productForm);
    ui->mdiArea->addSubWindow(orderForm);
    ui->mdiArea->addSubWindow(serverForm);
    ui->mdiArea->setActiveSubWindow(cw);


}

MainWindow::~MainWindow()
{
    delete ui;
    delete serverForm;
    delete clientForm;
    delete productForm;
    delete orderForm;

    QStringList list = QSqlDatabase::connectionNames();
    for(int i = 0; i < list.count(); ++i) {
        QSqlDatabase::removeDatabase(list[i]);
    }
}

void MainWindow::on_actionClient_triggered()
{
    if(clientForm != nullptr) {
        clientForm->setFocus();
    }
}

void MainWindow::on_actionProduct_triggered()
{
    if(productForm != nullptr) {
        productForm->setFocus();
    }
}

void MainWindow::on_actionOrder_triggered()
{
    if(orderForm != nullptr) {
        orderForm->setFocus();
    }
}

void MainWindow::on_mdiArea_subWindowActivated(QMdiSubWindow *orderupdate)
{
    Q_UNUSED(orderupdate);
    //emit orderForm->sig_requestProductNames();
//    emit orderForm->productAdded(int, QString);
}

void MainWindow::on_actionChatServer_triggered()
{
    if(serverForm != nullptr) {
        serverForm->setFocus();
    }
}

void MainWindow::on_actionChat_Client_triggered()
{
    chatClient = new ChatClient(nullptr, chatClientID++);
    chatClient->move(1100, 400);
    chatClient ->show();

    connect(chatClient, SIGNAL(destroyed()), chatClient, SLOT(deleteLater()));

    //여기서 커넥트 할 때 우리가 chatClient를 여러개 띄위면 그것들 중에 하나면 login해도 나머지 한테도 다 시그널이 가가지고 4번 뜨는거다.
    //그래서 chatClient마다 고유 ID를 부여해서 signal을 보낼 때 id를 같이 보낼 것이다.
    connect(chatClient, SIGNAL(sig_checkLogin(QString, int)), serverForm, SLOT(slot_checkLogin(QString, int)));
    connect(serverForm, SIGNAL(sig_checkLogin(int, int)), chatClient, SLOT(slot_login(int, int)));
}


