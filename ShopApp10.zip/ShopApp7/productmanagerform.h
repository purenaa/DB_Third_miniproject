#ifndef PRODUCTMANAGERFORM_H
#define PRODUCTMANAGERFORM_H

//#include "product.h"
#include <QWidget>

class Product;
class QMenu;
class QSqlDatabase;
class QSqlTableModel;
class QStandardItemModel;

namespace Ui { class ProductManagerForm; }

class ProductManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ProductManagerForm(QWidget *parent = nullptr);      // 생성자 (DB를 열 때)
    ~ProductManagerForm();                                       // 소멸자 (DB를 닫을 때)
    void headerName();                                           // 0~3열까지 헤더이름을 지정해주는 함수
    void loadData();                                             // DB 생성
    void clear();                                                // 초기화해주는 함수

private:
    int makeId();                               // 제품 ID를 자동 할당해주는 함수
    Ui::ProductManagerForm *ui;                 // ClientManagerForm의 ui
    /* 멤버변수 */
    QMenu* menu;                                // QMenu 클래스는 상황에 맞는 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel* productModel;               // 제품 커리모델
    QStandardItemModel* searchModel;            // 검색 커리모델

private slots:
    /* tableView를 위한 슬롯 */
    void removeItem();      //항목(item)을 제거하는 함수
    void showContextMenu(const QPoint &);       //마우스 커서 위치
//    void on_treeWidget_itemClicked(QTreeWidgetItem *item, int column);   //treeWidget에 있는 항목(item)을 선택했을 때
    void on_addPushButton_clicked();        //Add(고객 추가) 버튼을 클릭했을 때
    void on_modifyPushButton_clicked();     //Modify(수정) 버튼을 클릭했을 때
    void on_searchPushButton_clicked();     //검색 기능을 수행하는 함수
    void on_clearPushButton_clicked();
    //    void slot_getProductNames();
    void slot_sendProductNameSearch(QString);

    /* Order에서 remove, modify 정보를 받아서 재고수량을 변경해주는 슬롯*/
    void updateInventoryAmount(QString, int);


    /* totalPrice 계산 */
    void slot_CalTotalPrice(QString, int);


    void on_tableView_clicked(const QModelIndex &index);
//    void acceptProductInfo(int);      //교수님 코드


    /*YUNA*/
    void slot_productData(QString);

signals:
    void productAdded(int, QString);            // 추가한 제품 ID와 제품 이름을 [시그널:productAdded]로 전달합니다.


//    void sig_getProductNames(QList<QString>);
    void sig_sendProductNameSearch(QStringList);
//    void sig_sendProductNameSearch(QStringList, int = -1);
    void sendProductInfo(QString, QString, QString);

    /* totalPrice 전달 */
    void sig_sendTotalPrice(int);



    void productData(QStringList);     //제품 정보를 List에 담아 전달할 시그널 발생


//    /* product -> Order */      //modify할 때
    void sig_sendModifyProduct(int, int, QString);
    void sig_sendRemovdProduct(int);    //remvoe할 때


};

#endif // PRODUCTMANAGERFORM_H
