#ifndef CLIENTMANAGERFORM_H
#define CLIENTMANAGERFORM_H

//#include "client.h"
#include <QWidget>

class Client;
class QMenu;
class QSqlDatabase;
class QSqlTableModel;
class QStandardItemModel;

namespace Ui { class ClientManagerForm; }

class ClientManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ClientManagerForm(QWidget *parent = nullptr);      // 생성자 (DB를 열 때)
    ~ClientManagerForm();                                       // 소멸자 (DB를 닫을 때)
    void headerName();                                          // 0~4열까지 헤더이름을 지정해주는 함수
    void loadData();                                            // DB 생성
    void clear();                                               // 초기화해주는 함수

private:
    int makeId();                                           // 고객 ID를 자동 할당해주는 함수
    Ui::ClientManagerForm *ui;                              // ClientManagerForm의 ui
    /* 멤버변수 */
    QMenu* menu;                                            // QMenu 클래스는 상황에 맞는 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel* clientModel;                            // 고객 커리모델
    QStandardItemModel* searchModel;                        // 검색 커리모델

private slots:
    /* tableView를 위한 슬롯 */
    void removeItem();                                      // tableView에 있는 항목을 제거해주는 함수
    void showContextMenu(const QPoint &);                   // 오른쪽 마우스버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수
     void on_tableView_clicked(const QModelIndex &index);   // tableView의 항목을 선택했을 때
    void on_addPushButton_clicked();                        // 고객을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작
    void on_modifyPushButton_clicked();                     // modify 버튼을 누르면 이미 추가된 고객 정보가 변경됩니다.
    void on_clearPushButton_clicked();                      // clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수
    void on_searchPushButton_clicked();                     //검색 기능을 수행하는 함수
    /* Order에서 전달된 시그널을 구현하는 슬롯 */
    void sendSearchedClient(QString);                       /* orderManagerForm에서 입력한 고객 이름과 clientManagerForm에 있는 고객 이름이
                                                               일치할 때 일치하는 고객 정보를 가지고 있는 슬롯 */
    void sendSearchedID(int);                               /* orderManagerForm의 tableView에서 선택한 고객 ID와 clientManagerForm에 있는 고객 ID가
                                                            일치할 때 일치하는 고객 정보를 가지고 있는 슬롯 */
signals:
    /* Client -> Server 로 전달하는 시그널*/
    void clientAdded(int, QString);                         // 추가한 고객 ID와 고객 이름을 [시그널:clientAdded]로 전달합니다.
    void sig_sendModifyClient(int, int, QString);           //고객 ID, 인덱스의 행, 변경된 고객이름을 [시그널:sig_sendModifyClient]로 전달합니다.
    void sig_sendClientInfo(QString);                       // 제거된 고객이름을 [시그널:sig_sendClientInfo]로 전달합니다.
    /* Client -> Order로 전달하는 시그널 */
    void sig_sendSearchedClient(QList<QStringList>);        // orderManagerForm에서 입력한 고객 이름과 일치하는 고객 정보를 [시그널:sig_sendSearchedClient]로 전달합니다.
    void sig_sendSearchedID(QStringList);                   // orderManagerForm의 tableView에서 선택한 고객 ID와 일치하는 고객 정보를 [시그널:sig_sendSearchedID]로 전달합니다.
};
#endif // CLIENTMANAGERFORM_H
