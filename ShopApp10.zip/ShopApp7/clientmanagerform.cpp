#include "clientmanagerform.h"
#include "ui_clientmanagerform.h"
//#include "client.h"

#include <QFile>
#include <QMenu>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QStandardItemModel>
#include <QMessageBox>

/* 생성자 (DB를 열 때) */
ClientManagerForm::ClientManagerForm(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::ClientManagerForm)
{
    ui->setupUi(this);                                                  // 지정한 위젯에 대한 사용자 인터페이스를 설정

    QList<int> sizes;
    sizes << 1900 << 1300;                                              // 1900 : tableView size, 1300 : toolBox size
    ui->splitter->setSizes(sizes);                                      // splitter 크기 조절

    QAction* removeAction = new QAction(tr("&Remove"));                 // 삭제 기능 생성
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));     // remove할 때 시그널 슬롯 발생

    menu = new QMenu;                                                   // menu : 멤버변수       //메뉴 생성
    menu->addAction(removeAction);                                      // 메뉴에 remove 기능 추가
    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));                 // searchLineEdit에서의 시그널과 on_searchPushButton_clicked 슬롯 연결

    /*0행의 0~4열(5개)까지 헤더이름을 지정*/
    searchModel = new QStandardItemModel(0, 5);
    headerName();
    ui->searchTableView->setModel(searchModel);
}

/* 0~4열까지 헤더이름을 지정해주는 함수 */
void ClientManagerForm::headerName()
{
    searchModel->setHeaderData(0, Qt::Horizontal, tr("고객 ID"));
    searchModel->setHeaderData(1, Qt::Horizontal, tr("고객 이름"));
    searchModel->setHeaderData(2, Qt::Horizontal, tr("전화번호"));
    searchModel->setHeaderData(3, Qt::Horizontal, tr("주소"));
    searchModel->setHeaderData(4, Qt::Horizontal, tr("이메일"));
}

/* DB 생성 */
void ClientManagerForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "clientConnection");     // 데이터베이스를 만듦
    db.setDatabaseName("ClientDBlist.db");                                          // DB이름 : ClientDBlist
    if(db.open()) {                                                                 // DB를 열 때
        QSqlQuery query(db);                                                        // DB에 커리생성

        /* 테이블을 생성하고 0~4열까지 헤더이름을 지정해줍니다. */
        query.exec("CREATE TABLE IF NOT EXISTS ClientDB(id INTEGER Primary Key,"
                   "clientName VARCHAR(30) NOT NULL, phoneNumber VARHCHAR(50), address VARHCHAR(100), email VARHCHAR(100));");
        clientModel = new QSqlTableModel(this, db);
        clientModel->setTable("ClientDB");
        clientModel->select();
        headerName();
        ui->tableView->setModel(clientModel);       // tableView에 지정해준 헤더 이름을 가진 모델을 보여줍니다.
        ui->tableView->resizeColumnsToContents();   // 이름 크기에 맞기 사이즈를 지정해 줌
    }
    /* clientModel의 행의 개수만큼 반복하면서 고객 ID와 고객 이름을 [시그널:clientAdded]으로 전달합니다. */
    for(int i = 0; i < clientModel->rowCount(); i++) {
        int clientID = clientModel->data(clientModel->index(i, 0)).toInt();
        QString clientName = clientModel->data(clientModel->index(i, 1)).toString();
        emit clientAdded(clientID, clientName);
    }
}

/* 소멸자 (DB를 닫을 때) */
ClientManagerForm::~ClientManagerForm()
{
    delete ui;
    QSqlDatabase db = QSqlDatabase::database("clientConnection");
    if(db.isOpen()) {                           // DB를 열 때
        clientModel->submitAll();               // 보류 중인 모든 변경 사항을 제출하고 성공 시 true를 반환합니다.
        delete clientModel;                     // clientModel 삭제
        db.commit();                            // DB 트랜잭션을 데이터베이스에 커밋합니다. 작업이 성공하면 true를 반환합니다. 그렇지 않으면 false를 반환합니다.
        db.close();                             // DB 닫음
    }
}

/* 고객 ID를 자동 할당해주는 함수 */
int ClientManagerForm::makeId( )
{
    if(clientModel->rowCount() == 0) {              // clientModel의 행의 개수가 0일 때
        return 1;                                   // 1을 반환 (첫 번째 고객 ID는 1이 됩니다.)
    } else {
        auto clientID = clientModel->data(clientModel->index(clientModel->rowCount()-1, 0)).toInt();
        return ++clientID;
    }
}

/* tableView에 있는 항목을 제거해주는 함수 */
void ClientManagerForm::removeItem()
{
    QModelIndex index = ui->tableView->currentIndex();                       // tableView의 현재 인덱스
    QString clientName;
    clientName = clientModel->data(index.siblingAtColumn(1)).toString();     // clientName은 clientModel에서 선택된 행의 1열에 있는 정보
    if(index.isValid()) {
        clientModel->removeRow(index.row());                                 // clientModel의 해당 인덱스에 있는 행을 제거해줍니다.
        clientModel->select();                                               // clientModel을 재정렬
        ui->tableView->update();                                             // 인덱스 업데이트
    }
    emit sig_sendClientInfo(clientName);                                     // 제거된 고객 이름을 [시그널:sig_sendClientInfo]로 전달합니다.
}

/* 오른쪽 마우스버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수 */
void ClientManagerForm::showContextMenu(const QPoint &pos)
{
    QPoint globalPos = ui->tableView->mapToGlobal(pos);
    menu->exec(globalPos);
}

/* tableView의 항목을 선택했을 때 */
void ClientManagerForm::on_tableView_clicked(const QModelIndex &index)
{
    int clientID = clientModel->data(index.siblingAtColumn(0)).toInt();             // clientModel에서 선택된 행의 0열에 있는 정보
    QString clientName = clientModel->data(index.siblingAtColumn(1)).toString();    // clientModel에서 선택된 행의 1열에 있는 정보
    QString phoneNumber = clientModel->data(index.siblingAtColumn(2)).toString();   // clientModel에서 선택된 행의 2열에 있는 정보
    QString address = clientModel->data(index.siblingAtColumn(3)).toString();       // clientModel에서 선택된 행의 3열에 있는 정보
    QString email = clientModel->data(index.siblingAtColumn(4)).toString();         // clientModel에서 선택된 행의 4열에 있는 정보

    ui->clientIDLineEdit->setText(QString::number(clientID));                       // tableView에서 선택된 항목 중 고객 ID가 clientIDLineEdit에 나타납니다.
    ui->clientNameLineEdit->setText(clientName);                                    // tableView에서 선택된 항목 중 고객 이름이 clientNameLineEdit애 나타납니다.
    ui->phoneNumberLineEdit->setText(phoneNumber);                                  // tableView에서 선택된 항목 중 전화번호가 phoneNumberLineEdit에 나타납니다.
    ui->addressLineEdit->setText(address);                                          // tableView에서 선택된 항목 중 주소가 addressLineEdit에 나타납니다.
    ui->emailLineEdit->setText(email);                                              // tableView에서 선택된 항목 중 이메일이 addressLineEdit에 나타납니다.
}

/* 초기화해주는 함수 */
void ClientManagerForm::clear()
{
    ui->clientIDLineEdit->setText("");                                  // clientIDLineEdit을 공백으로 비워줌
    ui->clientNameLineEdit->setText("");                                // clientNameLineEdit을 공백으로 비워줌
    ui->phoneNumberLineEdit->setText("");                               // phoneNumberLineEdit을 을 공백으로 비워줌
    ui->addressLineEdit->setText("");                                   // addressLineEdit을 공백으로 비워줌
    ui->emailLineEdit->setText("");                                     // emailLineEdit을 공백으로 비워줌
}

/* 고객을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작 */
void ClientManagerForm::on_addPushButton_clicked()
{
    QString clientname, phonenumber, address, email;
    int clientID = makeId();                                            // 고객 ID는 자동할당
    ui->clientIDLineEdit->setText(QString::number(clientID));
    clientname = ui->clientNameLineEdit->text();                        // clientNameLineEdit에 입력한 text는 고객 이름
    phonenumber = ui->phoneNumberLineEdit->text();                      // phoneNumberLineEdit에 입력한 text는 고객 전화번호
    address = ui->addressLineEdit->text();                              // addressLineEdit 입력한 text는 고객 주소
    email = ui->emailLineEdit->text();                                  // emailLineEdit 입력한 text는 고객 이메일
#if 1
    QSqlDatabase db = QSqlDatabase::database("clientConnection");
    if(db.isOpen() && clientname.length()) {                            // DB를 열면
        QSqlQuery query(clientModel->database());
        query.prepare("INSERT INTO ClientDB VALUES(?, ?, ?, ?, ?)");    // ClientDB 테이블에 입력한 정보를 삽입합니다.
        query.bindValue(0, clientID);                                   // 0열: 고객 ID
        query.bindValue(1, clientname);                                 // 1열: 고객 이름
        query.bindValue(2, phonenumber);                                // 2열: 전화번호
        query.bindValue(3, address);                                    // 3열: 주소
        query.bindValue(4, email);                                      // 4열: 이메일
        query.exec();                                                   // 쿼리 실행
        clientModel->select();                                          // clientModel을 재정렬
        ui->tableView->resizeColumnsToContents();                       // 이름 크기에 맞기 사이즈를 지정해 줌
        emit clientAdded(clientID, clientname);                         // 추가한 고객 ID와 고객 이름을 [시그널:clientAdded]로 전달합니다.
#else
    if(clientname.length()) {
        QSqlDatabase db = QSqlDatabase::database("clientConnection");
        if(db.isOpen()) {
            QSqlQuery query(db);
            query.exec(QString("INSERT INTO ClientDB VALUES(%1, '%2', '%3', '%4', '%5')")
                       .arg(clientID).arg(clientname).arg(phonenumber).arg(address).arg(email));
            clientModel->select();
            ui->tableView->resizeColumnsToContents();
        }
#endif
    }
    clear();                                                            // 초기화
}

/* modify 버튼을 누르면 이미 추가된 고객 정보가 변경됩니다. */
void ClientManagerForm::on_modifyPushButton_clicked()
{
    QModelIndex ix = ui->tableView->currentIndex();                 // tableView의 현재 인덱스
    int index = ix.row();                                           // 선택된 인덱스의 행
    if(ix.isValid()) {
        QString clientName, phoneNumber, address, email;
        int clientID;
        clientID = ui->clientIDLineEdit->text().toInt();            // clientID는 clientIDLineEdit에 입력된 정보
        clientName = ui->clientNameLineEdit->text();                // clientName는 phoneNumberLineEdit에 입력된 정보
        phoneNumber = ui->phoneNumberLineEdit->text();              // phoneNumber는 phoneNumberLineEdit에 입력된 정보
        address = ui->addressLineEdit->text();                      // address는 addressLineEdit에 입력된 정보
        email = ui->emailLineEdit->text();                          // email은 emailLineEdi에 입력된 정보

        clientModel->setData(ix.siblingAtColumn(1), clientName);        // 선택된 행의 1열을 clientName으로 변경
        clientModel->setData(ix.siblingAtColumn(2), phoneNumber);       // 선택된 행의 2열을 phoneNumber으로 변경
        clientModel->setData(ix.siblingAtColumn(3), address);           // 선택된 행의 3열을 address으로 변경
        clientModel->setData(ix.siblingAtColumn(4), email);             // 선택된 행의 4열을 email으로 변경
        clientModel->submit();                                          // 변경 사항 제출
        clientModel->select();                                          // clientModel을 재정렬
        ui->tableView->resizeColumnsToContents();                       // 이름 크기에 맞기 사이즈를 지정해 줌
        emit sig_sendModifyClient(clientID, index, clientName);         // 고객 ID, 인덱스의 행, 변경된 고객 이름을 [시그널:sig_sendModifyClient]로 전달합니다.
    }
}

/* clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수 */
void ClientManagerForm::on_clearPushButton_clicked()
{
    clear();            //초기화
}

/* 고객 정보를 조회하고 싶을 때 Search 버튼을 누르면 조회하실 수 있습니다. */
void ClientManagerForm::on_searchPushButton_clicked()
{
    searchModel->clear();
    int i = ui->searchComboBox->currentIndex();
    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
                   : Qt::MatchCaseSensitive;
    QModelIndexList indexes = clientModel->match(clientModel->index(0, i), Qt::EditRole,
                                                 ui->searchLineEdit->text(), -1, Qt::MatchFlags(flag));
    foreach(auto ix, indexes) {
        int clientID = clientModel->data(ix.siblingAtColumn(0)).toInt();                // 일치하는 고객 ID
        QString clientName = clientModel->data(ix.siblingAtColumn(1)).toString();       // 일치하는 고객 이름
        QString phoneNumber = clientModel->data(ix.siblingAtColumn(2)).toString();      // 일치하는 전화번호
        QString address = clientModel->data(ix.siblingAtColumn(3)).toString();          // 일치하는 주소
        QString email = clientModel->data(ix.siblingAtColumn(4)).toString();            // 일치하는 이메일
        QStringList clientStrings;
        clientStrings << QString::number(clientID) << clientName << phoneNumber << address << email;

        QList<QStandardItem *> items;
        for (int i = 0; i < 5; ++i) {
            items.append(new QStandardItem(clientStrings.at(i)));       // 조회된 고객 정보를 순서대로 출력
        }
        searchModel->appendRow(items);
        headerName();                                                   // 0~4열까지 헤더 이름을 지정
        ui->searchTableView->resizeColumnsToContents();                 // 이름 크기에 맞기 사이즈를 지정해 줌
    }
}

/* orderManagerForm에서 입력한 고객 이름과 clientManagerForm에 있는 고객 이름이 일치할 때 일치하는 고객 정보를 가지고 있는 슬롯 */
void ClientManagerForm::sendSearchedClient(QString clientName)                  // 인자 clientName은 orderManagerForm에서 입력한 고객 이름
{
    /* 인자로 받은 고객 이름과 clientModel에 있는 고객 이름이 일치하는지 비교 */
    QModelIndexList indexes = clientModel->match(clientModel->index(0, 1),Qt::EditRole,
                                                 clientName, -1, Qt::MatchFlags(Qt::MatchCaseSensitive));
    QList<QStringList> searchedClientList;
    foreach(auto ix, indexes) {
        /* 고객 이름이 일치하는 고객 정보 (고객 ID, 고객 이름, 전화번호, 주소, 이메일) */
        int clientID = clientModel->data(ix.siblingAtColumn(0)).toInt();
        QString clientName = clientModel->data(ix.siblingAtColumn(1)).toString();
        QString phoneNumber = clientModel->data(ix.siblingAtColumn(2)).toString();
        QString address = clientModel->data(ix.siblingAtColumn(3)).toString();
        QString email =  clientModel->data(ix.siblingAtColumn(4)).toString();
        QStringList clientStrings;
        clientStrings << QString::number(clientID) << clientName << phoneNumber << address << email;
        searchedClientList.append(clientStrings);
    }
    emit sig_sendSearchedClient(searchedClientList);     // orderManagerForm에서 입력한 고객 이름과 일치하는 고객 정보를 [시그널:sig_sendSearchedClient]로 전달합니다.
}

/* orderManagerForm의 tableView에서 클릭한 주문 정보의 고객 ID와 clientManagerForm에 있는 고객 ID가 일치할 때 일치하는 고객 정보를 가지고 있는 슬롯 */
void ClientManagerForm::sendSearchedID(int clientID)                   // 인자 clientID는 orderManagerForm의 tableView에서 클릭한 주문 정보의 고객 ID
{
    /* 인자로 받은 고객 ID와 clientModel에 있는 고객 ID가 일치하는지 비교 */
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList indexes = clientModel->match(clientModel->index(0, 0), Qt::EditRole,
                                                 clientID, -1, Qt::MatchFlags(flag));
        /* 고객 ID가 일치하는 고객 정보 (고객 ID, 고객 이름, 전화번호, 주소, 이메일) */
        int cID = clientModel->data(indexes.at(0).siblingAtColumn(0)).toInt();
        QString clientName = clientModel->data(indexes.at(0).siblingAtColumn(1)).toString();
        QString phoneNumber = clientModel->data(indexes.at(0).siblingAtColumn(2)).toString();
        QString address = clientModel->data(indexes.at(0).siblingAtColumn(3)).toString();
        QString email =  clientModel->data(indexes.at(0).siblingAtColumn(4)).toString();
        QStringList clientStrings;
        clientStrings << QString::number(cID) << clientName << phoneNumber << address << email;
        emit sig_sendSearchedID(clientStrings);     /* orderManagerForm의 tableView에서 클릭한 주문 정보의 고객 ID와
                                                       일치하는 고객 정보를 [시그널:sig_sendSearchedID]로 전달합니다. */
}
