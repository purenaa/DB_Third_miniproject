#include "productmanagerform.h"
#include "ui_productmanagerform.h"
//#include "product.h"

#include <QFile>
#include <QMenu>
#include <QList>
#include <QPixmap>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>

ProductManagerForm::ProductManagerForm(QWidget *parent)         //생성자
    : QWidget(parent),
      ui(new Ui::ProductManagerForm)
{
    ui->setupUi(this);                                          //지정한 위젯에 대한 사용자 인터페이스를 설정

    QList<int> sizes;
    sizes << 1900 << 1300;                                      //1800 : treeWidget size, 1300 : toolBox size
    ui->splitter->setSizes(sizes);                              //splitter 크기 조절

    QAction* removeAction = new QAction(tr("&Remove"));         //삭제 기능 생성
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));

    menu = new QMenu;                                           //menu : 멤버변수       //메뉴 생성
    menu->addAction(removeAction);
    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));

//    //treeWidget size 변경
//    ui->treeWidget->header()->resizeSection(0, 70);             //Product ID size
//    ui->treeWidget->header()->resizeSection(1, 380);            //Product Name size
//    ui->treeWidget->header()->resizeSection(2, 80);             //Price size
//    ui->treeWidget->header()->resizeSection(3, 70);             //Inventory Amount size
//    //searchTreeWidget size 변경
//    ui->searchTreeWidget->header()->resizeSection(0, 80);       //Product ID size
//    ui->searchTreeWidget->header()->resizeSection(1, 130);      //Product Name size
//    ui->searchTreeWidget->header()->resizeSection(2, 60);       //Price size
//    ui->searchTreeWidget->header()->resizeSection(3, 120);      //Inventory Amount size
}

void ProductManagerForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "productConnection");
    db.setDatabaseName("ProductDBlist.db");            //DB 파일로 저장
    if(db.open()) {
        QSqlQuery query(db);
        query.exec("CREATE TABLE IF NOT EXISTS ProductDB(id INTEGER Primary Key,"
                   "productName VARCHAR(30) NOT NULL, price VARHCHAR(20), inventoryAmount INTEGER);");
        productModel = new QSqlTableModel(this, db);
        productModel->setTable("ProductDB");
        productModel->select();
        productModel->setHeaderData(0, Qt::Horizontal, QObject::tr("제품 ID"));
        productModel->setHeaderData(1, Qt::Horizontal, QObject::tr("제품 이름"));
        productModel->setHeaderData(2, Qt::Horizontal, QObject::tr("가격"));
        productModel->setHeaderData(3, Qt::Horizontal, QObject::tr("재고 수량"));
        //qDebug("%d", __LINE__);
        ui->tableView->setModel(productModel);
        ui->tableView->resizeColumnsToContents();
    }
    for(int i = 0; i < productModel->rowCount(); i++) {
        int productID = productModel->data(productModel->index(i, 0)).toInt();
        QString productName = productModel->data(productModel->index(i, 1)).toString();
        emit productAdded(productID, productName);
    }

}

ProductManagerForm::~ProductManagerForm()                       //소멸자
{
    delete ui;
    QSqlDatabase db = QSqlDatabase::database("productConnection");
    if(db.isOpen()) {
        productModel->submitAll();
        delete productModel;
        db.commit();
        db.close();
    }
}

int ProductManagerForm::makeId( )                               //제품 ID를 자동 할당해주는 함수
{
//    if(productList.size( ) == 0) {                              //초기 productList에 정보가 없을 경우 제품 ID 10000을 반환
//        return 10000;
//    } else {
//        auto productID = productList.lastKey();                 //productList가 비어있지 않으면
//        return ++productID;                                     //이전 반환 값 10000에 ++productID
//    }

    if(productModel->rowCount() == 0) {
        return 10000;
    } else {
        auto productId = productModel->data(productModel->index(productModel->rowCount()-1, 0)).toInt();
        return ++productId;
    }
}

void ProductManagerForm::removeItem()                           //항목(item)을 제거해주는 함수
{
    QModelIndex index = ui->tableView->currentIndex();
    if(index.isValid()) {
        productModel->removeRow(index.row());
        productModel->select();
        ui->tableView->update();
    }
}

void ProductManagerForm::showContextMenu(const QPoint &pos)      //마우스 커서 위치
{
    QPoint globalPos = ui->tableView->mapToGlobal(pos);
    menu->exec(globalPos);
}

void ProductManagerForm::on_tableView_clicked(const QModelIndex &index)
{
    int productID = productModel->data(index.siblingAtColumn(0)).toInt();
    QString productName = productModel->data(index.siblingAtColumn(1)).toString();
    QString price = productModel->data(index.siblingAtColumn(2)).toString();
    int inventoryAmount = productModel->data(index.siblingAtColumn(3)).toInt();

    ui->productIDLineEdit->setText(QString::number(productID));                       //treeView에서 선택된 항목 중 고객 ID가 clientIDLineEdit에 나타납니다.
    ui->productNameLineEdit->setText(productName);                     //treeView에서 선택된 항목 중 고객 이름이 clientNameLineEdit애 나타납니다.
    ui->priceLineEdit->setText(price);                              //treeView에서 선택된 항목 중 고객 전화번호가 phoneNumberLineEdit에 나타납니다.
    ui->inventoryAmountSpinBox->setValue(inventoryAmount);                  //treeView에서 선택된 항목 중 고객 주소가 addressLineEdit에 나타납니다.

    QString imagePath(tr("img/%1.png").arg(productName));         //이미지 경로
    QPixmap* selectImage = new QPixmap(imagePath);
    ui->imageLabel->setPixmap(*selectImage);                        //imageLabel 위치에 제품 이름과 일치하는 제품 사진을 보여줍니다.
}

//void ProductManagerForm::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)       //treeWidget에 있는 항목(item)을 선택했을 경우
//{
//    Q_UNUSED(column);                                               //Q_UNUSED()는 인자를 만들어놓고 사용하지 않을 때 쓰면 경고를 없앨 수 있다.
//    ui->productIDLineEdit->setText(item->text(0));                  //treeWidget에서 선택된 항목 중 제품 ID가 productIDLineEdit에 나타납니다.
//    ui->productNameLineEdit->setText(item->text(1));                //treeWidget에서 선택된 항목 중 제품 ID가 productNameLineEdit에 나타납니다.
//    ui->priceLineEdit->setText(item->text(2));                      //treeWidget에서 선택된 항목 중 제품 ID가 priceLineEdit에 나타납니다.
//    ui->inventoryAmountSpinBox->setValue(item->text(3).toInt());    //treeWidget에서 선택된 항목 중 제품 ID가 inventoryAmountSpinBox에 나타납니다.

//    QString imagePath(tr("img/%1.png").arg(item->text(1)));         //이미지 경로
//    QPixmap* selectImage = new QPixmap(imagePath);
//    ui->imageLabel->setPixmap(*selectImage);                        //imageLabel 위치에 제품 이름과 일치하는 제품 사진을 보여줍니다.
//}

void ProductManagerForm::on_addPushButton_clicked()                 //Add(고객 추가) 버튼을 클릭했을 때
{
    QString productName, price;
    int inventoryAmount;
    int productID = makeId( );                                      //고객 ID 자동할당
    ui->productIDLineEdit->setText(QString::number(productID));
    productName = ui->productNameLineEdit->text();                  //productNameLineEdit에 입력한 text는 제품 이름
    price = ui->priceLineEdit->text();                              //priceLineEdit에 입력한 text는 제품 가격
    inventoryAmount = ui->inventoryAmountSpinBox->value();          //inventoryAmountSpinBox에서 선택한 value는 재고 수량

    if(productName.length()) {
        QSqlDatabase db = QSqlDatabase::database("productConnection");
        if(db.isOpen()) {
            QSqlQuery query(db);
            query.exec(QString("INSERT INTO ProductDB VALUES(%1, '%2', '%3', %4)")
                       .arg(productID).arg(productName).arg(price).arg(inventoryAmount));
            productModel->select();
        }
        ui->tableView->resizeColumnsToContents();
        emit productAdded(productID, productName);
    }
    ui->productIDLineEdit->setText("");                             //Add 버튼을 누르고 나서 productIDLineEdit을 공백으로 비워줌
    ui->productNameLineEdit->setText("");                           //productNameLineEdit을 공백으로 비워줌
    ui->priceLineEdit->setText("");                                 //priceLineEdit을 공백으로 비워줌
    ui->inventoryAmountSpinBox->setValue(0);                        //inventoryAmountSpinBox의 값을 0으로 바꿔줌
}

void ProductManagerForm::on_modifyPushButton_clicked()              //Modify(수정) 버튼을 클릭했을 때
{
    QModelIndex index = ui->tableView->currentIndex();
    if(index.isValid()) {
        QString productName, price;
        int inventoryAmount;
//        int productID;
//        productID = ui->productIDLineEdit->text().toInt();
        productName = ui->productNameLineEdit->text();
        price = ui->priceLineEdit->text();
        inventoryAmount = ui->inventoryAmountSpinBox->value();
#if 1
        productModel->setData(index.siblingAtColumn(1), productName);
        productModel->setData(index.siblingAtColumn(2), price);
        productModel->setData(index.siblingAtColumn(3), inventoryAmount);
        productModel->submit();
#else
        QSqlQuery query(productModel->database());
        query.prepare("UPDATE product SET productName = ?, price = ?, inventoryAmount = ? WHERE productID = ?");
        query.bindValue(1, productName);
        query.bindValue(2, price);
        query.bindValue(3, inventoryAmount);
        query.bindValue(0, productID);
        query.exec();
#endif
        productModel->select();
        ui->tableView->resizeColumnsToContents();

//    QTreeWidgetItem* item = ui->treeWidget->currentItem();          //item = 현재 항목
//    if(item != nullptr) {                                           //항목이 비어있지 않으면
//        int key = item->text(0).toInt();
//        Product* productID = productList[key];
//        QString productName, price;
//        int inventoryAmount;
//        productName = ui->productNameLineEdit->text();
//        price = ui->priceLineEdit->text();
//        inventoryAmount = ui->inventoryAmountSpinBox->value();
//        productID->setProductName(productName);                     //제품 이름 수정
//        productID->setPrice(price);                                 //제품 가격 수정
//        productID->setInventoryAmount(inventoryAmount);             //제품 재고수량 수정
//        productList[key] = productID;
    }
}

void ProductManagerForm::on_searchPushButton_clicked()              //검색 기능을 수행하는 함수
{
    ui->searchTreeWidget->clear();                                  //searchTreeWidget 초기화
    int i = ui->searchComboBox->currentIndex();
    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
                   : Qt::MatchCaseSensitive;

    QModelIndexList indexes = productModel->match(productModel->index(0, i),
                                                  Qt::EditRole, ui->searchLineEdit->text(), -1, Qt::MatchFlags(flag));

    foreach(auto ix, indexes) {
        int productID = productModel->data(ix.siblingAtColumn(0)).toInt();
        QString productName = productModel->data(ix.siblingAtColumn(1)).toString();
        QString price = productModel->data(ix.siblingAtColumn(2)).toString();
        int inventoryAmount = productModel->data(ix.siblingAtColumn(3)).toInt();
        QStringList productStrings;
        productStrings << QString::number(productID) << productName << price << QString::number(inventoryAmount);
        new QTreeWidgetItem(ui->searchTreeWidget, productStrings);
        for(int i = 0; i < ui->searchTreeWidget->columnCount(); i++)
            ui->searchTreeWidget->resizeColumnToContents(i);                                 //searchTreeWidget에 보여줍니다.
    }
}

//void ProductManagerForm::acceptProductInfo(int key)
//{
//    QModelIndexList indexes = productModel->match(productModel->index(0, 0),
//                                                  Qt::EditRole, key, -1, Qt::MatchFlags(Qt::MatchCaseSensitive));
//    foreach(auto index, indexes) {
////    QModelIndex index = clientList[key];
//        QString name = productModel->data(index.siblingAtColumn(1)).toString();
//        QString phoneNumber = productModel->data(index.siblingAtColumn(2)).toString();
//        QString address = productModel->data(index.siblingAtColumn(3)).toString();
//        emit sendProductInfo(name, phoneNumber, address);
//    }
//}

void ProductManagerForm::on_clearPushButton_clicked()
{
    ui->productIDLineEdit->setText("");                             //Add 버튼을 누르고 나서 productIDLineEdit을 공백으로 비워줌
    ui->productNameLineEdit->setText("");                           //productNameLineEdit을 공백으로 비워줌
    ui->priceLineEdit->setText("");                                 //priceLineEdit을 공백으로 비워줌
    ui->inventoryAmountSpinBox->setValue(0);                        //inventoryAmountSpinBox의 값을 0으로 바꿔줌
    ui->imageLabel->clear();
}

void ProductManagerForm::slot_productData(QString productName)
{
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList products = productModel->match(productModel->index(0,1),
                                                   Qt::EditRole, productName,-1,Qt::MatchFlags(flag));

    int productID = productModel->data(products.at(0).siblingAtColumn(0)).toInt();
    QString pname = productModel->data(products.at(0).siblingAtColumn(1)).toString();
    QString price = productModel->data(products.at(0).siblingAtColumn(2)).toString();
    int inventoryAmount = productModel->data(products.at(0).siblingAtColumn(3)).toInt();
    QStringList productStrings;
    productStrings << QString::number(productID) << pname << price << QString::number(inventoryAmount);

    emit productData(productStrings);
}



//void ProductManagerForm::slot_getProductNames()                     //slot_getProductNames 슬롯 함수 구현
//{
//    QList<QString> productNameList;
//    foreach(Product *p, productList){                               //foreach(variable, container)
//        productNameList.append(p->getProductName());                //apppend : productNameList에 값을 넣는 함수
//    }
//    emit sig_getProductNames(productNameList);
//}


//void ProductManagerForm::slot_sendProductNameSearch(QString inputName, int purchaseQuantity)
//{
//    foreach(Product *p, productList){
//        if(inputName == p->getProductName())
//        {
//            emit sig_sendProductNameSearch(p, purchaseQuantity);
//            return;
//        }
//    }
//    emit sig_sendProductNameSearch(nullptr);
//}

void ProductManagerForm::updateInventoryAmount(QString productName, int purchaseQuantity)
{
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList products = productModel->match(productModel->index(0,1),
                                                   Qt::EditRole, productName,-1,Qt::MatchFlags(flag));

    int inventoryAmount = productModel->data(products.at(0).siblingAtColumn(3)).toInt();
    int result = inventoryAmount-purchaseQuantity;
    productModel->setData(products.at(0).siblingAtColumn(3), result);
    productModel->submit();

}


//    foreach(Product* p, productList){
//        if(productName == p->getProductName())
//        {
//            int result = p->getInventoryAmount()-purchaseQuantity;
//            p->setInventoryAmount(result);
//        }
//    }




