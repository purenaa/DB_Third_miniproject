/********************************************************************************
** Form generated from reading UI file 'clientmanagerform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CLIENTMANAGERFORM_H
#define UI_CLIENTMANAGERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ClientManagerForm
{
public:
    QVBoxLayout *verticalLayout_6;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QLabel *clientInfoLabel;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *inputPage;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout;
    QLabel *imageLabel;
    QSpacerItem *verticalSpacer_7;
    QFormLayout *formLayout;
    QLabel *clientIDLabel;
    QLineEdit *clientIDLineEdit;
    QSpacerItem *verticalSpacer_2;
    QLabel *clientNameLabel;
    QLineEdit *clientNameLineEdit;
    QSpacerItem *verticalSpacer_3;
    QLabel *phoneNumberLabel;
    QLineEdit *phoneNumberLineEdit;
    QSpacerItem *verticalSpacer_4;
    QLabel *addressLabel;
    QLineEdit *addressLineEdit;
    QSpacerItem *verticalSpacer_6;
    QLabel *emailLabel;
    QLineEdit *emailLineEdit;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addPushButton;
    QPushButton *modifyPushButton;
    QPushButton *clearPushButton;
    QWidget *searchPage;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout_3;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout;
    QComboBox *searchComboBox;
    QLineEdit *searchLineEdit;
    QPushButton *searchPushButton;

    void setupUi(QWidget *ClientManagerForm)
    {
        if (ClientManagerForm->objectName().isEmpty())
            ClientManagerForm->setObjectName(QString::fromUtf8("ClientManagerForm"));
        ClientManagerForm->resize(506, 396);
        verticalLayout_6 = new QVBoxLayout(ClientManagerForm);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        splitter = new QSplitter(ClientManagerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        clientInfoLabel = new QLabel(layoutWidget);
        clientInfoLabel->setObjectName(QString::fromUtf8("clientInfoLabel"));
        QFont font;
        font.setFamilies({QString::fromUtf8("Dubai")});
        font.setPointSize(20);
        font.setBold(true);
        clientInfoLabel->setFont(font);

        verticalLayout_2->addWidget(clientInfoLabel);

        tableView = new QTableView(layoutWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_2->addWidget(tableView);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        inputPage = new QWidget();
        inputPage->setObjectName(QString::fromUtf8("inputPage"));
        inputPage->setGeometry(QRect(0, 0, 330, 326));
        verticalLayout_4 = new QVBoxLayout(inputPage);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        imageLabel = new QLabel(inputPage);
        imageLabel->setObjectName(QString::fromUtf8("imageLabel"));
        imageLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(imageLabel);

        verticalSpacer_7 = new QSpacerItem(189, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_7);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        clientIDLabel = new QLabel(inputPage);
        clientIDLabel->setObjectName(QString::fromUtf8("clientIDLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, clientIDLabel);

        clientIDLineEdit = new QLineEdit(inputPage);
        clientIDLineEdit->setObjectName(QString::fromUtf8("clientIDLineEdit"));
        clientIDLineEdit->setEnabled(false);
        clientIDLineEdit->setReadOnly(true);

        formLayout->setWidget(0, QFormLayout::FieldRole, clientIDLineEdit);

        verticalSpacer_2 = new QSpacerItem(247, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(1, QFormLayout::FieldRole, verticalSpacer_2);

        clientNameLabel = new QLabel(inputPage);
        clientNameLabel->setObjectName(QString::fromUtf8("clientNameLabel"));

        formLayout->setWidget(2, QFormLayout::LabelRole, clientNameLabel);

        clientNameLineEdit = new QLineEdit(inputPage);
        clientNameLineEdit->setObjectName(QString::fromUtf8("clientNameLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, clientNameLineEdit);

        verticalSpacer_3 = new QSpacerItem(247, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(3, QFormLayout::FieldRole, verticalSpacer_3);

        phoneNumberLabel = new QLabel(inputPage);
        phoneNumberLabel->setObjectName(QString::fromUtf8("phoneNumberLabel"));

        formLayout->setWidget(4, QFormLayout::LabelRole, phoneNumberLabel);

        phoneNumberLineEdit = new QLineEdit(inputPage);
        phoneNumberLineEdit->setObjectName(QString::fromUtf8("phoneNumberLineEdit"));

        formLayout->setWidget(4, QFormLayout::FieldRole, phoneNumberLineEdit);

        verticalSpacer_4 = new QSpacerItem(247, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(5, QFormLayout::FieldRole, verticalSpacer_4);

        addressLabel = new QLabel(inputPage);
        addressLabel->setObjectName(QString::fromUtf8("addressLabel"));

        formLayout->setWidget(6, QFormLayout::LabelRole, addressLabel);

        addressLineEdit = new QLineEdit(inputPage);
        addressLineEdit->setObjectName(QString::fromUtf8("addressLineEdit"));

        formLayout->setWidget(6, QFormLayout::FieldRole, addressLineEdit);

        verticalSpacer_6 = new QSpacerItem(247, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        formLayout->setItem(7, QFormLayout::FieldRole, verticalSpacer_6);

        emailLabel = new QLabel(inputPage);
        emailLabel->setObjectName(QString::fromUtf8("emailLabel"));

        formLayout->setWidget(8, QFormLayout::LabelRole, emailLabel);

        emailLineEdit = new QLineEdit(inputPage);
        emailLineEdit->setObjectName(QString::fromUtf8("emailLineEdit"));

        formLayout->setWidget(8, QFormLayout::FieldRole, emailLineEdit);


        verticalLayout->addLayout(formLayout);

        verticalSpacer = new QSpacerItem(189, 13, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        addPushButton = new QPushButton(inputPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        horizontalLayout_2->addWidget(addPushButton);

        modifyPushButton = new QPushButton(inputPage);
        modifyPushButton->setObjectName(QString::fromUtf8("modifyPushButton"));

        horizontalLayout_2->addWidget(modifyPushButton);

        clearPushButton = new QPushButton(inputPage);
        clearPushButton->setObjectName(QString::fromUtf8("clearPushButton"));

        horizontalLayout_2->addWidget(clearPushButton);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_4->addLayout(verticalLayout);

        toolBox->addItem(inputPage, QString::fromUtf8("&Input"));
        searchPage = new QWidget();
        searchPage->setObjectName(QString::fromUtf8("searchPage"));
        searchPage->setGeometry(QRect(0, 0, 278, 336));
        verticalLayout_5 = new QVBoxLayout(searchPage);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        searchTableView = new QTableView(searchPage);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        searchTableView->setSelectionBehavior(QAbstractItemView::SelectRows);

        verticalLayout_3->addWidget(searchTableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchComboBox = new QComboBox(searchPage);
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->setObjectName(QString::fromUtf8("searchComboBox"));

        horizontalLayout->addWidget(searchComboBox);

        searchLineEdit = new QLineEdit(searchPage);
        searchLineEdit->setObjectName(QString::fromUtf8("searchLineEdit"));

        horizontalLayout->addWidget(searchLineEdit);


        verticalLayout_3->addLayout(horizontalLayout);

        searchPushButton = new QPushButton(searchPage);
        searchPushButton->setObjectName(QString::fromUtf8("searchPushButton"));

        verticalLayout_3->addWidget(searchPushButton);


        verticalLayout_5->addLayout(verticalLayout_3);

        toolBox->addItem(searchPage, QString::fromUtf8("&Search"));
        splitter->addWidget(toolBox);

        verticalLayout_6->addWidget(splitter);

#if QT_CONFIG(shortcut)
        clientIDLabel->setBuddy(clientIDLineEdit);
        clientNameLabel->setBuddy(clientNameLineEdit);
        phoneNumberLabel->setBuddy(phoneNumberLineEdit);
        addressLabel->setBuddy(addressLineEdit);
        emailLabel->setBuddy(emailLineEdit);
#endif // QT_CONFIG(shortcut)
        QWidget::setTabOrder(clientIDLineEdit, clientNameLineEdit);
        QWidget::setTabOrder(clientNameLineEdit, phoneNumberLineEdit);
        QWidget::setTabOrder(phoneNumberLineEdit, addressLineEdit);
        QWidget::setTabOrder(addressLineEdit, addPushButton);
        QWidget::setTabOrder(addPushButton, modifyPushButton);
        QWidget::setTabOrder(modifyPushButton, searchComboBox);
        QWidget::setTabOrder(searchComboBox, searchLineEdit);
        QWidget::setTabOrder(searchLineEdit, searchPushButton);

        retranslateUi(ClientManagerForm);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(ClientManagerForm);
    } // setupUi

    void retranslateUi(QWidget *ClientManagerForm)
    {
        ClientManagerForm->setWindowTitle(QCoreApplication::translate("ClientManagerForm", "ClientManagerForm", nullptr));
        clientInfoLabel->setText(QCoreApplication::translate("ClientManagerForm", "Client Information", nullptr));
        imageLabel->setText(QCoreApplication::translate("ClientManagerForm", "imageLabel", nullptr));
        clientIDLabel->setText(QCoreApplication::translate("ClientManagerForm", "&Client ID", nullptr));
        clientNameLabel->setText(QCoreApplication::translate("ClientManagerForm", "Client &Name", nullptr));
        phoneNumberLabel->setText(QCoreApplication::translate("ClientManagerForm", "&Phone Number", nullptr));
        phoneNumberLineEdit->setInputMask(QCoreApplication::translate("ClientManagerForm", "999-0000-9999", nullptr));
        addressLabel->setText(QCoreApplication::translate("ClientManagerForm", "&Address", nullptr));
        emailLabel->setText(QCoreApplication::translate("ClientManagerForm", "&Email", nullptr));
        addPushButton->setText(QCoreApplication::translate("ClientManagerForm", "&Add", nullptr));
        modifyPushButton->setText(QCoreApplication::translate("ClientManagerForm", "&Modify", nullptr));
        clearPushButton->setText(QCoreApplication::translate("ClientManagerForm", "Clear", nullptr));
        toolBox->setItemText(toolBox->indexOf(inputPage), QCoreApplication::translate("ClientManagerForm", "&Input", nullptr));
        searchComboBox->setItemText(0, QCoreApplication::translate("ClientManagerForm", "Client ID Search", nullptr));
        searchComboBox->setItemText(1, QCoreApplication::translate("ClientManagerForm", "Client Name Search", nullptr));
        searchComboBox->setItemText(2, QCoreApplication::translate("ClientManagerForm", "Phone Number Search", nullptr));
        searchComboBox->setItemText(3, QCoreApplication::translate("ClientManagerForm", "Address Search", nullptr));
        searchComboBox->setItemText(4, QCoreApplication::translate("ClientManagerForm", "Email Search", nullptr));

        searchPushButton->setText(QCoreApplication::translate("ClientManagerForm", "S&earch", nullptr));
        toolBox->setItemText(toolBox->indexOf(searchPage), QCoreApplication::translate("ClientManagerForm", "&Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ClientManagerForm: public Ui_ClientManagerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CLIENTMANAGERFORM_H
