/****************************************************************************
** Meta object code from reading C++ file 'ordermanagerform.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../ShopApp7/ordermanagerform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ordermanagerform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_OrderManagerForm_t {
    uint offsetsAndSizes[66];
    char stringdata0[17];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[28];
    char stringdata5[23];
    char stringdata6[12];
    char stringdata7[18];
    char stringdata8[11];
    char stringdata9[16];
    char stringdata10[21];
    char stringdata11[12];
    char stringdata12[6];
    char stringdata13[25];
    char stringdata14[28];
    char stringdata15[27];
    char stringdata16[28];
    char stringdata17[33];
    char stringdata18[23];
    char stringdata19[19];
    char stringdata20[13];
    char stringdata21[17];
    char stringdata22[37];
    char stringdata23[17];
    char stringdata24[32];
    char stringdata25[17];
    char stringdata26[5];
    char stringdata27[7];
    char stringdata28[14];
    char stringdata29[40];
    char stringdata30[17];
    char stringdata31[25];
    char stringdata32[26];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_OrderManagerForm_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_OrderManagerForm_t qt_meta_stringdata_OrderManagerForm = {
    {
        QT_MOC_LITERAL(0, 16),  // "OrderManagerForm"
        QT_MOC_LITERAL(17, 25),  // "sig_reduceInventoryAmount"
        QT_MOC_LITERAL(43, 0),  // ""
        QT_MOC_LITERAL(44, 19),  // "sig_requestSearchID"
        QT_MOC_LITERAL(64, 27),  // "sig_requesProductNameSearch"
        QT_MOC_LITERAL(92, 22),  // "sig_requesSearchClient"
        QT_MOC_LITERAL(115, 11),  // "productFind"
        QT_MOC_LITERAL(127, 17),  // "sig_calTotalPrice"
        QT_MOC_LITERAL(145, 10),  // "removeItem"
        QT_MOC_LITERAL(156, 15),  // "showContextMenu"
        QT_MOC_LITERAL(172, 20),  // "on_tableView_clicked"
        QT_MOC_LITERAL(193, 11),  // "QModelIndex"
        QT_MOC_LITERAL(205, 5),  // "index"
        QT_MOC_LITERAL(211, 24),  // "on_addPushButton_clicked"
        QT_MOC_LITERAL(236, 27),  // "on_modifyPushButton_clicked"
        QT_MOC_LITERAL(264, 26),  // "on_clearPushButton_clicked"
        QT_MOC_LITERAL(291, 27),  // "on_searchPushButton_clicked"
        QT_MOC_LITERAL(319, 32),  // "on_clientNameLineEdit_textEdited"
        QT_MOC_LITERAL(352, 22),  // "updateClientTreeWdiget"
        QT_MOC_LITERAL(375, 18),  // "QList<QStringList>"
        QT_MOC_LITERAL(394, 12),  // "updateClient"
        QT_MOC_LITERAL(407, 16),  // "slot_productName"
        QT_MOC_LITERAL(424, 36),  // "on_productNameComboBox_textAc..."
        QT_MOC_LITERAL(461, 16),  // "slot_productInfo"
        QT_MOC_LITERAL(478, 31),  // "on_clientTreeWidget_itemClicked"
        QT_MOC_LITERAL(510, 16),  // "QTreeWidgetItem*"
        QT_MOC_LITERAL(527, 4),  // "item"
        QT_MOC_LITERAL(532, 6),  // "column"
        QT_MOC_LITERAL(539, 13),  // "updateProduct"
        QT_MOC_LITERAL(553, 39),  // "on_purchaseQuantitySpinBox_va..."
        QT_MOC_LITERAL(593, 16),  // "updateTotalPrice"
        QT_MOC_LITERAL(610, 24),  // "producNameComboBoxModify"
        QT_MOC_LITERAL(635, 25)   // "productNameComboBoxRemove"
    },
    "OrderManagerForm",
    "sig_reduceInventoryAmount",
    "",
    "sig_requestSearchID",
    "sig_requesProductNameSearch",
    "sig_requesSearchClient",
    "productFind",
    "sig_calTotalPrice",
    "removeItem",
    "showContextMenu",
    "on_tableView_clicked",
    "QModelIndex",
    "index",
    "on_addPushButton_clicked",
    "on_modifyPushButton_clicked",
    "on_clearPushButton_clicked",
    "on_searchPushButton_clicked",
    "on_clientNameLineEdit_textEdited",
    "updateClientTreeWdiget",
    "QList<QStringList>",
    "updateClient",
    "slot_productName",
    "on_productNameComboBox_textActivated",
    "slot_productInfo",
    "on_clientTreeWidget_itemClicked",
    "QTreeWidgetItem*",
    "item",
    "column",
    "updateProduct",
    "on_purchaseQuantitySpinBox_valueChanged",
    "updateTotalPrice",
    "producNameComboBoxModify",
    "productNameComboBoxRemove"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OrderManagerForm[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    2,  170,    2, 0x06,    1 /* Public */,
       3,    1,  175,    2, 0x06,    4 /* Public */,
       4,    1,  178,    2, 0x06,    6 /* Public */,
       5,    1,  181,    2, 0x06,    8 /* Public */,
       6,    1,  184,    2, 0x06,   10 /* Public */,
       7,    2,  187,    2, 0x06,   12 /* Public */,
       7,    1,  192,    2, 0x26,   15 /* Public | MethodCloned */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    0,  195,    2, 0x08,   17 /* Private */,
       9,    1,  196,    2, 0x08,   18 /* Private */,
      10,    1,  199,    2, 0x08,   20 /* Private */,
      13,    0,  202,    2, 0x08,   22 /* Private */,
      14,    0,  203,    2, 0x08,   23 /* Private */,
      15,    0,  204,    2, 0x08,   24 /* Private */,
      16,    0,  205,    2, 0x08,   25 /* Private */,
      17,    1,  206,    2, 0x08,   26 /* Private */,
      18,    1,  209,    2, 0x08,   28 /* Private */,
      20,    1,  212,    2, 0x08,   30 /* Private */,
      21,    2,  215,    2, 0x08,   32 /* Private */,
      22,    1,  220,    2, 0x08,   35 /* Private */,
      23,    1,  223,    2, 0x08,   37 /* Private */,
      24,    2,  226,    2, 0x08,   39 /* Private */,
      28,    1,  231,    2, 0x08,   42 /* Private */,
      29,    1,  234,    2, 0x08,   44 /* Private */,
      30,    1,  237,    2, 0x08,   46 /* Private */,
      31,    2,  240,    2, 0x08,   48 /* Private */,
      32,    1,  245,    2, 0x08,   51 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, 0x80000000 | 19,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, 0x80000000 | 25, QMetaType::Int,   26,   27,
    QMetaType::Void, QMetaType::QStringList,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,

       0        // eod
};

void OrderManagerForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<OrderManagerForm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->sig_reduceInventoryAmount((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 1: _t->sig_requestSearchID((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->sig_requesProductNameSearch((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->sig_requesSearchClient((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->productFind((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 5: _t->sig_calTotalPrice((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 6: _t->sig_calTotalPrice((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: _t->removeItem(); break;
        case 8: _t->showContextMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 9: _t->on_tableView_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 10: _t->on_addPushButton_clicked(); break;
        case 11: _t->on_modifyPushButton_clicked(); break;
        case 12: _t->on_clearPushButton_clicked(); break;
        case 13: _t->on_searchPushButton_clicked(); break;
        case 14: _t->on_clientNameLineEdit_textEdited((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 15: _t->updateClientTreeWdiget((*reinterpret_cast< std::add_pointer_t<QList<QStringList>>>(_a[1]))); break;
        case 16: _t->updateClient((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 17: _t->slot_productName((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 18: _t->on_productNameComboBox_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 19: _t->slot_productInfo((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 20: _t->on_clientTreeWidget_itemClicked((*reinterpret_cast< std::add_pointer_t<QTreeWidgetItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 21: _t->updateProduct((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 22: _t->on_purchaseQuantitySpinBox_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 23: _t->updateTotalPrice((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 24: _t->producNameComboBoxModify((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 25: _t->productNameComboBoxRemove((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QList<QStringList> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (OrderManagerForm::*)(QString , int );
            if (_t _q_method = &OrderManagerForm::sig_reduceInventoryAmount; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(int );
            if (_t _q_method = &OrderManagerForm::sig_requestSearchID; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::sig_requesProductNameSearch; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::sig_requesSearchClient; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString );
            if (_t _q_method = &OrderManagerForm::productFind; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (OrderManagerForm::*)(QString , int );
            if (_t _q_method = &OrderManagerForm::sig_calTotalPrice; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject OrderManagerForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_OrderManagerForm.offsetsAndSizes,
    qt_meta_data_OrderManagerForm,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_OrderManagerForm_t
, QtPrivate::TypeAndForceComplete<OrderManagerForm, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QList<QStringList>, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QTreeWidgetItem *, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *OrderManagerForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OrderManagerForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_OrderManagerForm.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int OrderManagerForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    }
    return _id;
}

// SIGNAL 0
void OrderManagerForm::sig_reduceInventoryAmount(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void OrderManagerForm::sig_requestSearchID(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void OrderManagerForm::sig_requesProductNameSearch(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void OrderManagerForm::sig_requesSearchClient(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void OrderManagerForm::productFind(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void OrderManagerForm::sig_calTotalPrice(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
