#include "clientserverform.h"
#include "ui_clientserverform.h"
#include "logthread.h"
#include "ui_clientserverform.h"

#include <QPushButton>
#include <QBoxLayout>
#include <QTcpServer>
#include <QTcpSocket>
#include <QApplication>
#include <QMessageBox>
#include <QScrollBar>
#include <QDateTime>
#include <QDebug>
#include <QMenu>
#include <QFile>
#include <QFileInfo>
#include <QProgressDialog>

/* 생성자 */
ClientServerForm::ClientServerForm(QWidget *parent)
    : QWidget(parent),
    ui(new Ui::ClientServerForm), totalSize(0), byteReceived(0)
{
    ui->setupUi(this);
    QList<int> sizes;
    sizes << 120 << 500;
    ui->splitter->setSizes(sizes);

    ui->clientTreeWidget->hideColumn(2);                                    // clientTreeWidget의 2열을 숨깁니다.

    chatServer = new QTcpServer(this);                                      // chatServer 객체 생성
    connect(chatServer, SIGNAL(newConnection( )), SLOT(clientConnect( )));
    if (!chatServer->listen(QHostAddress::Any, PORT_NUMBER)) {              // chatServer로 접속하는 포트 번호가 PORT_NUMBER(8000)가 아닐 경우
        QMessageBox::critical(this, tr("Chatting Server"),
                              tr("Unable to start the server: %1.")         // "Unable to start the server: %1." 경고창 띄우기
                              .arg(chatServer->errorString( )));
        close( );
        return;
    }

    fileServer = new QTcpServer(this);                                      // chatServer 객체 생성
    connect(fileServer, SIGNAL(newConnection()), SLOT(acceptConnection()));
    if (!fileServer->listen(QHostAddress::Any, PORT_NUMBER+1)) {            // fileServer로 접속하는 포트 번호가 PORT_NUMBER+1이 아닐 경우
        QMessageBox::critical(this, tr("Chatting Server"),
                              tr("Unable to start the server: %1.")         // "Unable to start the server: %1." 경고창 띄우기
                              .arg(fileServer->errorString( )));
        close( );
        return;
    }

    qDebug("Start listening ...");

    /* 초대(Invite) 기능 생성 */
    QAction* inviteAction = new QAction(tr("&Invite"));
    inviteAction->setObjectName("Invite");
    connect(inviteAction, SIGNAL(triggered()), SLOT(inviteClient()));

    /* 강퇴(Kick Out) 기능 생성 */
    QAction* removeAction = new QAction(tr("&Kick out"));
    connect(removeAction, SIGNAL(triggered()), SLOT(kickOut()));
    menu = new QMenu;                                                       // menu 생성
    menu->addAction(inviteAction);                                          // menu에 inviteAction(초대 기능) 추가
    menu->addAction(removeAction);                                          // menu에 removeAction(삭제 기능) 추가
    ui->clientTreeWidget->setContextMenuPolicy(Qt::CustomContextMenu);      // clientTreeWidget에서 메뉴 기능 사용 가능
    progressDialog = new QProgressDialog(0);                                // progressDialog 객체 생성
    progressDialog->setAutoClose(true);                                     // 대화상자를 reset()으로 숨길지 여부를 유지합니다.
    progressDialog->reset();                                                // 대화상자 숨김
    logThread = new LogThread(this);                                        // logThread 객체 생성
    logThread->start();                                                     // logThread 시작
    connect(ui->savePushButton, SIGNAL(clicked()), logThread, SLOT(saveData()));    // save 버튼을 누르면 데이터가 저장됩니다.
    qDebug() << tr("The server is running on port %1.").arg(chatServer->serverPort( ));
}

/* 소멸자 */
ClientServerForm::~ClientServerForm()
{
    delete ui;
    logThread->terminate();                                                 // logThread 종료
    chatServer->close( );                                                   // chatServer 닫음
    fileServer->close( );                                                   // fileServer 닫음
}

/* 채팅 서버 */
void ClientServerForm::clientConnect( )
{
    QTcpSocket *clientConnection = chatServer->nextPendingConnection( );        // 보류 중인 다음 연결을 연결된 QTcpSocket 개체로 반환합니다.
    connect(clientConnection, SIGNAL(readyRead( )), SLOT(receiveData( )));      // 연결된 신호가 있으면 데이터를 읽습니다.
    connect(clientConnection, SIGNAL(disconnected( )), SLOT(removeClient()));   // 연결이 끊어지면 서버와 접속된 고객이 로그아웃 됩니다.
    qDebug("new connection is established...");
}

void ClientServerForm::receiveData( )                                       // 데이터를 받는 함수
{
    QTcpSocket *clientConnection = dynamic_cast<QTcpSocket *>(sender( ));
    QByteArray bytearray = clientConnection->read(BLOCK_SIZE);
    Chat_Status type;                                                       // 채팅의 종류
    char data[1020];                                                        // 전송되는 메시지/데이터
    memset(data, 0, 1020);                                                  // 범위를 벗어나는 데이터는 초기화
    QDataStream in(&bytearray, QIODevice::ReadOnly);
    in.device()->seek(0);                                                   // 현재 위치를 pos로 설정하여 성공 시 true를 반환하고 오류가 발생하면 false를 반환합니다.
    in >> type;
    in.readRawData(data, 1020);                                             // 1024byte - type(4byte) = 1020byte 만큼 데이터를 읽습니다.

    QString ip = clientConnection->peerAddress().toString();                // 연결된 IP주소
    quint16 port = clientConnection->peerPort();                            // 연결된 포트 번호
    QString name = QString::fromStdString(data);                            // 연결된 고객 이름

    qDebug() << ip << " : " << type;

    switch(type) {                                                          // 채팅의 종류
    case Chat_Login:                                                                             // 로그인하는 경우 (대기실에 접속)
    {
        foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchFixedString, 1)) {     // 대기실에 접속한 고객 이름을 1열에 보여줍니다.
            if(item->text(2) != "-") {
                item->setText(2, "-");
                item->setIcon(0, QIcon("p8.png"));                                               // 대기실에 접속했다는 아이콘을 0열에 출력합니다.
                clientList.append(clientConnection);                                             // QList<QTcpSocket*> clientList;
                clientSocketHash[name] = clientConnection;
            }
        }
        break;
    }
    case Chat_In:                                                                               // 채팅방에 입장하는 경우
        foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchFixedString, 1)) {    // 채팅방에 접속한 고객 이름을 1열에 보여줍니다.
            if(item->text(2) != "O") {
                item->setText(2, "O");
                item->setIcon(0, QIcon("g3.png"));                                              // 채팅방에 접속했다는 아이콘을 0열에 출력합니다.
            }
            clientNameHash[port] = name;
        }
        break;
    case Chat_Talk: {                                                                           // 채팅방에서 대화하는 경우
        foreach(QTcpSocket *sock, clientList) {
            qDebug() << sock->peerPort();
            if(clientNameHash.contains(sock->peerPort()) && sock != clientConnection) {         // 예외처리
                QByteArray sendArray;                                                           // 보내는 사람(나)을 제외한 모든 사람들에게 메세지가 전송됩니다.
                sendArray.clear();                                                              // 초기화
                QDataStream out(&sendArray, QIODevice::WriteOnly);
                out << Chat_Talk;                                                               // 메세지가 출력되는 경우
                sendArray.append("<font color=darkCyan>");                                      // 보내는 사람 이름 색상 설정
                sendArray.append(clientNameHash[port].toStdString().data());
                sendArray.append("</font> : ");                                                 // 보내는 사람 이름 : 메세지 내용
                sendArray.append(name.toStdString().data());                                    // 보내는 사람의 이름을 보여줍니다.
                sock->write(sendArray);
                qDebug() << sock->peerPort();
            }
        }
        QTreeWidgetItem* item = new QTreeWidgetItem(ui->messageTreeWidget);                     // messageTreeWidget에 보여줄 item 객체 생성
        item->setText(0, ip);                                                                   // item의 0열: ip주소
        item->setText(1, QString::number(port));                                                // item의 1열: Port 번호
        item->setText(2, QString::number(clientIDHash[clientNameHash[port]]));                  // item의 2열: 고객 ID
        item->setText(3, clientNameHash[port]);                                                 // item의 3열: 고객 이름
        item->setText(4, QString(data));                                                        // item의 4열: 메시지 내용 출력
        item->setText(5, QDateTime::currentDateTime().toString());                              // item의 5열: 현재 시간
        item->setToolTip(4, QString(data));
        ui->messageTreeWidget->addTopLevelItem(item);                                           // messageTreeWidget에 item에 담은 정보들을 출력해줍니다.
        for(int i = 0; i < ui->messageTreeWidget->columnCount(); i++)
            ui->messageTreeWidget->resizeColumnToContents(i);                                   // 크기에 맞기 사이즈를 지정해 줌
        logThread->appendData(item);
    }
        break;
    case Chat_Out:                                                                              // 채팅방을 나가는 경우 (대기실에 접속)
        foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchContains, 1)) {       // 채팅방을 나가는 고객 이름을 1열에 보여줍니다.
            if(item->text(2) != "-") {
                item->setText(2, "-");
                item->setIcon(0, QIcon("p8.png"));                                              // 대기실에 접속했다는 아이콘을 0열에 출력합니다
            }
            clientNameHash.remove(port);
        }
        break;
    case Chat_LogOut:                                                                           // 로그아웃하는 경우 (서버와 접속이 끊김)
        foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchContains, 1)) {       // 로그아웃하는 고객 이름을 1열에 보여줍니다.
            if(item->text(2) != "X") {
                item->setText(2, "X");
                item->setIcon(0, QIcon("x5ling.png"));                                          // 서버와 연결이 끊겼다는 아이콘을 0열에 출력합니다.
                clientList.removeOne(clientConnection);                                         // QList<QTcpSocket*> clientList;
                clientSocketHash.remove(name);
            }
        }
        break;
    }
}

void ClientServerForm::removeClient()                                                           // 서버와 연결이 끊긴 경우
{
    QTcpSocket *clientConnection = dynamic_cast<QTcpSocket *>(sender( ));
    QString name = clientNameHash[clientConnection->peerPort()];
    foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchContains, 1)) {           // 서버와 연결이 안된 고객 이름을 1열에 보여줍니다.
        item->setText(2, "X");
        item->setIcon(0, QIcon("x5ling.png"));                                                  // 서버와 연결이 끊겼다는 아이콘을 0열에 출력합니다
    }
    clientList.removeOne(clientConnection);
    clientConnection->deleteLater();
}

/* clientManagerForm에서 고객을 추가하면 clientServerForm에서도 고객 정보가 추가되는 슬롯 */
void ClientServerForm::addClient(int clientID, QString clientName)                              // clientManagerForm에 있는 고객 ID 고객 이름을 인자로 받음
{
    clientIDList << clientID;                                                                   // 일치하는 고객 ID
    QTreeWidgetItem* item = new QTreeWidgetItem(ui->clientTreeWidget);                          // clientTreeWidget에 보여줄 item 객체 생성
    item->setText(2, "X");
    item->setIcon(0, QIcon("x5ling.png"));                                                      // 서버와 연결이 안됐다는 아이콘을 item의 0열에 출력합니다.
    item->setText(1, clientName);                                                               // item의 1열에 고객 이름을 출력합니다.
    ui->clientTreeWidget->addTopLevelItem(item);                                                // clientTreeWidget에 item에 담은 정보들을 출력해줍니다.
    clientIDHash[clientName] = clientID;
    ui->clientTreeWidget->resizeColumnToContents(0);                                            // 크기에 맞기 사이즈를 지정해 줌
}

/* clientManagerForm에서 고객 정보를 변경하면 clientServerForm에서도 고객 정보가 변경되는 슬롯 */
void ClientServerForm::slot_updateModifyClient(int clientID, int index, QString clientName)     // clientManagerForm에 있는 고객ID, 인덱스, 고객 이름을 인자로 받음
{
    ui->clientTreeWidget->topLevelItem(index)->setText(1, clientName);                          // clientTreeWidget의 1열에 인덱스와 일치하는 고객이름을 나타냅니다.
    clientIDHash[clientName] = clientID;
}

/* clientTreeWidget에서 오른쪽 마우스를 누르면 메뉴 기능(초대)을 실행할 수 있는 함수 */
void ClientServerForm::on_clientTreeWidget_customContextMenuRequested(const QPoint &pos)
{
    foreach(QAction *action, menu->actions()) {
        if(action->objectName() == "Invite")                                                    // 메뉴에 있는 Invite를 누른 경우
            action->setEnabled(ui->clientTreeWidget->currentItem()->text(2) != "O");
        else
            action->setEnabled(ui->clientTreeWidget->currentItem()->text(2) == "O");
    }
    QPoint globalPos = ui->clientTreeWidget->mapToGlobal(pos);
    menu->exec(globalPos);
}

/* 강퇴 기능을 수행하는 함수 */
void ClientServerForm::kickOut()
{
    if(ui->clientTreeWidget->currentItem() != nullptr) {                                        // 예외처리
        QString name = ui->clientTreeWidget->currentItem()->text(1);                            // clientTreeWidget의 1열에 고객 이름
        QTcpSocket* sock = clientSocketHash[name];
        QByteArray sendArray;
        QDataStream out(&sendArray, QIODevice::WriteOnly);
        out << Chat_KickOut;                                                                    // 해당 고객을 채팅방으로부터 강퇴시킵니다.
        out.writeRawData("", 1020);
        sock->write(sendArray);
        ui->clientTreeWidget->currentItem()->setText(2, "-");
        ui->clientTreeWidget->currentItem()->setIcon(0, QIcon("p8.png"));                       // 강퇴되어 대기실에 재접속된 아이콘을 0열에 출력합니다.
    }
}

/* 초대 기능을 수행하는 함수 */
void ClientServerForm::inviteClient()
{
    if(ui->clientTreeWidget->topLevelItemCount()) {
        QString name = ui->clientTreeWidget->currentItem()->text(1);                            // clientTreeWidget의 1열에 있는 정보
        QByteArray sendArray;
        QDataStream out(&sendArray, QIODevice::WriteOnly);
        out << Chat_Invite;                                                                     // 해당 고객을 채팅방으로 초대합니다.
        out.writeRawData("", 1020);
        QTcpSocket* sock = clientSocketHash[name];                                              // 고객 이름이 담긴 sock 객체 생성
        if(sock == nullptr) {                                                                   // 고객 이름이 없으면
            return;                                                                             // 반환
        }
        sock->write(sendArray);
        foreach(auto item, ui->clientTreeWidget->findItems(name, Qt::MatchFixedString, 1)) {    // clientTreeWidget의 1열에 있는 고객 정보
            if(item->text(1) != "O") {
                item->setText(2, "O");
                item->setIcon(0, QIcon("g3.png"));                                              // 채팅방에 입장되었다는 아이콘을 0열에 출력합니다.
            }
        }
        quint64 port = sock->peerPort();
        clientNameHash[port] = name;
    }
}

/* 파일 서버 */
void ClientServerForm::acceptConnection()
{
    qDebug("Connected, preparing to receive files!");
    QTcpSocket* receivedSocket = fileServer->nextPendingConnection();
    connect(receivedSocket, SIGNAL(readyRead()), this, SLOT(readClient()));
}

/* 파일 전송 */
void ClientServerForm::readClient()
{
    qDebug("Receiving file ...");
    QTcpSocket* receivedSocket = dynamic_cast<QTcpSocket *>(sender( ));
    QString filename;
    QString name;

    if (byteReceived == 0) {                                                                    // 데이터를 받습니다.
        progressDialog->reset();                                                                // progressDialog 리셋
        progressDialog->show();

        QString ip = receivedSocket->peerAddress().toString();                                  // 연결된 IP주소
        quint16 port = receivedSocket->peerPort();                                              // 연결된 포트번호
        qDebug() << receivedSocket->peerName();
        QDataStream in(receivedSocket);
        in >> totalSize >> byteReceived >> filename >> name;
        progressDialog->setMaximum(totalSize);

        QTreeWidgetItem* item = new QTreeWidgetItem(ui->messageTreeWidget);                     // messageTreeWidget에 보여줄 item 객체 생성
        item->setText(0, ip);                                                                   // item의 0열: ip주소
        item->setText(1, QString::number(port));                                                // item의 1열: 포트 번호
        item->setText(2, QString::number(clientIDHash[name]));                                  // item의 2열: 고객 이름과 일치하는 고객 ID
        item->setText(3, name);                                                                 // item의 3열: 고객 이름
        item->setText(4, filename);                                                             // item의 4열: 메세지 전송 내용
        item->setText(5, QDateTime::currentDateTime().toString());                              // item의 5열: 메세지 전송 시간
        item->setToolTip(4, filename);

        for(int i = 0; i < ui->messageTreeWidget->columnCount(); i++)
            ui->messageTreeWidget->resizeColumnToContents(i);                                   // 크기에 맞기 사이즈를 지정해 줌
        ui->messageTreeWidget->addTopLevelItem(item);                                           // messageTreeWidget에 item에 담은 정보들을 출력해줍니다.
        logThread->appendData(item);

        QFileInfo info(filename);
        QString currentFileName = info.fileName();
        file = new QFile(currentFileName);                                                      // 파일 생성
        file->open(QFile::WriteOnly);
    } else {                                                                                    // 파일 내용을 읽습니다.
        inBlock = receivedSocket->readAll();
        byteReceived += inBlock.size();
        file->write(inBlock);                                                                   // 파일을 쓰고 난 후
        file->flush();                                                                          // 파일을 비웁니다.
    }
    progressDialog->setValue(byteReceived);
    if (byteReceived == totalSize) {                                                            // byteReceive와 totalSize가 같으면
        qDebug() << QString("%1 receive completed").arg(filename);
        inBlock.clear();                                                                        // inBlock 초기화
        byteReceived = 0;
        totalSize = 0;
        progressDialog->reset();                                                                // progressDialog 리셋
        progressDialog->hide();                                                                 // progressDialog 숨김
        file->close();                                                                          // 파일을 닫습니다.
        delete file;                                                                            // 파일 삭제
    }
}

/* treeWidget을 인자로 받은 정보와 일치하는 고객 이름이 있는지 찾고 있다면 이미 로그인 되어 있는지 없는지 확인하는 슬롯 */
void ClientServerForm::slot_checkLogin(QString name, int id)
{
    for(int i=0; i < ui->clientTreeWidget->topLevelItemCount(); i++) {
        /* clientManagerForm에 있는 고객 이름과 clientServerForm에 있는 고객 이름이 일치하는 경우 */
        if(ui->clientTreeWidget->topLevelItem(i)->text(1) == name) {
            if(ui->clientTreeWidget->topLevelItem(i)->text(2) == "X") {     // clientTreeWidget의 2열이 "X" 인 경우 (로그인 되어 있는지 없는지 확인합니다.)
                /* int login = 1 : 정상적으로 로그인이 가능한 경우*/
                emit sig_checkLogin(1, id);                                 // 이 경우에만 로그인이 가능하므로 로그인 가능여부(1)와 고객 ID를 [시그널:sig_checkLogin]로 전달합니다.
                return;
            }
            else {                                                          // 이미 로그인 되어 있는 경우
                emit sig_checkLogin(2, id);                                 // 로그인 가능여부(2)와 고객 ID를 [시그널:sig_checkLogin]로 전달합니다.
                return;
            }
        }
    }
    emit sig_checkLogin(3, id);                                             // 등록된 고객이 아닌 경우 로그인 가능여부(3)와 고객 ID를 [시그널:sig_checkLogin]로 전달합니다.
}

/* clientManagerForm에서 등록된 고객을 삭제한 경우 clientServerManagerForm의 clientTreeWidget을 업데이트(고객 삭제) 해주는 슬롯 */
void ClientServerForm::slot_updateClientInfo(QString clientName)
{
    int idx = -1;
    for(int i = 0; i < ui->clientTreeWidget->topLevelItemCount(); i++)
    {
        /* clientTreeWidget의 고객 이름과 인자로 받은 clientManagerForm에 있는 고객 이름이 일치하는 경우 */
        if(ui->clientTreeWidget->topLevelItem(i)->text(1) == clientName) {
            idx = i;
            break;
        }
    }
    /* clientTreeWidget의 고객 이름과 인자로 받은 고객 이름이 일치하지 않으면 clientTreeWidget을 업데이트(고객 삭제) 해줍니다. */
    if(idx != -1) {
        ui->clientTreeWidget->takeTopLevelItem(idx);
        ui->clientTreeWidget->update();
    }
}

/* Clear 버튼을 누르면 messageTreeWidget이 초기화 됩니다. */
void ClientServerForm::on_clearPushButton_clicked()
{
    ui->messageTreeWidget->clear();
}



