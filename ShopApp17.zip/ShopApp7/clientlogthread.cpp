#include "clientlogthread.h"

#include <QTreeWidgetItem>
#include <QFile>
#include <QDateTime>

ClientLogThread::ClientLogThread(QString name, QObject *parent)
    : QThread{parent}
{
    QString format = "yyyyMMdd_hhmmss";                                                                 // 날짜 및 시간 형식 지정
    filename = QString("log_%1_%2.txt").arg(name).arg(QDateTime::currentDateTime().toString(format));   // 파일 이름 = log_고객이름_날짜_시분초
}

void ClientLogThread::run()
{
    Q_FOREVER {
        saveData();     // 데이터 저장
        sleep(5);       // 5초마다 저장
    }
}

void ClientLogThread::appendData(QStringList item)                      // 데이터 출력
{
    itemList.append(item);
}

void ClientLogThread::saveData()                                        // 데이터 저장
{
    if(itemList.count() > 0) {                                          // 데이터가 있는 경우 (예외처리)
        QFile file(filename);                                           // 파일 이름
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
            return;

        QTextStream out(&file);                                         // 파일 출력
        foreach(auto item, itemList) {                                  // itemList에 담긴 파일 출력 형식
            out << item.at(0) << ", ";                                  // item의 첫번째: 서버 주소
            out << item.at(1) << ", ";                                  // item의 두번째: 포트 번호
            out << item.at(2) << ", ";                                  // item의 세번째: 고객 이름
            out << item.at(3) << ", ";                                  // item의 네번째: 해당 고객이 전송한 채팅 내용
            out << item.at(4) << "\n";                                  // item의 다섯번째: 채팅을 전송한 날짜 및 시간
        }
        file.close();                                                   // 파일 닫음
    }
}
