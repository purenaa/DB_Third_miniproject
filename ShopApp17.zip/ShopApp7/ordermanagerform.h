#ifndef ORDERMANAGERFORM_H
#define ORDERMANAGERFORM_H

//#include "client.h"
//#include "order.h"
//#include "product.h"
#include <QWidget>

class QMenu;
class QTreeWidgetItem;
class ProductManagerForm;
class ClientManagerForm;
class QSqlTableModel;
class QStandardItemModel;

namespace Ui { class OrderManagerForm; }

class OrderManagerForm : public QWidget
{
    Q_OBJECT

public:
    explicit OrderManagerForm(QWidget *parent = nullptr);       // 생성자 (DB를 열 때)
    ~OrderManagerForm();                                        // 소멸자 (DB를 닫을 때)
    void headerName();                                          // searchTableView의 0~6열까지 헤더 이름을 지정해주는 함수
    void loadData();                                            // DB 생성
    void clear();

private:
    int makeId();                                               // 주문 ID를 자동 할당해주는 함수
    Ui::OrderManagerForm *ui;                                   // OrderManagerForm의 ui
    /* 멤버변수 */
    int clientID;
    QMenu* menu;                                                // QMenu 클래스는 상황에 맞는 팝업 메뉴에서 사용할 수 있는 메뉴 위젯을 제공
    QSqlTableModel* orderModel;                                 // 주문 커리모델
    QStandardItemModel* searchModel;                            // 검색 커리모델

private slots:   
    /* tableView를 위한 슬롯 */
    void removeItem();                                          // tableView에 있는 항목을 제거해주는 함수
    void showContextMenu(const QPoint &);                       // 오른쪽 마우스 버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수
    void on_tableView_clicked(const QModelIndex &index);        // tableView의 항목을 선택했을 때
    void on_addPushButton_clicked();                            // 주문을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작
    void on_modifyPushButton_clicked();                         // modify 버튼을 누르면 이미 추가된 주문 정보가 변경됩니다.
    void on_clearPushButton_clicked();                          // clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수
    void on_searchPushButton_clicked();                         // 주문 정보를 조회하고 싶을 때 Search 버튼을 누르면 조회하실 수 있습니다.

    /* clientNameLineEdit에 고객 이름을 입력하고 Enter를 누르면 입력한 고객 이름을 [시그널:sig_requesSearchClient]로 전달합니다. */
    void on_clientNameLineEdit_textEdited(const QString);

    /* orderManagerForm의 clinetLineEdit에 입력한 고객 이름과 일치하는 고객 정보를 clientManagerForm에서 찾아 clientTreeWidget에 출력해주는 슬롯 */
    void updateClientTreeWdiget(QList<QStringList>);

    /* orderManagerForm의 tableView에서 주문 정보를 클릭했을 때 해당 고객 ID와 일치하는 고객 정보를 clientTreeWidget에 출력하는 슬롯 */
    void updateClient(QStringList);

    /* productManagerForm에서 전달받은 제품 이름을 orderManagerForm의 productNameComboBox에 출력해주는 슬롯 */
    void slot_productName(int, QString);

    /* productNameComboBox에서 제품을 선택하면 해당 제품 이름을 [시그널:productFind]로 전달합니다. */
    void on_productNameComboBox_textActivated(const QString);

    /* 주문할 때 productNameComboBox에서 선택한 제품 이름과 일치하는 제품 정보를 productManagerForm에서 찾아 productTreeWidget에 출력해주는 슬롯 */
    void slot_productInfo(QStringList);

    /* 동명이인일 경우 clientTableWidget에 출력된 고객 이름 중 해당하는 고객을 선택하기 위한 함수 */
    void on_clientTreeWidget_itemClicked(QTreeWidgetItem *item, int column);

    /* orderManagerForm의 tableView에서 주문 정보를 클릭했을 때 해당 제품 이름과 일치하는 제품 정보를 productTreeWidget에 출력하는 슬롯 */
    void updateProduct(QStringList);

    /* purchaseQuantitySpinBox의 값이 변경될 때 제품 이름과 구매 수량을 [시그널:sig_calTotalPrice]로 전달합니다. */
    void on_purchaseQuantitySpinBox_valueChanged(int);

    /* 구매 수량에 따라 계산된 총 구매가격을 totalPriceLineEdit에 출력시켜주는 슬롯 */
    void updateTotalPrice(int);

    /* productManagerForm에서 제품 이름을 변경하면 orderManagerForm의 productNameComboBox에도 변경된 제품 이름이 출력되는 슬롯 */
    void producNameComboBoxModify(int, QString);

    /* productManagerForm에서 제품 이름을 삭제하면 orderManagerForm의 productNameComboBox에도 해당 제품이 삭제되는 슬롯 */
    void productNameComboBoxRemove(int);

signals:
    /* 변경된 제품 이름과 구매수량(변경된 구매 수량 - 기존 구매 수량)을 [시그널:sig_reduceInventoryAmount]로 전달합니다. */
    void sig_reduceInventoryAmount(QString, int);

    /* tableView에서 선택된 주문 정보의 고객 ID를 [시그널:sig_requestSearchID]로 전달합니다. */
    void sig_requestSearchID(int);

    /* tableView에서 선택된 주문 정보의 제품 이름을 [시그널:sig_requesProductNameSearch]로 전달합니다. */
    void sig_requesProductNameSearch(QString);

    /* clientNameLineEdit에 입력한 고객 이름을 [시그널:sig_requesSearchClient]로 전달합니다. */
    void sig_requesSearchClient(QString);

    /* productComboBox에서 선택된 제품 이름을 [시그널:productFind]로 전달합니다. */
    void productFind(QString);

    /* 제품 이름과 구매 수량을 [시그널:sig_calTotalPrice]로 전달합니다. */
    void sig_calTotalPrice(QString, int = -1);
};

#endif // ORDERMANAGERFORM_H
