#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDataStream>

#include "clientserverform.h"

class QTextEdit;
class QLineEdit;
class QTcpSocket;
class QPushButton;
class QFile;
class QProgressDialog;
class ClientLogThread;

class ChatClient : public QWidget
{
    Q_OBJECT

public:
    const int PORT_NUMBER = 8000;
    ChatClient(QWidget *parent = nullptr, int id = 0);
    ~ChatClient();

private:
    void closeEvent(QCloseEvent*) override;     // 창이 닫힐 때 서버에 연결 접속 메시지를 보내고 종료
    QLineEdit *name;                            // 고객 이름을 입력하는 창
    QTextEdit *message;                         // 서버에서 오는 메세지 표시용
    QLineEdit* serverAddress;                   // IP 주소
    QLineEdit* serverPort;                      // 포트 번호
    QLineEdit *inputLine;                       // 서버로 보내는 메시지 입력창
    QPushButton *connectButton;                 // 서버 로그인 등 접속 처리하는 연결 버튼
    QPushButton *sendButton;                    // 메시지 전송 버튼
    QPushButton* fileButton;                    // 파일 전송 버튼
    QTcpSocket *clientSocket;                   // 클라이언트용 소켓
    QTcpSocket *fileClient;
    QProgressDialog* progressDialog;            // 파일 진행 확인
    QFile* file;                                // 서버로 보내는 파일
    qint64 loadSize;                            // 파일의 크기
    qint64 byteToWrite;                         // 보내는 파일의 크기
    qint64 totalSize;                           // 전체 파일의 크기
    QByteArray outBlock;                        // 전송을 위한 데이터
    bool isSent;                                // 파일 서버에 접속되었는지 확인
    int ID;
    int flag = 0;
    ClientLogThread* clientLogThread;

private slots:
    void receiveData();			// 서버에서 데이터가 올 때
    void sendData();               // 서버로 데이터를 보낼 때
    void disconnect();
    void sendProtocol(Chat_Status, char*, int = 1020);
    void sendFile();
    void goOnSend(qint64);
    void slot_login(int, int);

signals:
    void sig_checkLogin(QString, int);          /* Log In 버튼을 누르면 고객 이름과 고객 ID를 [시그널:sig_checkLogin]로 전달합니다.*/
};
#endif // WIDGET_H
