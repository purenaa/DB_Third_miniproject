#include "ordermanagerform.h"
#include "ui_ordermanagerform.h"

#include <QFile>
#include <QMenu>
#include <QDate>
#include <QDateEdit>
#include <QPalette>
#include <QTreeWidgetItem>
#include <QMessageBox>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QStandardItemModel>
#include <QMessageBox>

/* 생성자 (DB를 열 때) */
OrderManagerForm::OrderManagerForm(QWidget *parent)
    : QWidget(parent), ui(new Ui::OrderManagerForm),
      clientID(-1)
{
    ui->setupUi(this);                                                  // 지정한 위젯에 대한 사용자 인터페이스를 설정

    QList<int> sizes;
    sizes << 1850 << 1350;                                              // 1850 : tableView size, 1350 : toolBox size
    ui->splitter->setSizes(sizes);                                      // splitter 크기 조절

    QAction* removeAction = new QAction(tr("&Remove"));                 // 삭제 기능 생성
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));     // remove할 때 시그널 슬롯 발생
    menu = new QMenu;                                                   // menu : 멤버변수       //메뉴 생성
    QDate now = QDate::currentDate();                                   // now : 현재날짜
    menu->addAction(removeAction);                                      // 메뉴에 remove 기능 추가
    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));                 // searchLineEdit에서의 시그널과 on_searchPushButton_clicked 슬롯 연결

    /* 0행의 0~6열(7개)까지 헤더 이름을 지정 */
    searchModel = new QStandardItemModel(0, 7);
    headerName();
    ui->searchTableView->setModel(searchModel);
    ui->purchaseDayDateEdit->setDate(now);                              // purchaseDayDateEdit을 현재날짜로 설정
    ui->purchaseDayDateEdit->setCalendarPopup(true);                    // 화살표 버튼을 클릭하면 달력 팝업이 표시됩니다.
}

/* searchTableView의 0~6열까지 헤더 이름을 지정해주는 함수 */
void OrderManagerForm::headerName()
{
    searchModel->setHeaderData(0, Qt::Horizontal, tr("주문 ID"));
    searchModel->setHeaderData(1, Qt::Horizontal, tr("구매 날짜"));
    searchModel->setHeaderData(2, Qt::Horizontal, tr("고객 ID"));
    searchModel->setHeaderData(3, Qt::Horizontal, tr("고객 이름"));
    searchModel->setHeaderData(4, Qt::Horizontal, tr("제품 이름"));
    searchModel->setHeaderData(5, Qt::Horizontal, tr("구매 수량"));
    searchModel->setHeaderData(6, Qt::Horizontal, tr("총 가격"));
}

/* DB 생성 */
void OrderManagerForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "orderConnection");      // 데이터베이스를 만듦
    db.setDatabaseName("OrderDBlist.db");                                           // DB이름 : OrderDBlist
    if(db.open()) {                                                                 // DB를 열 때
        QSqlQuery query(db);                                                        // DB에 커리생성

        /* 테이블을 생성하고 0~6열까지 헤더 이름을 지정해줍니다. */
        query.exec("CREATE TABLE IF NOT EXISTS OrderDB(id INTEGER Primary Key,"
                   "purchaseDay VARCHAR(20), clientID INTEGER, clientName VARCHAR(30) NOT NULL, "
                   "productName VARHCHAR(50), purchaseQuantity INTEGER, totalPrice INTEGER);");
        orderModel = new QSqlTableModel(this, db);
        orderModel->setTable("OrderDB");                                            // 테이블명 : OrderDB
        orderModel->select();                                                       // orderModel을 재정렬
        /* 주문 tableView의 0~6열까지 헤더 이름을 지정해주는 함수 */
        orderModel->setHeaderData(0, Qt::Horizontal, tr("주문 ID"));
        orderModel->setHeaderData(1, Qt::Horizontal, tr("구매 날짜"));
        orderModel->setHeaderData(2, Qt::Horizontal, tr("고객 ID"));
        orderModel->setHeaderData(3, Qt::Horizontal, tr("고객 이름"));
        orderModel->setHeaderData(4, Qt::Horizontal, tr("제품 이름"));
        orderModel->setHeaderData(5, Qt::Horizontal, tr("구매 수량"));
        orderModel->setHeaderData(6, Qt::Horizontal, tr("총 가격"));
        ui->tableView->setModel(orderModel);                                        // tableView에 지정해준 헤더 이름을 가진 모델을 보여줍니다.
        ui->tableView->resizeColumnsToContents();                                   // 이름 크기에 맞기 사이즈를 지정해 줌
    }
}

/* 소멸자 (DB를 닫을 때) */
OrderManagerForm::~OrderManagerForm()
{
    delete ui;
    QSqlDatabase db = QSqlDatabase::database("orderConnection");
    if(db.isOpen()) {                           // DB를 열 때
        orderModel->submitAll();                // 보류 중인 모든 변경 사항을 제출하고 성공 시 true를 반환합니다.
        delete orderModel;                      // orderModel 삭제
        db.commit();                            // DB 트랜잭션을 데이터베이스에 커밋합니다. 작업이 성공하면 true를 반환합니다. 그렇지 않으면 false를 반환합니다.
        db.close();                             // DB 닫음
    }
}

/* 주문 ID를 자동 할당해주는 함수 */
int OrderManagerForm::makeId( )
{
    if(orderModel->rowCount() == 0) {                                       // clientModel의 행의 개수가 0일 때
        return 1000000;                                                     // 1000000을 반환 (첫 번째 고객 ID는 1이 됩니다.)
    } else {
        auto orderID = orderModel->data(orderModel->index(orderModel->rowCount()-1, 0)).toInt();
        return ++orderID;
    }
}

/* tableView에 있는 항목을 제거해주는 함수 */
void OrderManagerForm::removeItem()
{
    QModelIndex index = ui->tableView->currentIndex();                      // tableView의 현재 인덱스
    if(index.isValid()) {
        QString productName = orderModel->data(index.siblingAtColumn(4)).toString();
        int purchaseQuantity = orderModel->data(index.siblingAtColumn(5)).toInt();
        orderModel->removeRow(index.row());                                 // orderModel의 해당 인덱스에 있는 행을 제거해줍니다.
        orderModel->select();                                               // orderModel을 재정렬
        ui->tableView->update();                                            // 인덱스 업데이트
        /* 삭제된 주문 정보에 있는 제품 이름과 구매수량을 [시그널:sig_reduceInventoryAmount]로 전달합니다. */
        emit sig_reduceInventoryAmount(productName, purchaseQuantity*(-1));
    }
}

/* 오른쪽 마우스버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수 */
void OrderManagerForm::showContextMenu(const QPoint &pos)
{
    QPoint globalPos = ui->tableView->mapToGlobal(pos);
    menu->exec(globalPos);
}

/* tableView의 항목을 선택했을 때 */
void OrderManagerForm::on_tableView_clicked(const QModelIndex &index)
{
    ui->clientTreeWidget->clear();                          // clientTreeWidget을 초기화

    int orderID = orderModel->data(index.siblingAtColumn(0)).toInt();               // orderModel에서 선택된 행의 0열에 있는 정보
    QString date_define = "yyyy-MM-dd";                                             // 날짜 형식 정의
    QString purchaseDay = QDateTime::currentDateTime().toString(date_define);
    purchaseDay = orderModel->data(index.siblingAtColumn(1)).toString();            // orderModel에서 선택된 행의 1열에 있는 정보
    QString clientName = orderModel->data(index.siblingAtColumn(3)).toString();     // orderModel에서 선택된 행의 3열에 있는 정보
    QString productName = orderModel->data(index.siblingAtColumn(4)).toString();    // orderModel에서 선택된 행의 4열에 있는 정보
    int purchaseQuantity = orderModel->data(index.siblingAtColumn(5)).toInt();      // orderModel에서 선택된 행의 5열에 있는 정보
    int totalPrice = orderModel->data(index.siblingAtColumn(6)).toInt();            // orderModel에서 선택된 행의 6열에 있는 정보

    ui->orderIDLineEdit->setText(QString::number(orderID));                 // tableView에서 선택된 항목 중 주문 ID가 orderIDLineEdit에 나타납니다.
    ui->purchaseDayDateEdit->setDate(QDate::fromString(purchaseDay));       // tableView에서 선택된 항목 중 구매 날짜가 purchaseDayDateEdit에 나타납니다.
    ui->clientNameLineEdit->setText(clientName);                            // tableView에서 선택된 항목 중 고객 이름이 clientNameLineEdit에 나타납니다.
    ui->productNameComboBox->setCurrentText(productName);                   // tableView에서 선택된 항목 중 제품 이름이 productNameComboBox에 나타납니다.
    ui->purchaseQuantitySpinBox->setValue(purchaseQuantity);                // tableView에서 선택된 항목 중 구매 수량이 purchaseQuantitySpinBox에 나타납니다.
    ui->totalPriceLineEdit->setText(QString::number(totalPrice));           // tableView에서 선택된 항목 중 총 가격이 totalPriceLineEdit에 나타납니다.

    QModelIndex ix = ui->tableView->currentIndex();                         // tableView의 현재 인덱스
    int clientID = orderModel->data(ix.siblingAtColumn(2)).toInt();         // orderModel에서 선택된 행의 2열에 있는 정보
    emit sig_requestSearchID(clientID);                                     // tableView에서 선택된 주문 정보의 고객 ID를 [시그널:sig_requestSearchID]로 전달합니다.
    ui->productTreeWidget->clear();                                         // productTreeWidget 초기화
    emit sig_requesProductNameSearch(productName);                          // tableView에서 선택된 주문 정보의 제품 이름을 [시그널:sig_requesProductNameSearch]로 전달합니다.
}

/* 초기화해주는 함수 */
void OrderManagerForm::clear()
{
    ui->orderIDLineEdit->setText("");                                       // orderIDLineEdit을 공백으로 비워줌
    ui->clientNameLineEdit->setText("");                                    // clientNameLineEdit을 공백으로 비워줌
    ui->purchaseQuantitySpinBox->setValue(0);                               // purchaseQuantitySpinBox의 값을 0으로 바꿔줌
    ui->totalPriceLineEdit->setText("");                                    // totalPriceLineEdit을 공백으로 비워줌
}

/* 주문을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작 */
void OrderManagerForm::on_addPushButton_clicked()
{
    QString purchaseDay, clientName, productName, totalPrice;
    int clientID, purchaseQuantity;
    int orderID = makeId( );                                                //주문 ID는 자동할당
    ui->orderIDLineEdit->setText(QString::number(orderID));
    purchaseDay = ui->purchaseDayDateEdit->text();                          // purchaseDayDateEdit에서 입력한 text는 구매 날짜
    clientID = this->clientID;
    clientName = ui->clientNameLineEdit->text();                            // clientNameLineEdit에 입력한 text는 고객 이름
    productName = ui->productNameComboBox->currentText();                   // productNameComboBox에서 현재 선택한 제품의 제품 이름
    purchaseQuantity = ui->purchaseQuantitySpinBox->value();                // purchaseQuantitySpinBox에 입력한 value는 구매 수량
    totalPrice = ui->totalPriceLineEdit->text();                            // totalPriceLineEdit에 입력한 text는 총 구매 가격

    /* orderManagerForm에서 주문할 때 입력한 고객 이름이 clientManagerForm에 등록된 고객이 아닌 경우 경고창이 나타납니다. */
    if(this->clientID == -2) {                                                      // clientID == -2는 등록된 고객이 아닌경우
        QMessageBox::critical(this, "Client Search", "등록되지 않은 고객입니다.");      // "등록되지 않은 고객입니다." 경고창
        return;
    }

    /* orderManagerForm에서 주문할 때 입력한 고객 이름이 동명이인일 경우 clientManagerForm에 있는 고객 이름과 일치하는 고객 정보들이
      모두 clientTreeWidget에 나타나게 되고 그 중 주문할 고객 1명을 선택하지 않으면 경고창이 나타나게 됩니다. */
    if(this->clientID == -1) {                                                                               // clientID == -1은 동명이인일 경우
        QMessageBox::information(this, "Client Select", "고객이 선택되지 않았습니다. 선택 후 다시 시도해주세요.");   // "고객이 선택되지 않았습니다. 선택 후 다시 시도해주세요." 경고창
        return;
    }

    QSqlDatabase db = QSqlDatabase::database("orderConnection");
    if(db.isOpen() && purchaseDay.length()) {                                // DB를 열면
        QSqlQuery query(orderModel->database());

        query.prepare("INSERT INTO OrderDB VALUES(?, ?, ?, ?, ?, ?, ?)");    // OrderDB 테이블에 입력한 정보를 삽입합니다.
        query.bindValue(0, orderID);                                         // 0열: 주문 ID
        query.bindValue(1, purchaseDay);                                     // 1열: 구매 날짜
        query.bindValue(2, clientID);                                        // 2열: 고객 ID
        query.bindValue(3, clientName);                                      // 3열: 고객 이름
        query.bindValue(4, productName);                                     // 4열: 제품 이름
        query.bindValue(5, purchaseQuantity);                                // 5열: 구매 수량
        query.bindValue(6, totalPrice);                                      // 6열: 총 가격
        query.exec();                                                        // 쿼리 실행
        orderModel->select();                                                // orderModel을 재정렬
        ui->tableView->resizeColumnsToContents();                            // 이름 크기에 맞기 사이즈를 지정해 줌
    }
    this->clientID = -1;                                                     // clientID 초기값: -1이기 때문에 clientID를 초기화 시켜줌
    emit sig_reduceInventoryAmount(productName, purchaseQuantity);           // 주문할 때 입력한 제품 이름과 구매 수량을 [시그널:sig_reduceInventoryAmount]로 전달합니다.

    ui->clientTreeWidget->clear();                                           // clientTreeWidget 초기화
    ui->productTreeWidget->clear();                                          // productTreeWidget 초기화
    clear();                                                                 // 초기화해주는 함수
}

/* modify 버튼을 누르면 이미 추가된 주문 정보가 변경됩니다. */
void OrderManagerForm::on_modifyPushButton_clicked()
{
    QModelIndex index = ui->tableView->currentIndex();                                  // tableView의 현재 인덱스
    if(index.isValid()) {
        QString purchaseDay, clientName, productName, totalPrice;
        int purchaseQuantity;
        purchaseDay = ui->purchaseDayDateEdit->text();                                  // purchaseDay는 purchaseDayDateEdit에 입력된 정보
        clientName = ui->clientNameLineEdit->text();                                    // clientName은 clientNameLineEdit에 입력된 정보
        productName = ui->productNameComboBox->currentText();                           // productName은 productNameComboBox에 입력된 정보
        purchaseQuantity = ui->purchaseQuantitySpinBox->value();                        // purchaseQuantity는 purchaseQuantitySpinBox에 입력된 정보
        totalPrice = ui->totalPriceLineEdit->text();                                    // totalPrice는 totalPriceLineEdit에 입력된 정보
        int prePurchaseQuantity = orderModel->data(index.siblingAtColumn(5)).toInt();   // prePurchaseQuantity는 이미 주문된 목록의 구매 수량 정보 (기존 구매수량) */

        orderModel->setData(index.siblingAtColumn(1), purchaseDay);                     // 선택된 행의 1열을 purchaseDay로 변경
        orderModel->setData(index.siblingAtColumn(3), clientName);                      // 선택된 행의 3열을 clientName으로 변경
        orderModel->setData(index.siblingAtColumn(4), productName);                     // 선택된 행의 4열을 productName으로 변경
        orderModel->setData(index.siblingAtColumn(5), purchaseQuantity);                // 선택된 행의 5열을 purchaseQuantity으로 변경 (변경된 구매 수량)
        orderModel->setData(index.siblingAtColumn(6), totalPrice);                      // 선택된 행의 6열을 totalPrice로 변경
        orderModel->submit();                                                           // 변경 사항 제출
        orderModel->select();                                                           // orderModel을 재정렬
        ui->tableView->resizeColumnsToContents();                                       // 이름 크기에 맞기 사이즈를 지정해 줌
        /* 변경된 제품 이름과 구매수량(변경된 구매 수량 - 기존 구매 수량)을 [시그널:sig_reduceInventoryAmount]로 전달합니다. */
        emit sig_reduceInventoryAmount(productName, purchaseQuantity-prePurchaseQuantity);
    }
}

/* clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수 */
void OrderManagerForm::on_clearPushButton_clicked()
{
    ui->clientTreeWidget->clear();                                  // clientTreeWidget 초기화
    ui->productTreeWidget->clear();                                 // productTreeWidget 초기화
    clear();                                                        // 초기화해주는 함수
    ui->imageLabel->clear();                                        // 제품의 이미지를 보여주는 imageLabel 초기화
}

/* 주문 정보를 조회하고 싶을 때 Search 버튼을 누르면 조회하실 수 있습니다. */
void OrderManagerForm::on_searchPushButton_clicked()
{
    searchModel->clear();
    int i = ui->searchComboBox->currentIndex();
    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
                   : Qt::MatchCaseSensitive;
    QModelIndexList indexes = orderModel->match(orderModel->index(0, i), Qt::EditRole,
                                                 ui->searchLineEdit->text(), -1, Qt::MatchFlags(flag));
    foreach(auto ix, indexes) {
        QString date_define = "yyyy-MM-dd";
        int orderID = orderModel->data(ix.siblingAtColumn(0)).toInt();                      // 일치하는 주문 ID
        QString purchaseDay = QDateTime::currentDateTime().toString(date_define);
        purchaseDay = orderModel->data(ix.siblingAtColumn(1)).toString();                   // 일치하는 구매 날짜
        int clientID = orderModel->data(ix.siblingAtColumn(2)).toInt();                     // 일치하는 고객 ID
        QString clientName = orderModel->data(ix.siblingAtColumn(3)).toString();            // 일치하는 고객 이름
        QString productName = orderModel->data(ix.siblingAtColumn(4)).toString();           // 일치하는 제품 이름
        QString purchaseQuantity = orderModel->data(ix.siblingAtColumn(5)).toString();      // 일치하는 구매 수량
        QString totalPrice =  orderModel->data(ix.siblingAtColumn(6)).toString();           // 일치하는 총 가격
        QStringList orderStrings;
        orderStrings << QString::number(orderID) << purchaseDay << QString::number(clientID)
                     << clientName << productName << purchaseQuantity << totalPrice;

        QList<QStandardItem *> items;
        for (int i = 0; i < 7; ++i) {
            items.append(new QStandardItem(orderStrings.at(i)));    // 조회된 주문 정보를 순서대로 출력
        }
        searchModel->appendRow(items);
        headerName();                                               // searchTableView의 0~6열까지 헤더 이름을 지정
        ui->searchTableView->resizeColumnsToContents();             // 이름 크기에 맞기 사이즈를 지정해 줌
    }
}

/* clientNameLineEdit에 고객 이름을 입력하고 Enter를 누르면 입력한 고객 이름을 [시그널:sig_requesSearchClient]로 전달합니다. */
void OrderManagerForm::on_clientNameLineEdit_textEdited(const QString clientName)
{
    emit sig_requesSearchClient(clientName);
}

/* orderManagerForm의 clinetLineEdit에 입력한 고객 이름과 일치하는 고객 정보를 clientManagerForm에서 찾아 clientTreeWidget에 출력해주는 슬롯 */
void OrderManagerForm::updateClientTreeWdiget(QList<QStringList> searchedClientList)    // 인자로 받은 searchedClientList는 일치하는 고객 정보를 가지고 있는 List
{
    ui->clientTreeWidget->clear();                                           // clientTreeWidget 초기화
    if(searchedClientList.size() != 0) {                                     // 해당 이름의 고객 정보가 있을때만 작업하기 위한 예외처리
        foreach(auto ix, searchedClientList) {
            QTreeWidgetItem* clientItemClicked = new QTreeWidgetItem();      // 고객 정보 아이템을 담을 clientItemClicked 객체 생성
            clientItemClicked->setText(0, ix.at(0));                         // clientItemClicked의 0열에 일치하는 고객 ID
            clientItemClicked->setText(1, ix.at(1));                         // clientItemClicked의 1열에 일치하는 고객 이름
            clientItemClicked->setText(2, ix.at(2));                         // clientItemClicked의 2열에 일치하는 고객 전화번호
            clientItemClicked->setText(3, ix.at(3));                         // clientItemClicked의 3열에 일치하는 고객 주소
            clientItemClicked->setText(4, ix.at(4));                         // clientItemClicked의 4열에 일치하는 고객 이메일
            ui->clientTreeWidget->addTopLevelItem(clientItemClicked);        // 고객 정보를 담은 clientItemClicked을 clientTreeWidget에 출력합니다.
        }
    }
    if(searchedClientList.size() == 1) {                                     // 동명이인이 없어서 고객을 선택할 필요가 없는 경우
        this->clientID = searchedClientList[0][0].toInt();
    }
    else if(searchedClientList.size() == 0) {                                // clientManagerForm에 등록된 회원이 아닌 경우는 client = -2로 설정
        this->clientID = -2;
    }
    else {                                                                   // 위의 두 조건이 모두 아닌 경우 즉, 동명이인일 경우 client = -1로 설정
        this->clientID = -1;
    }
}

/* 동명이인일 경우 clientTableWidget에 출력된 고객 이름 중 해당하는 고객을 선택하기 위한 함수 */
void OrderManagerForm::on_clientTreeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);
    clientID = item->text(0).toInt();
}

/* orderManagerForm의 tableView에서 주문 정보를 클릭했을 때 해당 고객 ID와 일치하는 고객 정보를 clientTreeWidget에 출력하는 슬롯 */
void OrderManagerForm::updateClient(QStringList clientStrings)              // 인자로 받은 clientStrings는 일치하는 고객 정보를 가지고 있는 List
{
    if(clientStrings.at(0) != nullptr)                                      // 해당 이름의 고객 정보가 있을때만 작업하기 위한 예외처리
    {
        QTreeWidgetItem* clickedClientItem = new QTreeWidgetItem();         // 고객 정보 아이템을 담을 clickedClientItem 객체 생성
        clickedClientItem->setText(0, (clientStrings[0]));                  // clickedClientItem의 0열에 일치하는 고객 ID
        clickedClientItem->setText(1, (clientStrings[1]));                  // clickedClientItem의 1열에 일치하는 고객 이름
        clickedClientItem->setText(2, (clientStrings[2]));                  // clickedClientItem의 2열에 일치하는 고객 전화번호
        clickedClientItem->setText(3, (clientStrings[3]));                  // clickedClientItem의 3열에 일치하는 고객 주소
        clickedClientItem->setText(4, (clientStrings[4]));                  // clickedClientItem의 4열에 일치하는 고객 이메일
        ui->clientTreeWidget->addTopLevelItem(clickedClientItem);           // 고객 정보를 담은 clickedClientItem을 clientTreeWidget에 출력합니다.
    }
}

/* productManagerForm에서 전달받은 제품 이름을 orderManagerForm의 productNameComboBox에 출력해주는 슬롯 */
void OrderManagerForm::slot_productName(int productID, QString productName)
{
    Q_UNUSED(productID);                                            // 전달받은 인자를 사용하지 않을 때 Q_UNUSED()를 사용하여 예외처리
    ui->productNameComboBox->addItem(productName);
}

/* productNameComboBox에서 제품을 선택하면 해당 제품 이름을 [시그널:productFind]로 전달합니다. */
void OrderManagerForm::on_productNameComboBox_textActivated(const QString productName)
{
    emit productFind(productName);

    /* 제품을 클릭하면 imageLabel에 제품의 이미지를 보여줍니다. */
    QString imagePath(tr("smallImg/%1.png").arg(productName));
    QPixmap* selectImage = new QPixmap(imagePath);
    ui->imageLabel->setPixmap(*selectImage);
}

/* 주문할 때 productNameComboBox에서 선택한 제품 이름과 일치하는 제품 정보를 productManagerForm에서 찾아 productTreeWidget에 출력해주는 슬롯 */
void OrderManagerForm::slot_productInfo(QStringList productStrings)                 // 인자로 받은 productStrings는 일치하는 제품 정보를 가지고 있는 List
{
    ui->purchaseQuantitySpinBox->setRange(0, productStrings[3].toInt());            // 구매 수량의 범위를 지정 (최솟값, 최댓값)
    ui->productTreeWidget->clear();                                                 // productTreeWidget 초기화
    if(productStrings.size() > 0) {                                                 // 해당 이름의 제품 정보가 있을때만 작업하기 위한 예외처리
        QTreeWidgetItem* productItemClicked = new QTreeWidgetItem(ui->productTreeWidget);   // 제품 정보 아이템을 담을 productItemClicked 객체 생성
        productItemClicked->setText(0,productStrings[1]);                           // productItemClicked의 0열에 일치하는 제품 이름
        productItemClicked->setText(1,productStrings[2]);                           // productItemClicked의 1열에 일치하는 제품 가격
        productItemClicked->setText(2,productStrings[3]);                           // productItemClicked의 2열에 일치하는 제품 재고 수량
        ui->productTreeWidget->addTopLevelItem(productItemClicked);                 // 제품 정보를 담은 productItemClicked을 productTreeWidget에 출력합니다.

        /* 제품을 클릭하면 imageLabel에 제품의 이미지를 보여줍니다. */
        QString imagePath(tr("smallImg/%1.png").arg(productStrings[1]));
        QPixmap* selectImage = new QPixmap(imagePath);
        ui->imageLabel->setPixmap(*selectImage);
    }
}

/* orderManagerForm의 tableView에서 주문 정보를 클릭했을 때 해당 제품 이름과 일치하는 제품 정보를 productTreeWidget에 출력하는 슬롯 */
void OrderManagerForm::updateProduct(QStringList productStrings)            // 인자로 받은 productStrings는 일치하는 제품 정보를 가지고 있는 List
{
    if(productStrings.at(0) != nullptr) {                                   // 해당 이름의 제품 정보가 있을때만 작업하기 위한 예외처리
        QTreeWidgetItem* clickedProductItem = new QTreeWidgetItem();        // 제품 정보 아이템을 담을 clickedProductItem 객체 생성
        clickedProductItem->setText(0, productStrings[1]);                  // clickedProductItem의 0열에 일치하는 제품 이름
        clickedProductItem->setText(1, productStrings[2]);                  // clickedProductItem의 1열에 일치하는 제품 가격
        clickedProductItem->setText(2, productStrings[3]);                  // clickedProductItem의 2열에 일치하는 제품 재고 수량
        ui->productTreeWidget->addTopLevelItem(clickedProductItem);         // 제품 정보를 담은 clickedProductItem을 productTreeWidget에 출력합니다.

        /* 제품을 클릭하면 imageLabel에 제품의 이미지를 보여줍니다. */
        QString imagePath(tr("smallImg/%1.png").arg(productStrings[1]));
        QPixmap* selectImage = new QPixmap(imagePath);
        ui->imageLabel->setPixmap(*selectImage);
    }
}

/* purchaseQuantitySpinBox의 값이 변경될 때 제품 이름과 구매 수량을 [시그널:sig_calTotalPrice]로 전달합니다. */
void OrderManagerForm::on_purchaseQuantitySpinBox_valueChanged(int purchaseQuantity)
{
    QString productName = ui->productNameComboBox->currentText();           // productName은 현재 productNameComboBox에서 선택된 제품의 이름
    emit sig_calTotalPrice(productName, purchaseQuantity);
}

/* 구매 수량에 따라 계산된 총 구매가격을 totalPriceLineEdit에 출력시켜주는 슬롯 */
void OrderManagerForm::updateTotalPrice(int totalPrice)
{
    ui->totalPriceLineEdit->setText(QString::number(totalPrice));
}

/* productManagerForm에서 제품 이름을 변경하면 orderManagerForm의 productNameComboBox에도 변경된 제품 이름이 출력되는 슬롯 */
void OrderManagerForm::producNameComboBoxModify(int index, QString productName)
{
    ui->productNameComboBox->setItemText(index, productName);
}

/* productManagerForm에서 제품 이름을 삭제하면 orderManagerForm의 productNameComboBox에도 해당 제품이 삭제되는 슬롯 */
void OrderManagerForm::productNameComboBoxRemove(int index)
{
    ui->productNameComboBox->removeItem(index);
}
