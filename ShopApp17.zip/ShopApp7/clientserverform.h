#ifndef CHATSERVERFORM_H
#define CHATSERVERFORM_H

#include <QWidget>
#include <QList>
#include <QHash>

class QLabel;
class QTcpServer;
class QTcpSocket;
class QFile;
class QProgressDialog;
class LogThread;

namespace Ui { class ClientServerForm; }


typedef enum {
    Chat_Login,             // 로그인(서버 접속)   --> 초대를 위한 정보 저장
    Chat_In,                // 채팅방 입장
    Chat_Talk,              // 채팅
    Chat_Out,               // 채팅방 퇴장         --> 초대 가능
    Chat_LogOut,            // 로그 아웃(서버 단절) --> 초대 불가능
    Chat_Invite,            // 초대
    Chat_KickOut,           // 강퇴
} Chat_Status;

class ClientServerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ClientServerForm(QWidget *parent = nullptr);       // 생성자
    ~ClientServerForm();                                        // 소멸자

private:
    const int BLOCK_SIZE = 1024;                                // 블럭 크기 지정
    const int PORT_NUMBER = 8000;                               // 포트 번호 지정

    Ui::ClientServerForm *ui;
    QTcpServer *chatServer;
    QTcpServer *fileServer;
    QList<QTcpSocket*> clientList;
    QList<int> clientIDList;
    QHash<quint16, QString> clientNameHash;
    QHash<QString, QTcpSocket*> clientSocketHash;
    QHash<QString, int> clientIDHash;
    QMenu* menu;
    QFile* file;
    QProgressDialog* progressDialog;
    qint64 totalSize;
    qint64 byteReceived;
    QByteArray inBlock;
    LogThread* logThread;

private slots:
    void clientConnect();                                      // 채팅 서버
    void receiveData();                                        // 데이터를 받는 함수
    void removeClient();                                       // 서버와 연결이 끊긴 경우

    /* Client에서 정보를 받아옴 */
    void addClient(int, QString);                               // clientManagerForm에서 고객을 추가하면 clientServerForm에서도 고객 정보가 추가되는 슬롯
    void slot_updateModifyClient(int, int, QString);            // clientManagerForm에서 고객 정보를 변경하면 clientServerForm에서도 고객 정보가 변경되는 슬롯

    /* clientTreeWidget에서 오른쪽 마우스를 누르면 메뉴 기능(초대)을 실행할 수 있는 함수 */
    void on_clientTreeWidget_customContextMenuRequested(const QPoint &pos);

    void kickOut();                                             // 강퇴 기능을 수행하는 함수
    void inviteClient();                                        // 초대 기능을 수행하는 함수
    void acceptConnection();                                    // 파일 서버
    void readClient();                                          // 파일 전송

    /* treeWidget을 인자로 받은 정보와 일치하는 고객 이름이 있는지 찾고 있다면 이미 로그인 되어 있는지 없는지 확인하는 슬롯 */
    void slot_checkLogin(QString, int);

    /* clientManagerForm에서 등록된 고객을 삭제한 경우 clientServerManagerForm의 clientTreeWidget을 업데이트(고객 삭제) 해주는 슬롯 */
    void slot_updateClientInfo(QString);

    /* Clear 버튼을 누르면 messageTreeWidget이 초기화 됩니다. */
    void on_clearPushButton_clicked();

signals:
    void sig_checkLogin(int, int);                              // 로그인 가능여부와 고객 ID를 [시그널:sig_checkLogin]로 전달합니다.
};

#endif // CHATSERVERFORM_H
