#ifndef CLIENTLOGTHREAD_H
#define CLIENTLOGTHREAD_H

#include <QThread>
#include <QList>

class QTreeWidgetItem;

class ClientLogThread : public QThread
{
    Q_OBJECT
public:
    explicit ClientLogThread(QString name, QObject *parent = nullptr);

private:
    void run();                         // 데이터를 저장하는 함수
    QList<QStringList> itemList;        // 출력할 item들을 담을 List
    QString filename;                   // 파일 이름

signals:
    void send(int data);

public slots:
    void appendData(QStringList);       // 데이터를 출력하는 슬롯
    void saveData();                    // 데이터를 저장하는 슬롯
};

#endif // CLIENTLOGTHREAD_H
