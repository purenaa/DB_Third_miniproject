#include "productmanagerform.h"
#include "ui_productmanagerform.h"
//#include "product.h"

#include <QFile>
#include <QMenu>
#include <QList>
#include <QPixmap>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QStandardItemModel>
#include <QMessageBox>

/* 생성자 (DB를 열 때) */
ProductManagerForm::ProductManagerForm(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::ProductManagerForm)
{
    ui->setupUi(this);                                                  // 지정한 위젯에 대한 사용자 인터페이스를 설정

    QList<int> sizes;
    sizes << 1850 << 1350;                                              // 1850 : tableView size, 1350 : toolBox size
    ui->splitter->setSizes(sizes);                                      // splitter 크기 조절

    QAction* removeAction = new QAction(tr("&Remove"));                 // 삭제 기능 생성
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));     // remove할 때 시그널 슬롯 발생

    menu = new QMenu;                                                   // menu : 멤버변수, 메뉴 생성
    menu->addAction(removeAction);                                      // 메뉴에 remove 기능 추가
    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));                 // searchLineEdit에서의 시그널과 on_searchPushButton_clicked 슬롯 연결

    /* searchTableView의 0~3열(4개)까지 헤더 이름을 지정 */
    searchModel = new QStandardItemModel(0, 4);
    headerName();
    ui->searchTableView->setModel(searchModel);
}

/* searchTableView의 0~3열까지 헤더 이름을 지정해주는 함수 */
void ProductManagerForm::headerName()
{
    searchModel->setHeaderData(0, Qt::Horizontal, tr("제품 ID"));
    searchModel->setHeaderData(1, Qt::Horizontal, tr("제품 이름"));
    searchModel->setHeaderData(2, Qt::Horizontal, tr("가격"));
    searchModel->setHeaderData(3, Qt::Horizontal, tr("재고 수량"));
}

/* DB 생성 */
void ProductManagerForm::loadData()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "productConnection");    // 데이터베이스를  만듦
    db.setDatabaseName("ProductDBlist.db");                                         // DB이름 : ProductDBlist
    if(db.open()) {                                                                 // DB를 열 때
        QSqlQuery query(db);                                                        // DB에 커리생성

        /* 테이블을 생성하고 0~3열까지 헤더 이름을 지정해줍니다. */
        query.exec("CREATE TABLE IF NOT EXISTS ProductDB(id INTEGER Primary Key,"
                   "productName VARCHAR(30) NOT NULL, price VARHCHAR(20), inventoryAmount INTEGER);");
        productModel = new QSqlTableModel(this, db);
        productModel->setTable("ProductDB");                                        // 테이블명 : ProductDB
        productModel->select();                                                     // productModel을 재정렬
        /* 제품 tableView의 0~3열까지 헤더 이름을 지정 */
        productModel->setHeaderData(0, Qt::Horizontal, tr("제품 ID"));
        productModel->setHeaderData(1, Qt::Horizontal, tr("제품 이름"));
        productModel->setHeaderData(2, Qt::Horizontal, tr("가격"));
        productModel->setHeaderData(3, Qt::Horizontal, tr("재고 수량"));
        ui->tableView->setModel(productModel);                                      // tableView에 지정해준 헤더 이름을 가진 모델을 보여줍니다.
        ui->tableView->resizeColumnsToContents();                                   // 이름 크기에 맞기 사이즈를 지정해 줌
    }
    /* productModel의 행의 개수만큼 반복하면서 제품 ID와 제품 이름을 [시그널:productAdded]으로 전달합니다. */
    for(int i = 0; i < productModel->rowCount(); i++) {
        int productID = productModel->data(productModel->index(i, 0)).toInt();
        QString productName = productModel->data(productModel->index(i, 1)).toString();
        emit productAdded(productID, productName);
    }
}

/* 소멸자 (DB를 닫을 때) */
ProductManagerForm::~ProductManagerForm()
{
    delete ui;
    QSqlDatabase db = QSqlDatabase::database("productConnection");
    if(db.isOpen()) {                            // DB를 열 때
        productModel->submitAll();               // 보류 중인 모든 변경 사항을 제출하고 성공 시 true를 반환합니다.
        delete productModel;                     // clientModel 삭제
        db.commit();                             // DB 트랜잭션을 데이터베이스에 커밋합니다. 작업이 성공하면 true를 반환합니다. 그렇지 않으면 false를 반환합니다.
        db.close();                              // DB 닫음
    }
}

/* 고객 ID를 자동 할당해주는 함수 */
int ProductManagerForm::makeId( )                               // 제품 ID를 자동 할당해주는 함수
{
    if(productModel->rowCount() == 0) {                         // productModel의 행의 개수가 0일 때
        return 10000;                                           // 10000을 반환 (첫 번째 제품 ID는 10000이 됩니다.)
    } else {
        auto productId = productModel->data(productModel->index(productModel->rowCount()-1, 0)).toInt();
        return ++productId;
    }
}

/* tableView에 있는 항목을 제거해주는 함수 */
void ProductManagerForm::removeItem()
{
    QModelIndex ix = ui->tableView->currentIndex();             // tableView의 현재 인덱스
    int index = ix.row();                                       // 선택된 인덱스의 행
    if(ix.isValid()) {
        productModel->removeRow(ix.row());                      // clientModel의 해당 인덱스에 있는 행을 제거해줍니다.
        productModel->select();                                 // clientModel을 재정렬
        ui->tableView->update();                                // 인덱스 업데이트
    }
    emit sig_sendRemovdProduct(index);                          // 제거된 인덱스의 행을 [시그널:sig_sendRemovdProduct]로 전달합니다.
}

/* 오른쪽 마우스버튼을 클릭했을 때 메뉴(remove)가 나타나는 함수 */
void ProductManagerForm::showContextMenu(const QPoint &pos)
{
    QPoint globalPos = ui->tableView->mapToGlobal(pos);
    menu->exec(globalPos);
}

/* tableView의 항목을 선택했을 때 */
void ProductManagerForm::on_tableView_clicked(const QModelIndex &index)
{
    int productID = productModel->data(index.siblingAtColumn(0)).toInt();             // productModel에서 선택된 행의 0열에 있는 정보
    QString productName = productModel->data(index.siblingAtColumn(1)).toString();    // productModel에서 선택된 행의 1열에 있는 정보
    QString price = productModel->data(index.siblingAtColumn(2)).toString();          // productModel에서 선택된 행의 2열에 있는 정보
    int inventoryAmount = productModel->data(index.siblingAtColumn(3)).toInt();       // productModel에서 선택된 행의 3열에 있는 정보

    ui->productIDLineEdit->setText(QString::number(productID));                       //tableView에서 선택된 항목 중 제품 ID가 productIDLineEdit에 나타납니다.
    ui->productNameLineEdit->setText(productName);                                    //tableView에서 선택된 항목 중 고객 이름이 productNameLineEdit에 나타납니다.
    ui->priceLineEdit->setText(price);                                                //tableView에서 선택된 항목 중 고객 전화번호가 priceLineEdit에 나타납니다.
    ui->inventoryAmountSpinBox->setValue(inventoryAmount);                            //tableView에서 선택된 항목 중 고객 주소가 inventoryAmountSpinBox에 나타납니다.

    /* 제품을 클릭하면 imageLabel에 제품의 이미지를 보여줍니다. */
    QString imagePath(tr("img/%1.png").arg(productName));
    QPixmap* selectImage = new QPixmap(imagePath);
    ui->imageLabel->setPixmap(*selectImage);
}

/* 초기화해주는 함수 */
void ProductManagerForm::clear()
{
    ui->productIDLineEdit->setText("");                                 // productIDLineEdit을 공백으로 비워줌
    ui->productNameLineEdit->setText("");                               // productNameLineEdit을 공백으로 비워줌
    ui->priceLineEdit->setText("");                                     // priceLineEdit을 공백으로 비워줌
    ui->inventoryAmountSpinBox->setValue(0);                            // inventoryAmountSpinBox를 0으로 초기화
}

/* 제품을 추가하기 위해 각각의 정보를 입력하고 Add 버튼을 눌렀을 때 동작 */
void ProductManagerForm::on_addPushButton_clicked()
{
    QString productName, price;
    int inventoryAmount;
    int productID = makeId( );                                          // 제품 ID는 자동할당
    ui->productIDLineEdit->setText(QString::number(productID));
    productName = ui->productNameLineEdit->text();                      // productNameLineEdit에 입력한 text는 제품 이름
    price = ui->priceLineEdit->text();                                  // priceLineEdit에 입력한 text는 제품 가격
    inventoryAmount = ui->inventoryAmountSpinBox->value();              // inventoryAmountSpinBox에서 선택한 value는 재고 수량
#if 1
    QSqlDatabase db = QSqlDatabase::database("productConnection");
    if(db.isOpen() && productName.length()) {                           // DB를 열면
        QSqlQuery query(productModel->database());
        query.prepare("INSERT INTO ProductDB VALUES(?, ?, ?, ?)");      // ProductDB 테이블에 입력한 정보를 삽입합니다.
        query.bindValue(0, productID);                                  // 0열: 제품 ID
        query.bindValue(1, productName);                                // 1열: 제품 이름
        query.bindValue(2, price);                                      // 2열: 가격
        query.bindValue(3, inventoryAmount);                            // 3열: 재고 수량
        query.exec();                                                   // 쿼리 실행
        productModel->select();                                         // productModel을 재정렬
        ui->tableView->resizeColumnsToContents();                       // 이름 크기에 맞기 사이즈를 지정해 줌
        emit productAdded(productID, productName);                      // 추가한 고객 ID와 고객 이름을 [시그널:clientAdded]로 전달합니다.
#else
    if(productName.length()) {
        QSqlDatabase db = QSqlDatabase::database("productConnection");
        if(db.isOpen()) {                                           // DB를 열면
            QSqlQuery query(db);
            query.exec(QString("INSERT INTO ProductDB VALUES(%1, '%2', '%3', %4)")  // ProductDB 테이블에 입력한 정보를 삽입합니다.
                       .arg(productID).arg(productName).arg(price).arg(inventoryAmount));
            productModel->select();
        }
#endif

    }
    clear();                                                             // 초기화해주는 함수
}

/* modify 버튼을 누르면 이미 추가된 제품 정보가 변경됩니다. */
void ProductManagerForm::on_modifyPushButton_clicked()
{
    QModelIndex ix = ui->tableView->currentIndex();                     // tableView의 현재 인덱스
    int index = ix.row();                                               // 선택된 인덱스의 행
    if(ix.isValid()) {
        QString productName, price;
        int inventoryAmount;
        /*int productID;
        productID = ui->productIDLineEdit->text().toInt(); */             // productID는 productIDLineEdit에 입력된 정보
        productName = ui->productNameLineEdit->text();                  // productName는 productNameLineEdit에 입력된 정보
        price = ui->priceLineEdit->text();                              // price는 priceLineEdit에 입력된 정보
        inventoryAmount = ui->inventoryAmountSpinBox->value();          // inventoryAmount는 inventoryAmountSpinBox에 입력된 정보

        productModel->setData(ix.siblingAtColumn(1), productName);      // 선택된 행의 1열을 productName으로 변경
        productModel->setData(ix.siblingAtColumn(2), price);            // 선택된 행의 2열을 price으로 변경
        productModel->setData(ix.siblingAtColumn(3), inventoryAmount);  // 선택된 행의 3열을 inventoryAmount으로 변경
        productModel->submit();                                         // 변경 사항 제출
        productModel->select();                                         // productModel을 재정렬
        ui->tableView->resizeColumnsToContents();                       // 이름 크기에 맞기 사이즈를 지정해 줌
        emit sig_sendModifyProduct(index, productName);                 // 인덱스의 행, 변경된 제품 이름을 [시그널:sig_sendModifyProduct]로 전달합니다.
    }
}

/* clear 버튼을 누르면 LineEdit에 입력된 정보를 초기화 시켜주는 함수 */
void ProductManagerForm::on_clearPushButton_clicked()
{
    clear();                       // 초기화해주는 함수
    ui->imageLabel->clear();       // 제품 이미지를 보여주는 imageLabel 초기화
}

/* 제품 정보를 조회하고 싶을 때 Search 버튼을 누르면 조회하실 수 있습니다. */
void ProductManagerForm::on_searchPushButton_clicked()
{
    searchModel->clear();
    int i = ui->searchComboBox->currentIndex();
    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
                   : Qt::MatchCaseSensitive;
    QModelIndexList indexes = productModel->match(productModel->index(0, i), Qt::EditRole,
                                                  ui->searchLineEdit->text(), -1, Qt::MatchFlags(flag));
    foreach(auto ix, indexes) {
        int productID = productModel->data(ix.siblingAtColumn(0)).toInt();                  // 일치하는 제품 ID
        QString productName = productModel->data(ix.siblingAtColumn(1)).toString();         // 일치하는 제품 이름
        QString price = productModel->data(ix.siblingAtColumn(2)).toString();               // 일치하는 제품 가격
        QString inventoryAmount = productModel->data(ix.siblingAtColumn(3)).toString();     // 일치하는 제품 재고수량
        QStringList productStrings;
        productStrings << QString::number(productID) << productName << price << inventoryAmount;

        QList<QStandardItem *> items;
        for (int i = 0; i < 4; ++i) {
            items.append(new QStandardItem(productStrings.at(i)));      // 조회된 제품 정보를 순서대로 출력
        }
        searchModel->appendRow(items);
        headerName();                                                   // searchTableView의 0~3열까지 헤더 이름을 지정
        ui->searchTableView->resizeColumnsToContents();                 // 이름 크기에 맞기 사이즈를 지정해 줌
    }
}

/* orderManagerForm의 productNameComboBox에서 선택한 제품 이름과
   productManagerForm에 있는 제품 이름이 일치할 때 일치하는 제품 정보를 가지고 있는 슬롯 */
void ProductManagerForm::slot_productData(QString productName)      // 인자 productName은 orderManagerForm에서 클릭한 제품 이름
{
    /* 인자로 받은 제품 이름과 productModel에 있는 제품 이름이 일치하는지 비교 */
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList products = productModel->match(productModel->index(0,1),
                                                   Qt::EditRole, productName,-1,Qt::MatchFlags(flag));

    /* 제품 이름이 일치하는 제품 정보 (제품 ID, 제품 이름, 가격, 재고 수량) */
    int productID = productModel->data(products.at(0).siblingAtColumn(0)).toInt();
    QString pname = productModel->data(products.at(0).siblingAtColumn(1)).toString();
    QString price = productModel->data(products.at(0).siblingAtColumn(2)).toString();
    int inventoryAmount = productModel->data(products.at(0).siblingAtColumn(3)).toInt();
    QStringList productStrings;
    productStrings << QString::number(productID) << pname << price << QString::number(inventoryAmount);

    emit productData(productStrings);   // orderManagerForm에서 선택한 제품 이름과 일치하는 제품 정보를 [시그널:productData]로 전달합니다.
}

/* orderManagerForm의 tableView에서 클릭한 주문 정보의 제품 이름과
   ProductManagerForm에 있는 제품 이름이 일치할 때 일치하는 제품 정보를 가지고 있는 슬롯 */
void ProductManagerForm::slot_sendProductNameSearch(QString productName)   // 인자 productName은 orderManagerForm의 tableView에서 클릭한 주문 정보의 재품 이름
{
    /* 인자로 받은 제품 이름과 productModel에 있는 제품 이름이 일치하는지 비교 */
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList indexes = productModel->match(productModel->index(0, 1), Qt::EditRole,
                                                  productName, -1, Qt::MatchFlags(flag));
    if(indexes.size() > 0) {
        /* 제품 이름이 일치하는 제품 정보 (제품 ID, 제품 이름, 가격, 재고 수량) */
        int productID = productModel->data(indexes.at(0).siblingAtColumn(0)).toInt();
        QString pName = productModel->data(indexes.at(0).siblingAtColumn(1)).toString();
        QString price = productModel->data(indexes.at(0).siblingAtColumn(2)).toString();
        int inventoryAmount = productModel->data(indexes.at(0).siblingAtColumn(3)).toInt();
        QStringList productStrings;
        productStrings << QString::number(productID) << pName << price << QString::number(inventoryAmount);
        emit sig_sendProductNameSearch(productStrings);     /* orderManagerForm의 tableView에서 클릭한 주문 정보의 제품 이름과
                                                           일치하는 제품 정보를 [시그널:sig_sendProductNameSearch]로 전달합니다. */
    }
}

/* orderManagerForm의 purchaseQuantitySpinBox의 값을 변경할 때 총 제품 가격을 계산해주는 슬롯 */
void ProductManagerForm::slot_CalTotalPrice(QString productName, int purchaseQuantity)    // 인자 productName과 purchaseQuantity는 orderManagerForm에서 주문할 때 선택된 제품 이름과 구매수량
{
    /* 인자로 받은 주문할 때 선택된 제품 이름과 productModel에 있는 제품 이름이 일치하는지 비교 */
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList indexes = productModel->match(productModel->index(0, 1), Qt::EditRole,
                                                  productName, -1, Qt::MatchFlags(flag));
    /* 제품 이름이 일치하는 제품의 가격 */
    QString price = productModel->data(indexes.at(0).siblingAtColumn(2)).toString();
    /* 총 구매 가격을 계산하는 식 */
    int totalPrice = purchaseQuantity * price.toInt();      // 총 구매 가격 = 인자로 받은 구매 수량(orderManagerForm) x 제품 이름이 일치하는 제품의 가격(productManagerForm)
    emit sig_sendTotalPrice(totalPrice);                    // 계산한 총 구매 가격을 [시그널:sig_sendTotalPrice]로 전달합니다.
}

/* orderManagerForm에서 주문된 정보를 삭제하면 삭제된 제품의 이름과
   productManagerForm의 제품 이름이 일치할 때 일치하는 제품의 재고 수량을 업데이트해주는 슬롯 */
void ProductManagerForm::updateInventoryAmount(QString productName, int purchaseQuantity)  // 인자 productName과 purchaseQuantity는 orderManagerForm에서 주문 정보를 삭제할 때 선택된 제품의 이름과 구매 수량
{
    /* 인자로 받은 제품 이름과 productModel에 있는 제품 이름이 일치하는지 비교 */
    auto flag =  Qt::MatchCaseSensitive|Qt::MatchContains;
    QModelIndexList products = productModel->match(productModel->index(0,1),
                                                   Qt::EditRole, productName,-1,Qt::MatchFlags(flag));
    /* 제품 이름이 일치하는 제품의 재고 수량 */
    int inventoryAmount = productModel->data(products.at(0).siblingAtColumn(3)).toInt();
    int result = inventoryAmount-purchaseQuantity;                          // result = 재고 수량 - (-구매수량)
    productModel->setData(products.at(0).siblingAtColumn(3), result);       // productModel의 재고 수량을 result 값으로 업데이트 해줍니다.
    productModel->submit();                                                 // 변경 사항 제출
}
